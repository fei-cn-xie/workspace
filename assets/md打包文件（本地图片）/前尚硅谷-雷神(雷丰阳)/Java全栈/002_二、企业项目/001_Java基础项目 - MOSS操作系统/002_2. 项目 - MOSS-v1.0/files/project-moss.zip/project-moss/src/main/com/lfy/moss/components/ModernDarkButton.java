package com.lfy.moss.components;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;


/**
 *  // 创建不同样式的按钮
 *  ModernDarkButton button1 = new ModernDarkButton("默认按钮");
 *
 *  ModernDarkButton button2 = new ModernDarkButton("自定义按钮");
 *  button2.setHoverColors(new Color(255, 69, 0), new Color(255, 140, 0));
 *
 *  ModernDarkButton button3 = new ModernDarkButton("绿色按钮");
 *  button3.setHoverColors(new Color(34, 139, 34), new Color(0, 255, 127));
 *
 *  ModernDarkButton button4 = new ModernDarkButton("紫色按钮");
 *  button4.setHoverColors(new Color(138, 43, 226), new Color(147, 112, 219));
 */
public class ModernDarkButton extends JButton {
    private boolean isHovered = false;
    private boolean isPressed = false;
    private Timer animationTimer;
    private float animationProgress = 0f;

    // 颜色配置
    private Color normalStartColor = new Color(45, 45, 45);
    private Color normalEndColor = new Color(30, 30, 30);
    private Color hoverStartColor = new Color(70, 130, 180);
    private Color hoverEndColor = new Color(30, 144, 255);
    private Color pressedStartColor = new Color(25, 25, 25);
    private Color pressedEndColor = new Color(15, 15, 15);
    private Color textColor = Color.WHITE;
    private Color borderColor = new Color(60, 60, 60);

    // while； 观察者模式
    public ModernDarkButton(String text) {
        super(text);
        initializeButton();
        setupAnimations();
    }

    private void initializeButton() {
        setFocusPainted(false);
        setBorderPainted(false);
        setContentAreaFilled(false);
        setOpaque(false);
        setFont(new Font("微软雅黑", Font.BOLD, 14));
        setForeground(textColor);
        setCursor(new Cursor(Cursor.HAND_CURSOR));

        // 设置按钮大小
        setPreferredSize(new Dimension(120, 40));

        // button.addActionListenter();
        // 添加鼠标事件监听器
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                isHovered = true;
                startAnimation(true);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                isHovered = false;
                startAnimation(false);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                isPressed = true;
                repaint();
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                isPressed = false;
                repaint();
            }
        });
    }

    private void setupAnimations() {
        animationTimer = new Timer(16, e -> {
            if (isHovered && animationProgress < 1f) {
                animationProgress += 0.1f;
                if (animationProgress >= 1f) {
                    animationProgress = 1f;
                    animationTimer.stop();
                }
                repaint();
            } else if (!isHovered && animationProgress > 0f) {
                animationProgress -= 0.1f;
                if (animationProgress <= 0f) {
                    animationProgress = 0f;
                    animationTimer.stop();
                }
                repaint();
            }
        });
    }

    private void startAnimation(boolean hover) {
        if (!animationTimer.isRunning()) {
            animationTimer.start();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();

        // 启用抗锯齿
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        int width = getWidth();
        int height = getHeight();
        int arcSize = 12;

        // 创建圆角矩形
        RoundRectangle2D roundRect = new RoundRectangle2D.Double(1, 1, width - 2, height - 2, arcSize, arcSize);

        // 绘制阴影
        if (!isPressed) {
            g2d.setColor(new Color(0, 0, 0, 30));
            g2d.fill(new RoundRectangle2D.Double(2, 3, width - 2, height - 2, arcSize, arcSize));
        }

        // 计算当前颜色
        Color currentStartColor = interpolateColor(normalStartColor,
                isPressed ? pressedStartColor : hoverStartColor,
                animationProgress);
        Color currentEndColor = interpolateColor(normalEndColor,
                isPressed ? pressedEndColor : hoverEndColor,
                animationProgress);

        // 绘制渐变背景
        GradientPaint gradient = new GradientPaint(0, 0, currentStartColor, 0, height, currentEndColor);
        g2d.setPaint(gradient);
        g2d.fill(roundRect);

        // 绘制边框
        g2d.setColor(borderColor);
        g2d.setStroke(new BasicStroke(1f));
        g2d.draw(roundRect);

        // 绘制高光效果
        if (isHovered && !isPressed) {
            g2d.setColor(new Color(255, 255, 255, (int)(20 * animationProgress)));
            GradientPaint highlight = new GradientPaint(0, 1, new Color(255, 255, 255, (int)(40 * animationProgress)),
                    0, height / 3, new Color(255, 255, 255, 0));
            g2d.setPaint(highlight);
            g2d.fill(new RoundRectangle2D.Double(2, 2, width - 4, height / 3, arcSize - 2, arcSize - 2));
        }

        g2d.dispose();

        // 绘制文本
        super.paintComponent(g);
    }

    private Color interpolateColor(Color start, Color end, float progress) {
        if (progress <= 0f) return start;
        if (progress >= 1f) return end;

        int r = (int) (start.getRed() + (end.getRed() - start.getRed()) * progress);
        int g = (int) (start.getGreen() + (end.getGreen() - start.getGreen()) * progress);
        int b = (int) (start.getBlue() + (end.getBlue() - start.getBlue()) * progress);

        return new Color(r, g, b);
    }

    // 自定义颜色设置方法
    public void setNormalColors(Color startColor, Color endColor) {
        this.normalStartColor = startColor;
        this.normalEndColor = endColor;
        repaint();
    }

    public void setHoverColors(Color startColor, Color endColor) {
        this.hoverStartColor = startColor;
        this.hoverEndColor = endColor;
        repaint();
    }

    public void setPressedColors(Color startColor, Color endColor) {
        this.pressedStartColor = startColor;
        this.pressedEndColor = endColor;
        repaint();
    }

    public void setTextColor(Color color) {
        this.textColor = color;
        setForeground(color);
        repaint();
    }

    public void setBorderColor(Color color) {
        this.borderColor = color;
        repaint();
    }




}

