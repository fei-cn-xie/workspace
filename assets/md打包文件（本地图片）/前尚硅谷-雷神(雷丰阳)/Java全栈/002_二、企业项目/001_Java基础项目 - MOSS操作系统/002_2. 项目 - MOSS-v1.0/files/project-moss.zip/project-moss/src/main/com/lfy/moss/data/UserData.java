package com.lfy.moss.data;

import java.util.HashMap;
import java.util.Map;

public class UserData {
    private final static Map<String,Object>  users = new HashMap<>();
}
