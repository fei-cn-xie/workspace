package com.lfy.moss.views;

import com.lfy.moss.components.ModernDarkButton;
import com.lfy.moss.components.ModernLightPanel;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class StatusBarPanel extends JPanel {

    public StatusBarPanel() {
        //
//        JPanel panel = ModernLightPanel.createContentPanel("","",new Color(34, 197, 94));

//        setBackground(new Color(34, 197, 94));
        setLayout(new BorderLayout());
//        panel.setLayout(new BorderLayout());

        //1、给状态栏里面添加一个图标
        addStartButton(this);
        addTimelable(this);

    }

    private void addTimelable(JPanel panel) {
        LocalDateTime now = LocalDateTime.now();

        //格式化器：
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String format = formatter.format(now);

        JLabel timeLable = new JLabel(format);
        panel.add(timeLable,BorderLayout.EAST);

        //每秒让 timeLable 更新时间
        new Timer(1000, e->{
            String str = formatter.format(LocalDateTime.now());
            timeLable.setText(str);
        }).start();
    }

    private void addStartButton(JPanel panel) {
        ModernDarkButton startButton = new ModernDarkButton("开始");
        panel.add(startButton,BorderLayout.WEST);
    }
}
