package com.lfy.moss.components;


import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;


/**

 *             panel1.add(createContentPanel("默认样式", "这是一个默认样式的现代化Panel",
 *                     new Color(100, 100, 100)), BorderLayout.CENTER);
 *

 *             panel2.add(createContentPanel("卡片样式", "具有更深阴影的卡片风格Panel",
 *                     new Color(100, 100, 100)), BorderLayout.CENTER);

 *             panel3.add(createContentPanel("高架样式", "具有更强立体感的Panel",
 *                     new Color(100, 100, 100)), BorderLayout.CENTER);
 *

 *             panel4.add(createContentPanel("强调样式", "用于重要信息展示",
 *                     new Color(59, 130, 246)), BorderLayout.CENTER);
 *

 *             panel5.add(createContentPanel("成功样式", "表示成功状态的Panel",
 *                     new Color(34, 197, 94)), BorderLayout.CENTER);

 *             panel6.add(createContentPanel("警告样式", "用于警告信息展示",
 *                     new Color(245, 158, 11)), BorderLayout.CENTER);
 */
public class ModernLightPanel extends JPanel {
    private boolean isHovered = false;
    private Timer animationTimer;
    private float animationProgress = 0f;
    private int shadowSize = 8;
    private int cornerRadius = 16;

    // 亮色主题颜色配置
    private Color normalStartColor = new Color(250, 250, 250);
    private Color normalEndColor = new Color(240, 240, 240);
    private Color hoverStartColor = new Color(255, 255, 255);
    private Color hoverEndColor = new Color(245, 250, 255);
    private Color borderColor = new Color(220, 220, 220);
    private Color shadowColor = new Color(0, 0, 0, 15);
    private Color accentColor = new Color(64, 150, 255);

    public enum PanelStyle {
        DEFAULT, CARD, ELEVATED, ACCENT, SUCCESS, WARNING, ERROR
    }

    private PanelStyle style = PanelStyle.DEFAULT;

    public ModernLightPanel() {
        initializePanel();
        setupAnimations();
    }

    public ModernLightPanel(PanelStyle style) {
        this.style = style;
        initializePanel();
        setupAnimations();
        applyStyle();
    }

    private void initializePanel() {
        setOpaque(false);
        setBackground(new Color(0, 0, 0, 0)); // 透明背景

        // 设置默认大小
        setPreferredSize(new Dimension(300, 200));

        // 添加鼠标事件监听器
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                isHovered = true;
                startAnimation(true);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                isHovered = false;
                startAnimation(false);
            }
        });
    }

    private void setupAnimations() {
        animationTimer = new Timer(16, e -> {
            if (isHovered && animationProgress < 1f) {
                animationProgress += 0.08f;
                if (animationProgress >= 1f) {
                    animationProgress = 1f;
                    animationTimer.stop();
                }
                repaint();
            } else if (!isHovered && animationProgress > 0f) {
                animationProgress -= 0.08f;
                if (animationProgress <= 0f) {
                    animationProgress = 0f;
                    animationTimer.stop();
                }
                repaint();
            }
        });
    }

    private void startAnimation(boolean hover) {
        if (!animationTimer.isRunning()) {
            animationTimer.start();
        }
    }

    private void applyStyle() {
        switch (style) {
            case CARD:
                shadowSize = 12;
                cornerRadius = 20;
                normalStartColor = new Color(255, 255, 255);
                normalEndColor = new Color(248, 250, 252);
                borderColor = new Color(226, 232, 240);
                break;

            case ELEVATED:
                shadowSize = 16;
                cornerRadius = 16;
                normalStartColor = new Color(255, 255, 255);
                normalEndColor = new Color(251, 253, 255);
                shadowColor = new Color(0, 0, 0, 25);
                break;

            case ACCENT:
                normalStartColor = new Color(239, 246, 255);
                normalEndColor = new Color(219, 234, 254);
                hoverStartColor = new Color(254, 249, 195);
                hoverEndColor = new Color(147, 197, 253);
                accentColor = new Color(59, 130, 246);
                borderColor = new Color(147, 197, 253);
                break;

            case SUCCESS:
                normalStartColor = new Color(240, 253, 244);
                normalEndColor = new Color(220, 252, 231);
                hoverStartColor = new Color(254, 255, 255);
                hoverEndColor = new Color(187, 247, 208);
                accentColor = new Color(34, 197, 94);
                borderColor = new Color(187, 247, 208);
                break;

            case WARNING:
                normalStartColor = new Color(255, 251, 235);
                normalEndColor = new Color(254, 243, 199);
                hoverStartColor = new Color(255, 255, 255);
                hoverEndColor = new Color(252, 211, 77);
                accentColor = new Color(245, 158, 11);
                borderColor = new Color(252, 211, 77);
                break;

            case ERROR:
                normalStartColor = new Color(254, 242, 242);
                normalEndColor = new Color(254, 226, 226);
                hoverStartColor = new Color(255, 255, 255);
                hoverEndColor = new Color(252, 165, 165);
                accentColor = new Color(239, 68, 68);
                borderColor = new Color(252, 165, 165);
                break;
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();

        // 启用抗锯齿和高质量渲染
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);

        int width = getWidth();
        int height = getHeight();

        // 绘制阴影
        paintShadow(g2d, width, height);

        // 绘制主体背景
        paintBackground(g2d, width, height);

        // 绘制边框
        paintBorder(g2d, width, height);

        // 绘制装饰元素
        paintDecorations(g2d, width, height);

        g2d.dispose();
        super.paintComponent(g);
    }

    private void paintShadow(Graphics2D g2d, int width, int height) {
        // 多层阴影效果
        for (int i = shadowSize; i > 0; i--) {
            float alpha = (float) (shadowSize - i + 1) / shadowSize * 0.05f;
            Color shadowColorWithAlpha = new Color(0, 0, 0, (int) (alpha * 255 * (1 + animationProgress * 0.5f)));
            g2d.setColor(shadowColorWithAlpha);

            RoundRectangle2D shadow = new RoundRectangle2D.Double(
                    i, i + 2,
                    width - i * 2, height - i * 2 - 2,
                    cornerRadius, cornerRadius
            );
            g2d.fill(shadow);
        }
    }

    private void paintBackground(Graphics2D g2d, int width, int height) {
        // 计算当前背景颜色
        Color currentStartColor = interpolateColor(normalStartColor, hoverStartColor, animationProgress);
        Color currentEndColor = interpolateColor(normalEndColor, hoverEndColor, animationProgress);

        // 创建圆角矩形
        RoundRectangle2D roundRect = new RoundRectangle2D.Double(
                shadowSize / 2, shadowSize / 2,
                width - shadowSize, height - shadowSize,
                cornerRadius, cornerRadius
        );

        // 绘制渐变背景
        GradientPaint gradient = new GradientPaint(
                0, shadowSize / 2, currentStartColor,
                0, height - shadowSize, currentEndColor
        );
        g2d.setPaint(gradient);
        g2d.fill(roundRect);

        // 绘制高光效果
        if (animationProgress > 0) {
            g2d.setColor(new Color(255, 255, 255, (int) (30 * animationProgress)));
            GradientPaint highlight = new GradientPaint(
                    0, shadowSize / 2,
                    new Color(255, 255, 255, (int) (50 * animationProgress)),
                    0, height / 3,
                    new Color(255, 255, 255, 0)
            );
            g2d.setPaint(highlight);

            RoundRectangle2D highlightRect = new RoundRectangle2D.Double(
                    shadowSize / 2 + 1, shadowSize / 2 + 1,
                    width - shadowSize - 2, height / 3,
                    cornerRadius - 2, cornerRadius - 2
            );
            g2d.fill(highlightRect);
        }
    }

    private void paintBorder(Graphics2D g2d, int width, int height) {
        // 绘制边框
        Color currentBorderColor = interpolateColor(borderColor, accentColor, animationProgress * 0.3f);
        g2d.setColor(currentBorderColor);
        g2d.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        RoundRectangle2D borderRect = new RoundRectangle2D.Double(
                shadowSize / 2 + 0.75, shadowSize / 2 + 0.75,
                width - shadowSize - 1.5, height - shadowSize - 1.5,
                cornerRadius, cornerRadius
        );
        g2d.draw(borderRect);
    }

    private void paintDecorations(Graphics2D g2d, int width, int height) {
        // 绘制装饰性渐变线条（顶部）
        if (style == PanelStyle.ACCENT || style == PanelStyle.SUCCESS ||
                style == PanelStyle.WARNING || style == PanelStyle.ERROR) {

            g2d.setStroke(new BasicStroke(3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g2d.setColor(accentColor);

            g2d.drawLine(
                    shadowSize / 2 + cornerRadius / 2, shadowSize / 2,
                    width - shadowSize - cornerRadius / 2, shadowSize / 2
            );
        }

        // 绘制微妙的装饰点
        if (animationProgress > 0.5f) {
            g2d.setColor(new Color(accentColor.getRed(), accentColor.getGreen(), accentColor.getBlue(),
                    (int) (20 * (animationProgress - 0.5f) * 2)));

            int dotSize = 4;
            int spacing = 12;
            int startX = width - shadowSize / 2 - 30;
            int y = shadowSize / 2 + 10;

            for (int i = 0; i < 3; i++) {
                g2d.fillOval(startX + i * spacing, y, dotSize, dotSize);
            }
        }
    }

    private Color interpolateColor(Color start, Color end, float progress) {
        if (progress <= 0f) return start;
        if (progress >= 1f) return end;

        int r = (int) (start.getRed() + (end.getRed() - start.getRed()) * progress);
        int g = (int) (start.getGreen() + (end.getGreen() - start.getGreen()) * progress);
        int b = (int) (start.getBlue() + (end.getBlue() - start.getBlue()) * progress);
        int a = (int) (start.getAlpha() + (end.getAlpha() - start.getAlpha()) * progress);

        return new Color(r, g, b, a);
    }

    // Getter和Setter方法
    public void setStyle(PanelStyle style) {
        this.style = style;
        applyStyle();
        repaint();
    }

    public void setCornerRadius(int radius) {
        this.cornerRadius = radius;
        repaint();
    }

    public void setShadowSize(int size) {
        this.shadowSize = size;
        repaint();
    }

    public void setColors(Color normalStart, Color normalEnd, Color hoverStart, Color hoverEnd) {
        this.normalStartColor = normalStart;
        this.normalEndColor = normalEnd;
        this.hoverStartColor = hoverStart;
        this.hoverEndColor = hoverEnd;
        repaint();
    }

    public void setAccentColor(Color color) {
        this.accentColor = color;
        repaint();
    }

    public static JPanel createContentPanel(String title, String description, Color titleColor) {
        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 18));
        titleLabel.setForeground(titleColor);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel descLabel = new JLabel("<html><div style='text-align: center;'>" + description + "</div></html>");
        descLabel.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        descLabel.setForeground(new Color(120, 120, 120));
        descLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        content.add(Box.createVerticalGlue());
        content.add(titleLabel);
        content.add(Box.createVerticalStrut(10));
        content.add(descLabel);
        content.add(Box.createVerticalGlue());

        return content;
    }
}
