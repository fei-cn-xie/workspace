package com.lfy.moss;


import com.lfy.moss.components.ModernDarkButton;
import com.lfy.moss.components.ModernTextField;
import com.lfy.moss.frame.DesktopFrame;
import com.lfy.moss.frame.LoginFrame;
import com.lfy.moss.views.DesktopView;
import com.lfy.moss.views.StatusBarPanel;

import javax.swing.*;
import java.awt.*;

/**
 * 项目主程序：模拟操作系统
 */
public class MainApplication {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginFrame();
        });
    }

}
