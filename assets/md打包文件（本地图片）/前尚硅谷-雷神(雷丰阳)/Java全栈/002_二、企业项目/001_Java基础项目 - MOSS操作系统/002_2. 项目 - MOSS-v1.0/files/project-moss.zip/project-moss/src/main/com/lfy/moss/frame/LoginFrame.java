package com.lfy.moss.frame;

import com.lfy.moss.components.ModernDarkButton;
import com.lfy.moss.components.ModernTextField;

import javax.swing.*;
import java.awt.*;

/**
 * @author 53409
 */
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;

public class LoginFrame extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JLabel avatarLabel;

    public LoginFrame() {
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        setFrameProperties();

        //自动展示
        setVisible(true);
    }

    private void initializeComponents() {
        // 创建组件
        usernameField = createStyledTextField("请输入用户名");
        passwordField = createStyledPasswordField("请输入密码");
        loginButton = createStyledButton("登 录");
        avatarLabel = createAvatarLabel();
    }

    private void setupLayout() {
        setLayout(new BorderLayout());

        // 主面板
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(245, 245, 245));
        mainPanel.setBorder(new EmptyBorder(50, 50, 50, 50));
        mainPanel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();

        // 标题
        JLabel titleLabel = new JLabel("用户登录");
        titleLabel.setFont(new Font("微软雅黑", Font.BOLD, 28));
        titleLabel.setForeground(new Color(51, 51, 51));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0; gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 30, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(titleLabel, gbc);

        // 头像
        gbc.gridx = 0; gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 0, 30, 0);
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        mainPanel.add(avatarLabel, gbc);

        // 用户名标签
        JLabel userLabel = createLabel("用户名:");
        gbc.gridx = 0; gbc.gridy = 2;
        gbc.gridwidth = 1;
        gbc.insets = new Insets(0, 0, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;
        mainPanel.add(userLabel, gbc);

        // 用户名输入框
        gbc.gridx = 1; gbc.gridy = 2;
        gbc.insets = new Insets(0, 0, 10, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        mainPanel.add(usernameField, gbc);

        // 密码标签
        JLabel passwordLabel = createLabel("密  码:");
        gbc.gridx = 0; gbc.gridy = 3;
        gbc.insets = new Insets(0, 0, 20, 10);
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        mainPanel.add(passwordLabel, gbc);

        // 密码输入框
        gbc.gridx = 1; gbc.gridy = 3;
        gbc.insets = new Insets(0, 0, 20, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        mainPanel.add(passwordField, gbc);

        // 登录按钮
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(10, 0, 0, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        mainPanel.add(loginButton, gbc);

        add(mainPanel, BorderLayout.CENTER);
    }

    private JTextField createStyledTextField(String placeholder) {
        JTextField field = new JTextField(20) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                super.paintComponent(g);
                g2.dispose();
            }
        };

        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                BorderFactory.createEmptyBorder(12, 15, 12, 15)
        ));
        field.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        field.setBackground(Color.WHITE);
        field.setForeground(new Color(51, 51, 51));

        // 添加占位符效果
        addPlaceholder(field, placeholder);

        return field;
    }

    private JPasswordField createStyledPasswordField(String placeholder) {
        JPasswordField field = new JPasswordField(20) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                super.paintComponent(g);
                g2.dispose();
            }
        };

        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                BorderFactory.createEmptyBorder(12, 15, 12, 15)
        ));
        field.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        field.setBackground(Color.WHITE);
        field.setForeground(new Color(51, 51, 51));
        field.setEchoChar('●');

        return field;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                if (getModel().isPressed()) {
                    g2.setColor(new Color(45, 125, 255));
                } else if (getModel().isRollover()) {
                    g2.setColor(new Color(75, 155, 255));
                } else {
                    g2.setColor(new Color(65, 145, 255));
                }

                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);

                FontMetrics fm = g2.getFontMetrics();
                int x = (getWidth() - fm.stringWidth(getText())) / 2;
                int y = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;

                g2.setColor(Color.WHITE);
                g2.drawString(getText(), x, y);

                g2.dispose();
            }
        };

        button.setPreferredSize(new Dimension(280, 45));
        button.setFont(new Font("微软雅黑", Font.BOLD, 16));
        button.setBorder(null);
        button.setFocusPainted(false);
        button.setContentAreaFilled(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        return button;
    }

    private JLabel createAvatarLabel() {
        JLabel label = new JLabel();

        // 创建一个圆形的用户头像图标
        ImageIcon avatarIcon = createUserAvatarIcon();
        label.setIcon(avatarIcon);
        label.setHorizontalAlignment(SwingConstants.CENTER);

        return label;
    }

    private ImageIcon createUserAvatarIcon() {
        int size = 80;
        BufferedImage image = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // 绘制圆形背景
        g2.setColor(new Color(65, 145, 255));
        g2.fillOval(0, 0, size, size);

        // 绘制用户图标
        g2.setColor(Color.WHITE);
        g2.setStroke(new BasicStroke(2));

        // 头部
        int headSize = size / 4;
        g2.fillOval(size/2 - headSize/2, size/4, headSize, headSize);

        // 身体
        int bodyWidth = size / 2;
        int bodyHeight = size / 3;
        g2.fillArc(size/2 - bodyWidth/2, size/2 + 5, bodyWidth, bodyHeight, 0, 180);

        g2.dispose();
        return new ImageIcon(image);
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        label.setForeground(new Color(51, 51, 51));
        return label;
    }

    private void addPlaceholder(JTextField field, String placeholder) {
        field.setText(placeholder);
        field.setForeground(Color.GRAY);

        field.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                if (field.getText().equals(placeholder)) {
                    field.setText("");
                    field.setForeground(new Color(51, 51, 51));
                }
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                if (field.getText().isEmpty()) {
                    field.setText(placeholder);
                    field.setForeground(Color.GRAY);
                }
            }
        });
    }

    private void setupEventHandlers() {
        // 登录按钮事件
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (username.equals("请输入用户名") || username.trim().isEmpty()) {
                    showMessage("请输入用户名！");
                    return;
                }

                if (password.trim().isEmpty()) {
                    showMessage("请输入密码！");
                    return;
                }

                // 这里可以添加实际的登录验证逻辑
                if (username.equals("admin") && password.equals("123456")) {
                    showMessage("登录成功！");
                    // 关闭登录窗口，打开主窗口
                    dispose(); // 直接销毁
//                    setVisible(false); //不展示


                    // 打开桌面
                    new DesktopFrame();
                } else {
                    showMessage("用户名或密码错误！");
                }
            }
        });

        // 回车键登录
        passwordField.addActionListener(e -> loginButton.doClick());

        // 头像点击事件
        avatarLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                showMessage("可以在这里添加更换头像功能！");
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                avatarLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
        });
    }

    private void setFrameProperties() {
        setTitle("用户登录");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        pack();
        setLocationRelativeTo(null); // 居中显示

        // 设置窗口图标
        try {
            setIconImage(createUserAvatarIcon().getImage());
        } catch (Exception e) {
            // 忽略图标设置错误
        }
    }

    private void showMessage(String message) {
        JOptionPane.showMessageDialog(this, message, "提示", JOptionPane.INFORMATION_MESSAGE);
    }


}

