package com.lfy.moss.frame;

import com.lfy.moss.views.DesktopView;
import com.lfy.moss.views.StatusBarPanel;

import javax.swing.*;
import java.awt.*;

public class DesktopFrame extends JFrame {

    public DesktopFrame() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        Container pane = getContentPane();
        pane.setLayout(new BorderLayout());


        //上：桌面
        DesktopView desktopView = new DesktopView();
        //下：状态栏
        StatusBarPanel barPanel = new StatusBarPanel();
        barPanel.setSize(800, 20);


        pane.add(desktopView, BorderLayout.CENTER);
        pane.add(barPanel, BorderLayout.SOUTH);


        // 自动展示
        setVisible(true);
    }
}
