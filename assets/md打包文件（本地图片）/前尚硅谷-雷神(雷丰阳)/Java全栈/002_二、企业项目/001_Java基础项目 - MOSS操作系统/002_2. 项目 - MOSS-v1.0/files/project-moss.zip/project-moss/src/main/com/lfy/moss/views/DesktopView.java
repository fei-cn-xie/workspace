package com.lfy.moss.views;

import com.lfy.moss.components.DesktopIcon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class DesktopView  extends JPanel {


    public DesktopView() {
        super();
        //流式布局
        setLayout(new FlowLayout(FlowLayout.LEFT, 20, 20));
        //把所有的桌面图标都放进去
        addAllDesktopIcons();

        //添加一个鼠标右键单击监听
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    // 显示右键菜单
                    System.out.println("点了右键....");
                    // 弹出右键菜单
                    JPopupMenu popup = new JPopupMenu();
                    popup.add(new JMenuItem("新建"));

                    JMenuItem item = new JMenuItem("刷新");
                    item.addActionListener(e1 ->{
                       //播放系统声音
                        Toolkit.getDefaultToolkit().beep();
                    });
                    popup.add(item);


                    popup.show(DesktopView.this, e.getX(), e.getY());
                }
            }
        });
    }

    private void addAllDesktopIcons() {

        // 文件夹图标
        DesktopIcon folderIcon = new DesktopIcon(DesktopIcon.createFolderIcon(), "我的文档");
        folderIcon.addDoubleClickListener(e ->
                JOptionPane.showMessageDialog(this, "双击了: " + folderIcon.getText()));

        // 应用程序图标
        DesktopIcon appIcon = new DesktopIcon(DesktopIcon.createAppIcon(), "记事本");
        appIcon.addDoubleClickListener(e ->
                JOptionPane.showMessageDialog(this, "启动应用程序: " + appIcon.getText()));

        // 图片图标
        DesktopIcon imageIcon = new DesktopIcon(DesktopIcon.createImageIcon(), "我的图片");
        imageIcon.addDoubleClickListener(e ->
                JOptionPane.showMessageDialog(this, "打开图片: " + imageIcon.getText()));

        // 音乐图标
        DesktopIcon musicIcon = new DesktopIcon(DesktopIcon.createMusicIcon(), "音乐播放器");
        musicIcon.addDoubleClickListener(e ->
                JOptionPane.showMessageDialog(this, "播放音乐: " + musicIcon.getText()));

        // 视频图标
        DesktopIcon videoIcon = new DesktopIcon(DesktopIcon.createVideoIcon(), "视频播放器");
        videoIcon.addDoubleClickListener(e ->
                JOptionPane.showMessageDialog(this, "播放视频: " + videoIcon.getText()));

        // 设置图标
        DesktopIcon settingsIcon = new DesktopIcon(DesktopIcon.createSettingsIcon(), "系统设置");
        settingsIcon.addDoubleClickListener(e ->
                JOptionPane.showMessageDialog(this, "打开设置: " + settingsIcon.getText()));

        // 网络图标
        DesktopIcon networkIcon = new DesktopIcon(DesktopIcon.createNetworkIcon(), "网络连接");
        networkIcon.addDoubleClickListener(e ->
                JOptionPane.showMessageDialog(this, "网络设置: " + networkIcon.getText()));

        // 回收站图标
        DesktopIcon trashIcon = new DesktopIcon(DesktopIcon.createTrashIcon(), "回收站");
        trashIcon.addDoubleClickListener(e ->
                JOptionPane.showMessageDialog(this, "打开回收站: " + trashIcon.getText()));

        // 添加到容器
        this.add(folderIcon);
        this.add(appIcon);
        this.add(imageIcon);
        this.add(musicIcon);
        this.add(videoIcon);
        this.add(settingsIcon);
        this.add(networkIcon);
        this.add(trashIcon);

        // 添加单击监听器（用于取消其他图标的选中状态）
        DesktopIcon[] icons = {folderIcon, appIcon, imageIcon, musicIcon,
                videoIcon, settingsIcon, networkIcon, trashIcon};

        for (DesktopIcon icon : icons) {
            icon.addActionListener(e -> {
                // 取消其他图标的选中状态
                for (DesktopIcon otherIcon : icons) {
                    if (otherIcon != e.getSource()) {
                        otherIcon.setSelected(false);
                    }
                }
            });
        }
    }

    // 绘制渐变背景
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // 绘制渐变背景
        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gradient = new GradientPaint(
                0, 0, new Color(20, 30, 48),
                getWidth(), getHeight(), new Color(36, 59, 85)
        );
        g2d.setPaint(gradient);
        g2d.fillRect(0, 0, getWidth(), getHeight());
    }
}
