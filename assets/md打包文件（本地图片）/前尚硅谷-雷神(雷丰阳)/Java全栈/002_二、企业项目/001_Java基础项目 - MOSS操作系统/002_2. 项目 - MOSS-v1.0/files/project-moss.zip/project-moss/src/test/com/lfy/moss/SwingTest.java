package com.lfy.moss;

import com.lfy.moss.components.DesktopIcon;
import com.lfy.moss.components.ModernDarkButton;
import com.lfy.moss.components.ModernTextField;
import org.junit.Test;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import java.awt.*;
import java.awt.event.*;

public class SwingTest {


    @Test
    public void test04(){

        JFrame frame = new JFrame("测试");
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);

        // 给窗口添加组件； 面板组件
        JPanel pane = (JPanel) frame.getContentPane();
        pane.setLayout(new FlowLayout());

        JButton button1 = new JButton("按钮1");
        pane.add(button1);
        ModernDarkButton button2 = new ModernDarkButton("按钮2");
        button2.addActionListener(e -> System.out.println("按钮2被点击"));
        pane.add(button2);

        ModernTextField field = new ModernTextField(ModernTextField.FieldType.TEXT);
        pane.add(field);
        ModernTextField field2 = new ModernTextField(ModernTextField.FieldType.PASSWORD);
        pane.add(field2);


        Icon appIcon = DesktopIcon.createAppIcon();
        DesktopIcon icon = new DesktopIcon(appIcon, "我的电脑");
        pane.add(icon);

        frame.setVisible(true);
        sleep();
    }


    @Test
    public void test03(){
        JFrame frame = new JFrame("测试");
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);

        //给窗口添加组件； 面板组件
        JPanel pane = (JPanel) frame.getContentPane();
        //边界布局
        pane.setLayout(new BorderLayout());

        JButton button1 = new JButton("按钮1");
        JButton button2 = new JButton("按钮2");
        JButton button3 = new JButton("按钮3");
        JButton button4 = new JButton("按钮4");
        JButton button5 = new JButton("按钮5");
        JButton button6 = new JButton("按钮6");



//        JPanel panel = new JPanel();


        // 添加组件的时候，指定在布局区域的位置
        pane.add(button1, BorderLayout.NORTH);
        pane.add(button2, BorderLayout.SOUTH);
        pane.add(button3, BorderLayout.WEST);
        pane.add(button4, BorderLayout.EAST);
        pane.add(button5, BorderLayout.CENTER);
        pane.add(button6);


        //展示

        frame.setVisible(true);



        sleep();
    }


    // 我 + AI = 嘎嘎乱杀
    @Test
    public void test02(){
        JFrame frame = new JFrame("测试2");
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);

        //给窗口添加组件
        Container pane = frame.getContentPane();
        // FlowLayout： 流式布局； 默认居中
        pane.setLayout(new FlowLayout());

        //添加各种组件
        addButton(pane); // 按钮组件
        addTextField(pane); // 文本输入框组件
        addLabel(pane); // 标签组件
        addCheckBox(pane); // 复选框
        addRadioButton(pane); // 单选按钮
//        addComboBox(pane); // 下拉框
//        addList(pane); // 列表
        addTable(pane); // 表格
//        addMenuBar(pane); // 菜单栏
//        addScrollPane(pane); // 滚动面板
//        addSlider(pane); // 滑动条
//        addSpinner(pane); // 数字选择器
//        addProgressBar(pane); // 进度条
//        addEditorPane(pane); // 富文本编辑器
//        addTextArea(pane); // 文本域
//        addPasswordField(pane); // 密码输入框
        addTree(pane); // 树形结构


        //展示
        frame.setVisible(true);


        sleep();
    }

    private void addTree(Container pane) {
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("project-moss");
        DefaultMutableTreeNode src = new DefaultMutableTreeNode("src");

        src.add(new DefaultMutableTreeNode("main"));
        src.add(new DefaultMutableTreeNode("test"));

        root.add(src);
        root.add(new DefaultMutableTreeNode("project-moss.iml"));
        JTree tree = new JTree(root);


        pane.add(tree);
    }

    private void addTable(Container pane) {
        String[][] rowData = {
                {"张三","20","男"},
                {"李四","21","女"},
                {"王五","22","男"},
                {"赵六","23","女"},
                {"孙七","24","男"},
                {"周八","25","女"}
        };
        String[] columnNames = {"姓名","年龄","性别"};

        //把所有行列数据封装一个 DefaultTableModel
        DefaultTableModel model = new DefaultTableModel(rowData,columnNames);

        JTable table = new JTable(model);

        //带滚动条的面板
        JScrollPane scrollPane = new JScrollPane(table);
        JButton button = new JButton("添加数据");
        button.addActionListener(e -> {
            String[] newRow = {"张三"+(rowData.length+1),"20","男"};
            //封装了表格模型，可以直接操作表格数据
            model.addRow(newRow);
            // 刷新表格数据
            table.repaint();
        });

        pane.add(scrollPane);
        pane.add(button);
    }

    private void addRadioButton(Container pane) {

    }

    private void addCheckBox(Container pane) {
        JCheckBox checkBox1 = new JCheckBox("同意协议");
        JCheckBox checkBox2 = new JCheckBox("同意支付");
        JButton button = new JButton("查询选择状态");
        button.addActionListener(e -> {
            System.out.println("checkbox1："+checkBox1.isSelected());
            System.out.println("checkbox2："+checkBox2.isSelected());
        });

        pane.add(checkBox1);
        pane.add(checkBox2);
        pane.add(button);

    }

    private void addLabel(Container pane) {
        JLabel jLabel = new JLabel("标签-哈哈");
        pane.add(jLabel);
    }

    private void addTextField(Container pane) {
        //给定长度 20， 即文本框的长度为 20个字符的宽度
        JTextField textField = new JTextField(20);
        JButton button = new JButton("获取内容");

        button.addActionListener(e -> {
           //回调触发
            String text = textField.getText();
            System.out.println(text);
        });

        pane.add(textField);
        pane.add(button);
    }


    //添加按钮组件到容器中
    private void addButton(Container pane) {

        JButton button = new JButton("按钮1");
        button.addActionListener(e -> {
            System.out.println("按钮被点击了");
        });

//        button.addMouseListener(new MouseAdapter() {
//
//            @Override
//            public void mouseClicked(MouseEvent e) {
//                System.out.println("鼠标被点击了");
//            }
//        });
        pane.add(button);
    }


    // Swing
    @Test
    public void test01(){
        JFrame frame = new JFrame("测试");


        //setter/getter
        frame.setVisible(true);
        frame.setSize(600,400);
        //居中显示
        frame.setLocationRelativeTo(null);


        //拿到内容区； 默认有一个布局：
        Container pane = frame.getContentPane();
        //给内容区中添加组件； 按钮、文本、标签、输入框
        //设置布局
        pane.setLayout(new FlowLayout(FlowLayout.LEFT));

        for (int i = 0; i < 20; i++) {
            JButton button = new JButton("按钮"+i);

            //给按钮添加一个事件监听器；
            button.addActionListener(new ActionListener() {
                /**
                 * 回调函数; 按钮点击以后，这个方法会被自动调用（回调机制）
                 * @param e 当前发生了什么事情的完整信息； JVM自动封装
                 * ActionEvent e = new ActionEvent(事件源,id,...);
                 */
                @Override
                public void actionPerformed(ActionEvent e) {
                    //拿到触发事件的组件； 事件来源
                    JButton source = (JButton) e.getSource();
                    System.out.println("按钮被点击了;"+source.getText());

                    //播放系统声音
                    Toolkit toolkit = Toolkit.getDefaultToolkit();
                    toolkit.beep();
                }
            });

            pane.add(button);
        }


        // 【事件监听】？ 一旦按钮被点击，触发一个行为；
        // 按钮：某个组件身上会发生一些事件；


        sleep();

    }

    public void sleep(){
        //单元测试的时候，要显示东西，不能让测试终止
        try {
            Thread.sleep(10000000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
