import request from '@/utils/request';


/**
 * 发布短剧接口
 * @param data 发布数据
 */
export const publishDramaApi = (data: any) => {
  return request({
    url: '/content/publish',
    method: 'post',
    data
  });
};