import request from '@/utils/request';

/**
 * 文件上传接口
 * @param file 文件对象
 */
export const uploadFile = (file: FormData) => {
  return request({
    url: '/content/upload',
    method: 'post',
    data: file,
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  });
};
