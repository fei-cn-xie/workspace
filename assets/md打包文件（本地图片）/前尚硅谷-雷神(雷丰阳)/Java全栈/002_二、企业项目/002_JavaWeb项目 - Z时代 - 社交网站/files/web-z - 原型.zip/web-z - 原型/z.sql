CREATE TABLE `user` (
    `id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户ID（主键）',
    `username` varchar(50) NOT NULL UNIQUE COMMENT '用户名（唯一）',
    `email` varchar(100) NOT NULL UNIQUE COMMENT '邮箱（唯一）',
    `password` varchar(255) NOT NULL COMMENT '加密后的密码',
    `avatar_url` varchar(255) DEFAULT 'default_avatar.png' COMMENT '头像URL',
    `bio` varchar(200) DEFAULT '' COMMENT '个人简介',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户基础信息表';

CREATE TABLE `tweet` (
    `id` bigint NOT NULL AUTO_INCREMENT COMMENT '推文ID（主键）',
    `user_id` bigint NOT NULL COMMENT '发布用户ID（外键关联user.id）',
    `content` text NOT NULL COMMENT '推文内容',
    `media_urls` varchar(1000) DEFAULT '' COMMENT '媒体资源URL（JSON数组格式）',
    `like_count` int NOT NULL DEFAULT 0 COMMENT '点赞数',
    `comment_count` int NOT NULL DEFAULT 0 COMMENT '评论数',
    `retweet_count` int NOT NULL DEFAULT 0 COMMENT '转发数',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='推文内容表';

CREATE TABLE `comments` (
    `id` bigint NOT NULL AUTO_INCREMENT COMMENT '评论ID（主键）',
    `tweet_id` bigint NOT NULL COMMENT '关联的推文ID（外键关联tweet.id）',
    `user_id` bigint NOT NULL COMMENT '评论用户ID（外键关联user.id）',
    `content` text NOT NULL COMMENT '评论内容',
    `parent_comment_id` bigint COMMENT '父评论ID（NULL表示顶级评论，外键关联comments.id）',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '评论时间',
    PRIMARY KEY (`id`),
    INDEX `idx_tweet_id` (`tweet_id`),
    INDEX `idx_parent_comment_id` (`parent_comment_id`),
    FOREIGN KEY (`tweet_id`) REFERENCES `tweet`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`parent_comment_id`) REFERENCES `comments`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='推文评论及回复表';

CREATE TABLE `notification` (
    `id` bigint NOT NULL AUTO_INCREMENT COMMENT '通知ID（主键）',
    `user_id` bigint NOT NULL COMMENT '接收通知的用户ID（外键关联user.id）',
    `type` enum('like','follow','mention') NOT NULL COMMENT '通知类型（点赞/关注/提及）',
    `source_user_id` bigint NOT NULL COMMENT '触发通知的用户ID（外键关联user.id）',
    `tweet_id` bigint DEFAULT NULL COMMENT '关联的推文ID（外键关联tweet.id）',
    `is_read` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否已读（0未读/1已读）',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '通知时间',
    PRIMARY KEY (`id`),
    FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`source_user_id`) REFERENCES `user`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`tweet_id`) REFERENCES `tweet`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户通知表';

CREATE TABLE `message` (
    `id` bigint NOT NULL AUTO_INCREMENT COMMENT '消息ID（主键）',
    `sender_id` bigint NOT NULL COMMENT '发送方用户ID（外键关联user.id）',
    `receiver_id` bigint NOT NULL COMMENT '接收方用户ID（外键关联user.id）',
    `content` text NOT NULL COMMENT '消息内容',
    `is_read` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否已读（0未读/1已读）',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '发送时间',
    PRIMARY KEY (`id`),
    FOREIGN KEY (`sender_id`) REFERENCES `user`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`receiver_id`) REFERENCES `user`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户私信表';


-- 推文与话题关联表（多对多关系）
CREATE TABLE `tweet_topic` (
    `id` bigint NOT NULL AUTO_INCREMENT COMMENT '关联ID（主键）',
    `tweet_id` bigint NOT NULL COMMENT '推文ID（外键关联tweet.id）',
    `topic_id` bigint NOT NULL COMMENT '话题ID（外键关联topic.id）',
    PRIMARY KEY (`id`),
    INDEX `idx_tweet_id` (`tweet_id`),
    INDEX `idx_topic_id` (`topic_id`),
    FOREIGN KEY (`tweet_id`) REFERENCES `tweet`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`topic_id`) REFERENCES `topic`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='推文与话题关联表';

CREATE TABLE `topic` (
    `id` bigint NOT NULL AUTO_INCREMENT COMMENT '话题ID（主键）',
    `name` varchar(100) NOT NULL UNIQUE COMMENT '话题名称（如#AI设计工具）',
    `tweet_count` int NOT NULL DEFAULT 0 COMMENT '关联的推文数量',
    `hot_score` int NOT NULL DEFAULT 0 COMMENT '热度分数（用于排序）',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '首次出现时间',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='热门话题表';

CREATE TABLE `follow` (
    `id` bigint NOT NULL AUTO_INCREMENT COMMENT '关注关系ID（主键）',
    `follower_id` bigint NOT NULL COMMENT '关注者ID（外键关联user.id）',
    `following_id` bigint NOT NULL COMMENT '被关注者ID（外键关联user.id）',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '关注时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `unique_follow` (`follower_id`, `following_id`),
    FOREIGN KEY (`follower_id`) REFERENCES `user`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`following_id`) REFERENCES `user`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户关注关系表';
