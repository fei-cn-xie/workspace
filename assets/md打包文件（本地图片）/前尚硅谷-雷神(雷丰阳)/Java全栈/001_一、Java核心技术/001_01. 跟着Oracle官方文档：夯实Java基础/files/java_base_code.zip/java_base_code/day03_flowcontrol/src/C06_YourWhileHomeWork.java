import java.util.Random;
import java.util.Scanner;

/**
 * 【自己先做】猜数字：
 * 1、程序获取键盘输入的值（数字）。
 * 2、用户输入的数字和我预先留的数字
 *     1.如果一样，就猜对了，
 *     2.如果不一样就一直猜
 */
public class C06_YourWhileHomeWork {
    public static void main(String[] args) {
        //电脑随机生成一个数字
        //得到一个能执行随机功能的对象
        Random random = new Random();
        // 包含0， 不包含100
        int num = random.nextInt(0,100);

        System.out.println("电脑悄悄生成了一个随机数，你猜！");

        //定义一个扫描仪，能获取到系统的输入
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入你猜的数字：");
        //等你输入东西：从控制台获取到一个输入的数字
        int i = scanner.nextInt();
        while (i != num){
            if(i > num){
                System.out.println("你猜大了，重新猜：");
            }else {
                System.out.println("你猜小了，重新猜：");
            }
            //改变i的值为键盘输入的新东西
            i = scanner.nextInt();
        }
        System.out.println("你终于猜对了");
        
        //TODO 利用while，完成猜数字的游戏

    }
}
