package com.lfy.ch06;

public class Circle extends GraphicObject {


    @Override
    void draw() {
        System.out.println("Circle draw()");
    }

    @Override
    void destroy() {
        System.out.println("Circle destroy()");
    }

    //重写父类方法
    @Override
    public void moveTo(int newX, int newY) {
        super.moveTo(newX, newY);
    }
}
