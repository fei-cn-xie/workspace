package com.lfy.ch05;


import org.junit.Test;

import java.io.*;
import java.util.Scanner;

// 其他流
public class OtherStreamTest {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String text = scanner.nextLine();
        System.out.println("输入的内容是：" + text);
    }

    @Test
    public void test3() throws FileNotFoundException {
        // 重定向字节流； InputStream 里面 能传入一个新的位置流
        System.setIn(new FileInputStream("kubla.txt"));

        Scanner scanner = new Scanner(System.in);
        String text = scanner.nextLine();
        System.out.println("输入的内容是：" + text);
    }

    @Test
    public void test2() throws IOException {


        // 日志在底层就是用（文件追加内容）： new FileOutputStream("outout.txt",true)

        // 重定向字符流； PrintStream 里面 能传入一个新的位置流
        System.setOut(new PrintStream(new FileOutputStream("outout.txt",true)));
        System.out.println("hello");
        System.out.println("hello");
        System.out.println("hello");
        System.out.println("hello");
        System.out.println("hello");


        System.out.println(); // 等同于 fos.flush();
    }

    /**
     * System.out： 标准输出流（默认给控制台输出）
     * System.in： 标准输入流（默认从键盘输入）
     */
    @Test
    public void sysytemTest(){

        PrintStream out = System.out;
        out.println("hello");

        System.out.println("world");
        Scanner scanner = new Scanner(System.in);

        String text = scanner.nextLine();
        System.out.println("输入的内容是：" + text);
    }
}
