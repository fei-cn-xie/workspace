package ch01;

// IDEA：编辑器
// javac 编译器
// 自动导入 某个包下的某个类
import ch01.haha.hehe.*;  // 导入 ch01.haha.hehe 包下所有的类
//import ch01.haha.hehe.C;
//import ch01.haha.hehe.D;

public class A {

    public static void main(String[] args) {
        B b = new B();
        C c = new C();
        D d = new D();
    }
}
