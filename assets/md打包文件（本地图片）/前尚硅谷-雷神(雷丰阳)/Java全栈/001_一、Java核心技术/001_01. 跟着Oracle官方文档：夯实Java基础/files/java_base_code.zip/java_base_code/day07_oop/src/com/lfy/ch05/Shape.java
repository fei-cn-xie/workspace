package com.lfy.ch05;


/**
 * 定义一个接口的实现类
 */
public class Shape implements Drawable, Serialize {

    @Override
    public void draw() {
        System.out.println("正在画 Shape 这种图形....");
    }

    @Override
    public void serialize() {
        System.out.println("正在把 Shape 保存到 D盘");
    }

    public static void main(String[] args) {
        Shape shape = new Shape();

        // 就近原则
        shape.draw();
        shape.serialize();
    }
}
