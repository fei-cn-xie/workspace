package c01;

public class F18Test03 {

    public static void main(String[] args) {
        F18Hornet f18 = new F18Hornet("小屁墩01",4);

        f18.showStatus();




        Person zhangsan = new Person();

        String[] apps =  new String[5];

//        zhangsan.eatApple(apps);
        System.out.println("============");

        String a = "小苹果";
        String b = "小果果";
        // 可变参数必须声明在最后
        zhangsan.eatApple(1,a,a,a,a,a,a);

        new F18Hornet("F001",4);

        
        zhangsan.takeFlight(f18);

        f18.showStatus();

    }
}
