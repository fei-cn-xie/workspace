package com.lfy.ch03;

/**
 * 验证可见性：
 *   可见性： 如果某个线程更改了数据；其他线程最好能看到这个最新值（如果能看到说明具有可见性）
 */
public class VisableTest {

    //volatile：内存可见性修饰符，【强制去主存； 禁用这个变量缓存】
    //  1）哪个变量加了 volatile 修饰符，告诉所有线程，你只要想要这个变量或者修改，都去主内存里面去拿，不要看自己的缓存
    //JMM 内存模型规定。
    private volatile static Integer flag = 1;

    public static void main(String[] args)  throws InterruptedException {
        new Thread(()->{
            System.out.println("我是子线程工作内存flag的值：" + flag);
            while(flag == 1){ //只要flag为1，就空循环
                //啥也不做
            }
            System.out.println("子线程操作结束..." + flag);
        }).start();

        Thread.sleep(500);

        //复制给CPU的缓存里面； 虽然改的是副本，但是主内存一段时间以后（极短）会更新过来（靠数据总线）
        flag = 2;
        System.out.println("我是主线程工作内存flag的值：" + flag);
    }
}
