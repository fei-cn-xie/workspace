package com.lfy.ch01;

public class Outer {
    String outerField = "外部类字段";

    public void method() {
        // 不可变。
        final String name = "局部变量";

        //1、想要用 USB3_0 的实现。
        USB3_0_Imp imp = new USB3_0_Imp();
        imp.fastTransfer();

        //2、想要用 USB3_0 的第二种实现。
        //3、想要用 USB3_0 的第三种实现。
        //4、想要用 USB3_0 的第四种实现。
        //=====以前：需要写 USB3_0 的多个实现类=====

        // 临时自己写一个匿名内部类去来实现 USB3_0 接口。
        USB3_0 usb = new USB3_0(){
            @Override
            public void fastTransfer() {
                System.out.println(name + "匿名内部类实现接口， 传输贼快！");
            }
        };

        usb.fastTransfer();

    }

    public static void main(String[] args) {
        new Outer().method();
    }
}
