package com.lfy.ch04;

public class RuntimeTest {
    public static void main(String[] args) {
        //运行时环境对象
        Runtime runtime = Runtime.getRuntime();


        long l = runtime.freeMemory(); // byte
        System.out.println("空闲内存：" + l/1024/1024 + "MB");

        long totalMemory = runtime.totalMemory();
        System.out.println("总内存：" + totalMemory/1024/1024 + "MB");

        //最大可用内存
        long maxMemory = runtime.maxMemory();
        System.out.println("最大可用内存：" + maxMemory/1024/1024 + "MB");

        // Java应用启动，JVM默认会占用 1/4 的内存； 可以通过 -Xmx 参数调整最大可用内存


    }
}
