package com.lfy.ch02;


/**
 * 程序员自己抛出异常;
 * 总结： 异常3种机制
 * 1、用 try...catch 捕获异常。自己处理
 * 2、声明 throws 抛出异常；让别人想办法
 * 3、手动抛出一个异常。（为了充实业务逻辑）【为了让外界失败】、
 *     除了抛异常能让外界感知失败，还有一种方式是：【利用不同返回值定义业务出现的错误】
 */
public class ThrowTest {

    public static void main(String[] args) {

        int admin222 = login("admin222", "123456111");
        if(admin222 == 0){

        }else if (admin222 == 1){

        } else if (admin222 == -1) {

        }

    }

    public static int login(String username, String password) throws RuntimeException {
        if ("admin".equals(username) && "123456".equals(password)){
            System.out.println("登陆成功");
            return 1;
        }else {
            // 只是内存中创建一个对象。
//            throw new RuntimeException("用户名或密码错误");
            return 0;
        }
    }
}
