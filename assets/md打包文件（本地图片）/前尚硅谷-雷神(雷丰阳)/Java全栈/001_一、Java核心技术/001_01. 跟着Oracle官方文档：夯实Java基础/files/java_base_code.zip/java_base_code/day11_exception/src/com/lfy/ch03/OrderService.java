package com.lfy.ch03;

import com.sun.security.jgss.GSSUtil;

import java.util.Date;

/**
 * 订单服务类：业务
 * 【自定义异常 + 枚举类】 会列举出项目中所有的错误；
 */
public class OrderService {
    public static void main(String[] args) {

        OrderService orderService = new OrderService();

        long l = System.currentTimeMillis() - 30 * 60 * 1000;
        Date date = new Date(l);
        try {
            orderService.payOrder("1233445",date);
        }catch (OrderTimeoutException e){
            e.printStackTrace(); //打印异常栈信息
            Date timeout = e.getTimeout();
            String orderId = e.getOrderId();
            System.out.println("异常信息：【"+e.getMessage()+"】：id：【"+orderId+"】；过期时间：【"+timeout+"】");
        }catch (OrderNotExistException e){
            e.printStackTrace();
            System.out.println("订单号不能为空");
        }


    }

    public void payOrder(String orderId, Date timeout) {
        if (orderId!=null){
            //判断订单是否超时
            Date date = new Date();
            if (timeout.before(date)) {
                throw new OrderTimeoutException("订单已超时",orderId,timeout);
                //代码就结束
            }
            System.out.println("订单支付成功");
        }else {
            throw new OrderNotExistException("订单号不能为空");
        }
    }
}
