package com.lfy.ch04;

public class PriorityDemo {

    public static void main(String[] args) {
        Runnable task1 = () -> {
            for (int i = 0; i < 100; i++) {
                System.out.println(Thread.currentThread().getName() + ": " + i);
                Thread.yield(); // 主动让出CPU
            }
        };
        Runnable task2 = () -> {
            for (int i = 0; i < 100; i++) {
                System.out.println(Thread.currentThread().getName() + ": " + i);
                Thread.yield(); // 主动让出CPU
            }
        };
        Thread t1 = new Thread(task1, "高优先级");
        Thread t2 = new Thread(task2, "低优先级");


        // 设置优先级
        t1.setPriority(Thread.MAX_PRIORITY); // 10  5//中优先级
        t2.setPriority(Thread.MIN_PRIORITY); // 1


        // 优先级不是绝对; 无任何演示效果(看底层操作系统)
        t2.start(); // 先启动低优先级的线程
        t1.start(); // 再启动高优先级的线程

    }
}
