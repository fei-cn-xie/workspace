package com.lfy.ch04;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

public class SystemTest {
    public static void main(String[] args) {
        //获取当前环境变量
        Map<String, String> getenv = System.getenv();
        System.out.println(getenv);


        // 设置环境变量
        Map<String, String> env = System.getenv();
//        env.put("JAVA_HOME", "D:\\Java\\jdk1.8");
        System.out.println(System.getenv());



//        //设置当前环境变量
//        SpringApplication.builder()
//                .environment(env)
//                .properties("spring.profiles.active:dev")
//                .sources(Application.class)
//                .run(args);

        //获取当前系统属性
        Properties properties = System.getProperties();

        Object o = properties.get("java.version");
        Object o1 = properties.get("java.home");
        Object o2 = properties.get("os.name");
        System.out.println(o);
        System.out.println(o1);
        System.out.println(o2);


        LinkedList<String> list = new LinkedList<>();


    }


}
