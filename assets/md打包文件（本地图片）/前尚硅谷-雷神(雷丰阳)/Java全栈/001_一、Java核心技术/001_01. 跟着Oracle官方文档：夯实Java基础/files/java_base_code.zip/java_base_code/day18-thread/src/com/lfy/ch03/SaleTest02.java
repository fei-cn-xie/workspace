package com.lfy.ch03;

import java.util.ArrayList;

public class SaleTest02 {

    public static void main(String[] args) {
        //1、只 new 了一个对象， SaleTicketV2 里面的 ticketNum 只有一个；
        SaleTicketV2 saleV2 = new SaleTicketV2();


//        Runnable runnable = ArrayList::new; // 相当于 new ArrayList();


        //Java8 新特性
        // 对象::方法引用
        // 类::静态引用
        new Thread(saleV2::sale,"窗口1").start();

        new Thread(saleV2::sale,"窗口2").start();

        new Thread(saleV2::sale,"窗口3").start();



    }
}
