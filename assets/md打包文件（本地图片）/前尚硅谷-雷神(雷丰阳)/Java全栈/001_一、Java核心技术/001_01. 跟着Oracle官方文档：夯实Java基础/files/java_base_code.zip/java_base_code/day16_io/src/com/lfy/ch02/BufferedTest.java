package com.lfy.ch02;

import org.junit.Test;

import java.io.*;

public class BufferedTest {

    @Test  // 423 ms
    public void bufferZeiBufQuick() throws IOException {
        long start = System.currentTimeMillis();
        FileInputStream fis = new FileInputStream("C:\\Users\\53409\\Desktop\\java_all_in\\视频\\day15 - IO流\\视频\\8、Java基础 - IO流 - 小练习：视频加解密.mp4");
        FileOutputStream fos = new FileOutputStream("C:\\Users\\53409\\Desktop\\hello.mp4");



        // 带缓冲区的 FileInputStream 和 FileOutputStream
        BufferedInputStream bis = new BufferedInputStream(fis);
        BufferedOutputStream bos = new BufferedOutputStream(fos);


        byte[] bytes = new byte[100]; // byte 就可以忽略大小了。多大都是交互内存；

        int len; // NIO（IO多路复用[后来讲]）：三大件：Channel、Buffer、Selector
        while((len = bis.read(bytes))!=-1){
            bos.write(bytes,0,len);
        };

        // 不用关闭原始流、
//        fis.close();
//        fos.close();


        // 关闭缓冲区流，会自动关闭原始流（缓冲区流是对原始流的一个包装类）
        bis.close();
        bos.close();


        long end = System.currentTimeMillis();
        System.out.println("耗时：" + (end - start));
    }

    @Test // 8161 ms
    public void bufferZeiQuick() throws IOException {
        long start = System.currentTimeMillis();
        FileInputStream fis = new FileInputStream("C:\\Users\\53409\\Desktop\\java_all_in\\视频\\day15 - IO流\\视频\\8、Java基础 - IO流 - 小练习：视频加解密.mp4");


        FileOutputStream fos = new FileOutputStream("C:\\Users\\53409\\Desktop\\hello.mp4");

        byte[] bytes = new byte[100];

        int len;
        while((len = fis.read(bytes))!=-1){
            fos.write(bytes,0,len);
        };

        fis.close();
        fos.close();
        long end = System.currentTimeMillis();
        System.out.println("耗时：" + (end - start));
    }


    @Test
    public void test01() throws IOException {
        //1、定义一个BufferedInputStream对象的时候
        FileInputStream fis = new FileInputStream("kubla.txt");

        //2、加了 buf 的 FileInputStream
        BufferedInputStream bis = new BufferedInputStream(fis);

        //3、读取数据
        byte[] bytes = new byte[1024];
        int len;

        // bis.read(bytes) 这次读 是操作的内存缓冲区
        // fis.read(bytes) 这次读 是操作的磁盘文件
        while ((len = bis.read(bytes)) != -1) {
            System.out.write(bytes, 0, len);
        }


    }
}
