package com.lfy.ch0;

public class Person {

    //成员变量：属性
    String name;
    int age;

    //构造器
    public Person(){

    }


    //方法
    // 方法返回值：
    //1、方法正常执行完成：
    //   1)、直接结束,无返回值：void
    //   2)、返回一个结果：int、double、String、数组、对象等
    //2、方法执行出现问题：
    public void eat() {
        System.out.println("吃饭");
    }

    public void sleep() {
        System.out.println("睡觉");
    }

    public int addNum(int a,int b){
        int c = a / b;
        return c; //最希望
    }

    public Person getMyFriend(){
        //引用类型的返回值，返回一个对象
        return new Person();
    }
}
