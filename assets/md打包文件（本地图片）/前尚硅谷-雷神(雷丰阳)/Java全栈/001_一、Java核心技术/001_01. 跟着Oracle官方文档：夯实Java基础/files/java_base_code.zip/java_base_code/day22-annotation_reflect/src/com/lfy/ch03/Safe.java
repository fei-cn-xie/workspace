package com.lfy.ch03;

public interface Safe<T> {

    T safe();
}
