package c01;

public class Person {

    //1、属性
    String name;
    int age;
    String phoneNum;

    //2、构造器
    public Person(){

    }



    //1、只能传3个苹果的名字
    public void eatApple(String a1,String a2,String a3){

    }

    //2、可以使用数组，接受多个值
//    public void eatApple(String[] apps){
//
//    }

    //3、可以使用可变参数(底层是数组，简写方式)
    public void eatApple(int b,String... a){
        System.out.println("传来了 "+ a.length +" 个参数");
    }


    //开飞机; 引用类型传递的地址。可能会导致 一修改 全改了。
    public void takeFlight(F18Hornet f){



        System.out.println("我正在开【"+f.callSign+"】飞机");
        f.callSign = "飞飞飞01";
    }

    //3、方法
    public void walk(){
        System.out.println(name+"：正在走路...");
    }

    public void eat(){
        System.out.println(name+"：正在吃饭...");
    }
}
