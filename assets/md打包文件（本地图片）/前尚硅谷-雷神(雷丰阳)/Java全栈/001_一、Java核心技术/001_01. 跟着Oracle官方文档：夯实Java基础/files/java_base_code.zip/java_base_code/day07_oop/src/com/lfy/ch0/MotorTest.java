package com.lfy.ch0;

public class MotorTest {

    public static void main(String[] args) {
        Motor motor = new Motor(100);
        motor.run();
    }
}
