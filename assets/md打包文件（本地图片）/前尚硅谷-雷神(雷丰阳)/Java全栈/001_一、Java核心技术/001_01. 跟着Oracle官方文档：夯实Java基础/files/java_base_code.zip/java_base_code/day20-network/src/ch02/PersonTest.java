package ch02;

import org.openjdk.jol.info.ClassLayout;

public class PersonTest {

    public static void main(String[] args) throws InterruptedException {
        Person person = new Person("Tom",12);

        //引用 jol： Java Object Layout（Java对象布局）


        //1、打印对象在内存中的布局信息
        String printable = ClassLayout.parseInstance(person).toPrintable();
        System.out.println(printable); // 01

        Thread thread = new Thread(() -> {
            person.sayHello();  // 00
        });

        thread.start();

        thread.join();

        String printable1 = ClassLayout.parseInstance(person).toPrintable(); // 01
        System.out.println(printable1);


    }
}
