package com.lfy.ch02;

import com.lfy.ch1.Hello;

public class HelloHaha extends Hello {

    public void abc(){
        System.out.println("父类的name："+name);
    }

    public static void main(String[] args) {
        HelloHaha helloHaha = new HelloHaha();

        helloHaha.abc();
    }
}
