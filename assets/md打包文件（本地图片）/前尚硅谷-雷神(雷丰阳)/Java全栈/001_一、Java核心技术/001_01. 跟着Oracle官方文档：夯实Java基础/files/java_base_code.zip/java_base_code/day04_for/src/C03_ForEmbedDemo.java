/**
 * 循环嵌套
 */
public class C03_ForEmbedDemo {

    public static void main(String[] args) {


        //双层For
        String[][] arr = {
                {"1","2","3","4"},
                {"5","6"},
                {"11","22","33","44","66"}
        };

        //1、打印货架的长度
        System.out.println( arr.length );
        for (int i = 0; i < arr.length; i++) {
            //是拿到每一层货架  i = 0   i=1  i=2
            System.out.println("本层货架的长度：" +  arr[i].length);
//            arr[i] //代表这层货架
            //内层的完全结束，才会跳出到外层，外层开始下一次循环
            for (int j = 0; j < arr[i].length; j++) {
                // j = 0 ~ 4 arr[0]
                // j = 0 ~ 2 arr[1]
                // j = 0 ~ 5 arr[2]
                System.out.println( arr[i][j] );
            }
        }





        System.out.println("==============");

        for (int i = 0; i < arr[0].length; i++) {
            System.out.println(arr[0][i]);
        }

        for (int i = 0; i < arr[1].length; i++) {
            System.out.println(arr[1][i]);
        }

        for (int i = 0; i < arr[2].length; i++) {
            System.out.println(arr[2][i]);
        }




    }
}
