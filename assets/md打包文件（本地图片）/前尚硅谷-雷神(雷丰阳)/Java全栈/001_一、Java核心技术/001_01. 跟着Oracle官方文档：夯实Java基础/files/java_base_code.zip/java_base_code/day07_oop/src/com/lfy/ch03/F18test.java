package com.lfy.ch03;

public class F18test {

    public static void main(String[] args) {

        //默认 成员（变量，方法）都是 【对象.成员】
//        F18 f18 = new F18();
//        f18.missiles--;
//        f18.fire();
//        System.out.println("=========");
//
//
//
//        System.out.println("=========");


        // 类成员。不用new对象也能



        F18 f18 = new F18();
        F18 f182 = new F18();
        F18 f183 = new F18();
        F18 f184 = new F18();


        f18.summary();
        f182.summary();
        f183.summary();
        f184.summary();

        F18.summary();

    }
}
