package com.lfy.ch01;

public class Hello {

    public static void main(String[] args) {
        //静态
        Person.Phone phone = new Person.Phone();


        //非静态的
        Person.Card person = new Person().new Card();





    }
}
