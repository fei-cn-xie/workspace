package com.lfy.ch04;

public class ThreadInterruptTest {


    public static void main(String[] args) throws InterruptedException {
        System.out.println("main start");
        Thread thread = new Thread(()->{
            for (int i = 0; i < 10; i++) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("i = " + i);
            }
        });

        thread.start();


        Thread.sleep(2000);
        System.out.println("准备打断 thread 的执行");

        //中断
        thread.interrupt(); //只是发出一个中断信号。 不是立即就能中断

        System.out.println("main end");

    }

}


class PrinterRunnable implements Runnable{

    @Override
    public void run() {

    }
}