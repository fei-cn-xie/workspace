package com.lfy.ch02;

public enum Calculator implements Operation {

    ADD {
        @Override
        public int compute(int a, int b) {
            return a+b;
        }
    },

    SUBTRACT {
        @Override
        public int compute(int a, int b) {
            return a-b;
        }
    },

    MULTIPLY {
        @Override
        public int compute(int a, int b) {
            return a*b;
        }
    },

    DIVIDE {
        @Override
        public int compute(int a, int b) {
            return a/b;
        }
    };


}
