/**
 * return程序返回，就代表结束了
 */
public class C07_ReturnDemo {

    public static void main(String[] args) {
        System.out.println("开始");
        for (int i = 0; i < 5; i++) {
            if( i == 3){
                //分支的中断控制 break/continue/return
                return; //代表这个方法完全退出结束
            }
            System.out.println(i);
        }
        System.out.println("结束");
    }
}
