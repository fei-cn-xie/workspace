package com.lfy.ch02;

// 老项目 8-17；  新项目：23
// 把自己的idea调整为jdk 21
// 【idea版本问题】idea最高支持到21， 现在用23，导致lombok没有生效。
// idea 没配置好。后面直接是用用maven构建项目。
// idea 编译代码的时候，没用启用lombok插件，导致编译不通过。
// SpringBoot 新版的 lombok 不是一个问题； Maven管理问题。
// org.projectlombok:lombok:1.18.38
public class CarTest {

    public static void main(String[] args) {
        Car car = new Car();
        car.getBrand();

        System.out.println("car到底有几个属性");
        System.out.println("car到底有几个方法");
        System.out.println("car到底有几个构造器");
        System.out.println("car到底有几个注解");
        System.out.println("car到底实现有几个接口");
        System.out.println("car到底继承了几个类");

        Car car1 = new Car("宝马", "红色", 100_000, "宝马3系");
        System.out.println(car1);

//        car.setBrand("宝马");
//        String brand = car.getBrand();
//        System.out.println("品牌是：" + brand);

    }
}
