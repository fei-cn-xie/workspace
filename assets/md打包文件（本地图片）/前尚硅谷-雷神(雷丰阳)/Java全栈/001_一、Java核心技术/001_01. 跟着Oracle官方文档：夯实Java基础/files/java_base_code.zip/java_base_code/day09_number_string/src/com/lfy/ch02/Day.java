package com.lfy.ch02;


/**
 * 枚举类：
 * 1. 列举有限的常量
 */
public enum Day {

    //1、列出了所有的可能性; Java在底层帮你已经创建好了Day 的 7个对象；
    //2、别人不能在创建更多的对象; 枚举类型不能被实例化


    //序号默认从0开始；
    MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY,SATURDAY,SUNDAY;

}
