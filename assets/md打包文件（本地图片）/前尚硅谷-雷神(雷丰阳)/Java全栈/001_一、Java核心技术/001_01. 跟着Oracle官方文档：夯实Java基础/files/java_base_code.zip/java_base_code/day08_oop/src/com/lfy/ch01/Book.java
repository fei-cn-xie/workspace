package com.lfy.ch01;


/**
 * JavaBean：封装数据的Bean类
 */
public class Book {
    private String name;
    private String author;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
}
