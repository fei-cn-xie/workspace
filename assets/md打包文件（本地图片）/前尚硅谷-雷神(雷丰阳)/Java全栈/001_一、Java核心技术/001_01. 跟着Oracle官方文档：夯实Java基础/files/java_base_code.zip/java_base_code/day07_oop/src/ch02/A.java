package ch02;

import com.lfy.ch1.Hello;

// src： 代码的根文件夹
// 某个包下继续创建包： ch01.haha.hehe
public class A {

    public static void main(String[] args) {
        Hello hello = new Hello();

//        hello.haha();
    }
}
