package com.lfy.ch07;

public class BirdX implements Fly8{
    @Override
    public void fly() {
        System.out.println("BirdX 正在飞行...");
    }
}
