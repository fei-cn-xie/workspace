package com.lfy.ch02;


/**
 * 支付场景：
 *    Alipay：
 *    Wechatpay：
 *    Unionpay：
 * 枚举是支付方式，业务是支付逻辑。
 */
public class CalculatorTest {

    public static void main(String[] args) {
        Calculator add = Calculator.ADD;



        int compute = add.compute(1, 2);
        System.out.println(compute);


        Calculator multiply = Calculator.MULTIPLY;
        int compute1 = multiply.compute(2, 3);
        System.out.println(compute1);
    }
}
