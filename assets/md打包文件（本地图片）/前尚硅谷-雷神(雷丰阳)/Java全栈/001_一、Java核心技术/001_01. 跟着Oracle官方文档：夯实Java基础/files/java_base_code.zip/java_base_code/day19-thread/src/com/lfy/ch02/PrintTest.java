package com.lfy.ch02;

public class PrintTest {

    public static void main(String[] args) {
        PrinterEach printerEach = new PrinterEach();


        //打印数字
        new Thread(()->{
            for (int i = 0; i < 26; i++) {
                printerEach.printNum();
            }
        }).start();

        //打印字母
        new Thread(()->{
            for (int i = 0; i < 26; i++) {
                printerEach.printChar();
            }
        }).start();

    }
}
