package com.lfy.ch02;

import com.lfy.ch03.Animal;

public class Cat extends Animal {

    public Cat() {

    }
}
