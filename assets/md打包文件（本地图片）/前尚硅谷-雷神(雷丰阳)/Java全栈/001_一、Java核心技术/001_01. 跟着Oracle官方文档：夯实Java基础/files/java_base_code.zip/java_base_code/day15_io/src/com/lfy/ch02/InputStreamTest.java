package com.lfy.ch02;

import org.junit.Test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * 测试 InputStream： 字节输入流，可读万物；
 */
public class InputStreamTest {

    @Test
    public void testIs4()  throws IOException{
        byte[] bytesX = new byte[10];
        for (Object b:bytesX){
            System.out.println(b);
        }

        System.out.println("=========================");
        //1、拿到文件输入流对象
        InputStream is = new FileInputStream("kubla .txt");

        //桶只有一个，来回复用；
        byte[] bytes = new byte[10]; //一次读取10个字节

        int size = 0;
        while ( (size = is.read(bytes)) != -1){
            System.out.println("这次读了：" + size + "个字节");
            //创建字符串的时候，一定要知道 此次桶里面装个多少字节，否则会报错
            String s = new String(bytes,0,size);

            System.out.println(s);
        }

        is.close();
    }

    @Test
    public void testIs3() throws IOException {
        //1、拿到文件输入流对象
        InputStream is = new FileInputStream("kubla .txt");

        //2、读取数据
        byte[] bytes = new byte[100]; //一次读取10个字节

        // 返回的是读取的字节个数
        int read = is.read(bytes);
        System.out.println(read);


        // 有可能最后一次 这个桶 没有装满
        read = is.read(bytes);
        System.out.println(read);




        //关流
        is.close();
    }


    @Test
    public void testIs2() throws IOException {
        InputStream is = new FileInputStream("kubla .txt");


        //1、读到所有数据
        int data = 0;
        while((data = is.read())!=-1){
//            一直读取数据，直到文件末尾
            System.out.print((char) data);
        };

    }

    @Test
    public void testIs() throws IOException {
        InputStream is = new FileInputStream("kubla .txt");


        //1、从文件中读取数据
        // 一次读取一个字节；
        // 返回值：int类型，读取到的数据；如果返回-1表示文件末尾
        int read = is.read();
        System.out.println((char)read);
        read = is.read();
        System.out.println((char)read);
        read = is.read();
        System.out.println((char)read);
        read = is.read();
        System.out.println((char)read);
        read = is.read();
        System.out.println((char)read);
        read = is.read();
        System.out.println((char)read);

    }
}
