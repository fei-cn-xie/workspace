package com.lfy.ch08;

public class ChildX extends ParentX {

    static {
        System.out.println("ChildX 静态代码块执行...");
    }

    {
        System.out.println("ChildX 动态代码块执行...");
    }

    public ChildX() {
        System.out.println("ChildX 构造方法执行...");
    }
}
