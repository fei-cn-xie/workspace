package com.lfy.ch01;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * 编译时异常：受检异常； 必须处理掉这个异常
 *   1)、FileNotFoundException： 文件没找到异常
 *   2)、UnknownHostException： 域名找不到异常
 */
public class Exception2Test {

    public static void main(String[] args) {
        new Exception2Test().a();
    }

    public void a(){
        //1、读取磁盘文件; 编译器觉得未来肯定会出错，所以编译时就会报错
        try {
            new FileInputStream("c://abc.txt");
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

    }
}
