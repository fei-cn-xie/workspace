package com.lfy.ch04;

public class MathTes {
    public static void main(String[] args) {
//        - double ceil(double d) : 大于他的最小值；- floor(-x)。 12.18
//        - double floor(double d) : 向下取整。 12
//        - double rint(double d) : 最接近的整数。
//        -  Math.round(12.48)： 四舍五入


        //  -Math.floor(-x)  -12.18  -13   13
        double ceil = Math.ceil(12.18); //13
        System.out.println(ceil);

        double floor = Math.floor(12.18); // 12.0
        System.out.println(floor);

        double rint = Math.rint(12.98);// 12.0
        System.out.println(rint);


        long round = Math.round(12.48);
        System.out.println(round);


        // 即使用 Math 来做数学运算，丢失精度；
        double a = 0.09;
        System.out.println(a);


    }
}
