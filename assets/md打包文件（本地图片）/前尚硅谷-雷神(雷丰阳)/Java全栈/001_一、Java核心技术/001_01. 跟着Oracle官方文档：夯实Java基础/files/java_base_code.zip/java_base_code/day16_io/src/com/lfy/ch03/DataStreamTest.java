package com.lfy.ch03;


import org.junit.Test;

import java.io.*;

// 了解
// BufferedStream(包装流)： 包装原始的字节流，提高效率
// DataStream(包装流)： 包装原始的数据流
public class DataStreamTest {





    @Test
    public void testReadDs() throws IOException {
        DataInputStream ds = new DataInputStream(new FileInputStream("data.txt"));


        boolean b = ds.readBoolean();
        byte b1 = ds.readByte();
        char c = ds.readChar();
        double d = ds.readDouble();
        float f = ds.readFloat();
        int i = ds.readInt();
        long l = ds.readLong();
        short s = ds.readShort();
        String str = ds.readUTF();

        System.out.println(b);
        System.out.println(b1);
        System.out.println(c);
        System.out.println(d);
        System.out.println(f);
        System.out.println(i);
        System.out.println(l);
        System.out.println(s);
        System.out.println(str);

        ds.close();


    }


    @Test
    public void testDs() throws IOException {

        DataOutputStream ds = new DataOutputStream(new FileOutputStream("data.txt"));


        ds.writeBoolean(true);
        ds.writeByte(99);
        ds.writeChar('a');
        ds.writeDouble(3.14);
        ds.writeFloat(3.14f);
        ds.writeInt(1234567890);
        ds.writeLong(1234567890L);
        ds.writeShort((short) 12345);
        ds.writeUTF("Hello");




        ds.close();



    }
}
