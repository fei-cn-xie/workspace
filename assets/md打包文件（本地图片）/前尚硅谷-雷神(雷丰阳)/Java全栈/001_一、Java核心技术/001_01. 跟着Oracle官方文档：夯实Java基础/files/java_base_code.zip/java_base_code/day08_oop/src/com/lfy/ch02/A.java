package com.lfy.ch02;

public class A extends B{
}
