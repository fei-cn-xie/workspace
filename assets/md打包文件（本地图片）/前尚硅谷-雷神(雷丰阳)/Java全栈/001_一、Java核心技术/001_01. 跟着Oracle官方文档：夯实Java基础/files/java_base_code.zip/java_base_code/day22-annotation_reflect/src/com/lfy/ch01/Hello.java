package com.lfy.ch01;


/**
 * interface：定义接口
 * @interface：定义注解
 *
 * 总结：
 * 1、创建一个注解 @interface 你的注解名
 * 2、关注这几点
 *      1. 注解标注在哪里：@Target
 *      2. 注解什么时候生效：@Retention
 * 3、注解自带哪些属性
 *      1. 默认value属性
 *      2. 每个属性还可以有默认值
 *      3. 没有默认值，就需要标注注解的时候手动赋值
 *
 * 自定义会写就行/会标。后来结合 Spring AOP 可以实现自定义功能
 * lombok：简化JavaBean开发
 */

//@Override
@Leifengyang(date = "2019-03-01",age = 18)
public class Hello {


    @Leifengyang(value = false, age = 0) // false 默认对应value属性的值
    private String name;



    //
    public Hello() {
        String[] value = {"abc","def"};
    }



    //权限检查思路：
    // 运行方法之前，看一下这个方法，有没有标注定义的权限注解
    //  1、如果标了，判断是哪个注解 @Admin @Anyone
    //  2、如果没标，无需权限控制

//    @Admin
    @Leifengyang(age = 0)
    public void sayHello(@Leifengyang(age = 0) String msg) {

        System.out.println("Hello, world!");
    }


//    @Anyone
    public void sayHello2() {

        System.out.println("Hello, world!");
    }
}
