package com.lfy.ch04;

import com.lfy.Student;
import com.lfy.ch05.LogUtils;
import org.junit.Test;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

// 测试对象流
public class ObjectStreamTest {



    // 网络传输数据如何传输的？ RPC： 远程过程调用；


    @Test
    public void test() throws IOException, ClassNotFoundException {
        // 序列化： 把内存中的对象保存到磁盘文件中；
        // 反序列化： 把磁盘文件中的数据读取到内存中。  把对象怎么表示成文件
        List<Student> students = new ArrayList<>();
        students.add(new Student("张三1", 23,true));
        LogUtils.log("保存了张三1");


        students.add(new Student("张三2", 20,false));
        LogUtils.log("保存了张三2");


        students.add(new Student("张三3", 21,true));
        LogUtils.log("保存了张三3");


        students.add(new Student("张三4", 33,false));
        LogUtils.log("保存了张三4");


        students.add(new Student("张三5", 18,true));
        LogUtils.log("保存了张三5");


        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("studentsList.ser"));

        oos.writeObject(students);

        oos.close();

        LogUtils.logError("上面没有关闭流资源，导致文件损坏。", new NullPointerException());

        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("studentsList.ser"));

        // 读取对象；
        List<Student>  list = (List<Student>) ois.readObject();

        System.out.println(list);
        LogUtils.logError("上面打印太多东西，太乱了", new RuntimeException());

        ois.close();

    }

    // poke游戏； 三个人： 手里一堆牌；


    // 反序列化； 把磁盘文件中的对象读取到内存中。
    @Test
    public void readStudent() throws Exception {
        //1、定义一个对象输入流，包装原始的文件字节输入流
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("student.ser"));

        //2、读取对象
        Student o = (Student) ois.readObject();

        System.out.println(o);

        //3、关闭资源； 只需要关最外层的包装流
        ois.close();
    }



    // 写出一个对象到磁盘；  内存对象 =》 磁盘文件； 序列化；
    @Test
    public void writeStudent() throws IOException {
        //1、定义一个对象输出流，包装原始的文件字节流
        ObjectOutputStream objectOs = new ObjectOutputStream(new FileOutputStream("student.ser"));
        Student zhangsan = new Student("张三1", 23, true);



        objectOs.writeObject(zhangsan);

        //2、关闭资源； 只需要关最外层的包装流
        objectOs.close();

    }

    @Test
    public void testWriteObj(){
        //1、有5个学生
        List<Student> students = new ArrayList<>();

        students.add(new Student("张三1", 23,true));
        students.add(new Student("张三2", 20,false));
        students.add(new Student("张三3", 21,true));
        students.add(new Student("张三4", 33,false));
        students.add(new Student("张三5", 18,true));


        // 程序运行过程中； 断电； new 的东西都在内存。
        // 需求：
        //   内存对象 =》 磁盘文件； 序列化；     1、 把内存中的数据持久化到磁盘（持久化设备）上；
        //   磁盘文件 =》 内存对象； 反序列化     2、 下次程序启动的时候，可以从磁盘上读取数据；恢复到内存中。
        //
    }
}
