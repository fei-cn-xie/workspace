package com.lfy.ch02;


/**
 * 资源类：把资源和对资源的操作封装到一起； OOP：封装性；
 * @author 53409
 */
public class PrinterEach {

    private int num = 0; // num = 1;
    private char ch = 'a'; // ascii码表

    // flag = 1; 打印数字；
    // flag = 2; 打印字符；
    private int flag = 1;

    public void printNum(){
        synchronized (this){
            //1、判断，不该打印数字，就等待
            while(flag != 1){
                try {
                    this.wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }

            //2、打印数字
            System.out.print(num++);
            flag = 2; // 修改标志位，让其他线程人知道该打印字母了
            //3、通知其他线程
            this.notifyAll();
        }

    }

    public void printChar(){
        synchronized (this){
            //1、判断，不该打印字符，就等待
            while (flag != 2){
                try {
                    this.wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            //2、打印字符
            System.out.print(ch++);

            flag = 1; // 修改标志位，让其他线程人知道该打印数字了
            //3、通知其他线程
            this.notifyAll();
        }

    }

}
