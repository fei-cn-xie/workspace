package com.lfy.ch01;


/**
 * String 不可变原理
 */
public class StringTest2 {

    public static void main(String[] args) {
        //1、产生了几个对象？ new String（）内部的value指向常量池中的"雷丰阳"；
        String s1 = new String("雷丰阳");
        //2、产生了几个对象？
        String s2 = new String("雷丰阳");

        //3、产生几个对象？ 总计3个

        //内存地址不同
        System.out.println(s1 == s2); // 1：false   2：true

        //4、常量池中只有一个对象（s1.intern() 拿到在常量池里面的东西）
        System.out.println(s1.intern() == s2.intern());


        // 字符串特殊处理，在常量池中真正有这个字符串


        String s3 = "雷丰阳Hello";
        String s4 = "雷丰阳Hello";
        System.out.println(s3 == s4); // true； 指向常量池同一个位置


        //我们声明常量
        final int a = 1;

    }
}
