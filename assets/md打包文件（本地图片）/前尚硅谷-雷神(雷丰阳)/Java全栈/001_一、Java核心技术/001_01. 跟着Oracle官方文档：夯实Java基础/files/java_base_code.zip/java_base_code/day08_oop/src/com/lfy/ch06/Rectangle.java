package com.lfy.ch06;

public class Rectangle extends GraphicObject{

    @Override
    void draw() {

    }

    @Override
    void destroy() {

    }
}
