package com.lfy.ch01;


import java.lang.annotation.*;

/**
 * 自定义注解
 * 限定：
 * 元注解； 定义注解的【元数据】
 *
 * 【元数据（描述数据的数据）】：例子
 *    1：元信息【修饰数据的数据】；自然数、大于0、奇数
 *    雷丰阳： 元信息：男、35、程序员....
 *
 *
 * @Target(value = ElementType.METHOD)： 指定可以标在哪里
 *      ElementType.METHOD： 方法上
 *      ElementType.FIELD： 属性上
 *      ElementType.TYPE： 类上
 *      ElementType.PARAMETER： 参数上
 *      ElementType.CONSTRUCTOR： 构造器上
 *
 * @Retention: 指定注解的生命周期（什么时候能用[生效]）  ctrl+f9：触发重新编译
 *      SOURCE： 只存在于源代码中； 编译阶段丢弃; .class 中看不到
 *      CLASS： 只存在于class文件中； 编译阶段保留; 运行时（代码正在跑的时候）拿不到
 *      RUNTIME： 运行时可通过反射读取到；编译、运行阶段都保留； 反射。
 *
 *
 * @Douyinzhibo
 * 使用场景： 权限控制
 */

//@Repeatable(MyAnnotations.class) // 允许一个元素上多次标注该注解
@Inherited // 让子类继承父类的注解
@Documented //为项目生成文档
@Target(value = {ElementType.METHOD, ElementType.FIELD, ElementType.TYPE, ElementType.PARAMETER})
@Retention(value = RetentionPolicy.RUNTIME) // 后来最多使用
public @interface Leifengyang {


    //默认属性
    boolean value() default true;
    boolean isMan() default true;
    //属性； 定义接口方法
    String date() default "2023-11-15";
    int age(); // 没有默认值的属性，标注注解的时候，就必须赋值



}
