package com.lfy.ch07;

public abstract class AbstractFly implements Fly{
    @Override
    public void flyOnLand() {
        System.out.println("在陆地上飞");
        fly();
    }

    @Override
    public void flyInSky() {
        System.out.println("在天空中飞");
        fly();
    }

    @Override
    public void flyInSpace() {
        System.out.println("在太空中飞");
        fly();
    }


    //留给子类实现
    abstract void fly();
}
