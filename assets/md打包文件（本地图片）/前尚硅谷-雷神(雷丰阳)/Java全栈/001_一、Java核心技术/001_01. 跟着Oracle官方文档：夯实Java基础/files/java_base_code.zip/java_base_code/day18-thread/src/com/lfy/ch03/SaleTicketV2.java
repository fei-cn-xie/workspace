package com.lfy.ch03;


/**
 * 卖票程序 V2: 既没有继承 Thread 类，也没有实现 Runnable 接口
 * POJO：普通的Java对象
 *
 * 【解耦】：解除和其他代码的耦合性（关联性）
 * 资源类（体现封装性）：对资源本身的封装（ticketNum） 和 对资源操作的封装（sale） 都在一个类中。
 */
public class SaleTicketV2 {

    private int ticketNum = 100; //实例变量，跟着对象走



    // 业务功能
    public void sale(){
        while (ticketNum > 0){
            System.out.println(Thread.currentThread().getName() + " 卖出一张，剩余：" + --ticketNum);
        }
    }
}
