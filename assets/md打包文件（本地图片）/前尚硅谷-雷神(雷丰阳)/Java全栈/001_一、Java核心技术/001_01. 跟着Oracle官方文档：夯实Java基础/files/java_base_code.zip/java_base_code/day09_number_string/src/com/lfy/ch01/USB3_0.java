package com.lfy.ch01;

public interface USB3_0 {

    void fastTransfer();
}
