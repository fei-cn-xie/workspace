package com.lfy.ch10;

public interface UPhone3_0 {

    void call();
}
