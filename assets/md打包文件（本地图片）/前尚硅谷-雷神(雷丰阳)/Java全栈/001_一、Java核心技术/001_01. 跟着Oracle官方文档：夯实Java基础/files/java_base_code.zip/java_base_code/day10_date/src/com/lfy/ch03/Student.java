package com.lfy.ch03;

public class Student implements Comparable<Student> {

    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Student(String name, int age){
        this.name=name;
        this.age=age;
    }
    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }


    // 自己指定如何排序：
    // >0: 当前对象 > 参数对象
    // =0: 当前对象 = 参数对象
    // <0: 当前对象 < 参数对象
    @Override
    public int compareTo(Student o) {
        // 按年龄升序排列

        ; //this.age - o.age >0 =0 <0； 升序排列
          //o.age - this.age; //降序排列
        return o.age - this.age;
    }
}
