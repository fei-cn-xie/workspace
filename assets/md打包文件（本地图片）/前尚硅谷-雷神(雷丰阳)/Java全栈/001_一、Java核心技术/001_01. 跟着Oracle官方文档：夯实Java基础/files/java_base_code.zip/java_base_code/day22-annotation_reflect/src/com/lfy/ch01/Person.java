package com.lfy.ch01;

import java.util.Objects;


/**
 * 专门用来 封装个人信息 数据的类；
 * JavaBean： 小豆子
 * POJO： Plain Old Java Object; 简单老旧的Java对象；
 *
 * lombok： 自动生成 getter/setter/toString/equals/hashCode 等方法；
 */
public class Person {

    private String name;
    private int age;
    private boolean isMale;


    // 下面的东西都是模板化的....
    //无参构造器 alt+ (fn) + insert
    public Person() {
    }


    //全参构造器
    public Person(String name, int age, boolean isMale) {
        this.name = name;
        this.age = age;
        this.isMale = isMale;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean isMale() {
        return isMale;
    }

    public void setMale(boolean male) {
        isMale = male;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", isMale=" + isMale +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Person person)) return false;
        return getAge() == person.getAge() && isMale() == person.isMale() && Objects.equals(getName(), person.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName(), getAge(), isMale());
    }
}
