package com.lfy.ch03;

import org.junit.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class FilesTest {


    /**
     * E盘的所有目录文件都打印出来
     * @throws IOException
     */
    @Test
    public void fileTest01() throws IOException {

        // 爬目录下的所有东西
        List<Path> list = Files.walk(Path.of("E:\\dev")).toList();
        for (Path path : list) {
            System.out.println(path);
        }
    }

    // 文件创建
    @Test
    public void fileTest02() throws IOException {
        // 只是一个路径的代表 NIO
        Path path = Path.of("c.haha");


        // Files: 对指定的路径进行操作
        if (Files.exists(path)) {
            System.out.println("文件已存在，删除中...");
            Files.delete(path);
        }
        Files.createFile(path);
        System.out.println("文件创建成功!");

        Path path1 = Path.of("hello");
        Files.createDirectories(path1);
        System.out.println("文件夹创建成功!");

        Files.delete(path);
    }


    //文件复制
    @Test
    public void fileTest() throws IOException {

        Path source = Path.of("a.text");

        Path target = Path.of("b.text");

        Files.copy(source,target);

        System.out.println("文件复制成功!");
    }
}
