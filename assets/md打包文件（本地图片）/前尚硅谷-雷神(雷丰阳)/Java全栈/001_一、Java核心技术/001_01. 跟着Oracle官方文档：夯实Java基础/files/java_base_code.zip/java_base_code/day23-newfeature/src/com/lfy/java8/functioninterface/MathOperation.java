package com.lfy.java8.functioninterface;


@FunctionalInterface
public interface MathOperation {


    // 操作这两个数
    int operate(int a, int b);
}
