import java.util.Scanner;

/**
 * 奖学金评定系统
 */
public class HomeScholarShip {

    public static void main(String[] args) {
        //1、平均成绩  pixpin
        int avgScore;
        //2、有无违纪
        boolean hasBadthing;
        //3、论文数量
        int papersNum;
        //4、社会活动积分
        int socialScore;
        //5、参与国家项目
        boolean hasNationalProject;

        System.out.println("请输入平均成绩(0-100)：");
        //从键盘获取一个 int 值。 获取到的值 赋值 给 avgScore
        avgScore = new Scanner(System.in).nextInt();

        System.out.println("请输入有无违纪(true/false)：");
        hasBadthing = new Scanner(System.in).nextBoolean();

        System.out.println("请输入论文数量(0-100)：");
        papersNum = new Scanner(System.in).nextInt();

        System.out.println("请输入社会活动积分(0-10)：");
        socialScore = new Scanner(System.in).nextInt();

        System.out.println("请输入有无参与国家项目(true/false)：");
        hasNationalProject = new Scanner(System.in).nextBoolean();



        // 成绩小于80 或者 有违纪
        if (avgScore <80 || hasBadthing){
            System.out.println("条件不满足，不能参与奖学金评审");
        }else {
            System.out.println("条件满足，正在计算奖学金....");

            //计算附加分
            int extendScore = papersNum*3 + socialScore;
            //如果参加国家项目，再加15分
            if (hasNationalProject){
                extendScore += 15;
            }

            //三元运算符  xx?yy:zz  判断xx是true还是false，如果是true，就是yy，如果是false，就是zz
//            String  x = hasNationalProject?"是：+15":"否";
//            if (hasNationalProject){
//                x = "是：+15";
//            }else {
//                x = "否";
//            }
            //附加分详情字符串
            String extendScoreDetailStr = "附加分总分"+ extendScore +" =>明细：" +
                    "1、(论文："+ papersNum +"篇x3 = "+ papersNum*3 +"分；)" +
                    "2、(社会活动："+ socialScore +"分)" +
                    "3、国家级项目："+ (hasNationalProject?"是：+15":"否");


            if(avgScore >= 95){
                if (extendScore >= 30){
                    System.out.println("特等奖学金；金额：20k");
                }else if(extendScore >=25){
                    System.out.println("一等奖学金；金额：10k");
                }else {
                    System.out.println("二等奖学金；金额：5k");
                }
            } else if (avgScore >= 90) {
                if (papersNum >=2 && extendScore>=28){
                    System.out.println("一等奖学金；金额：10k");
                } else if (extendScore >= 20) {
                    System.out.println("二等奖学金；金额：5k");
                } else {
                    System.out.println("三等奖学金；金额：3k");
                }

            } else if (avgScore >= 85) {
                if (extendScore >= 25){
                    System.out.println("二等奖学金；金额：5k");
                } else if (socialScore >=8) {
                    System.out.println("三等奖学金；金额：3k");
                } else if (papersNum >= 1) {
                    System.out.println("科研鼓励奖(1.5k)");
                }
            } else {
                if (extendScore >= 25){
                    System.out.println("三等奖学金；金额：3k");
                }else if (extendScore >= 15){
                    System.out.println("科研鼓励奖(1k)");
                }
            }
            System.out.println(extendScoreDetailStr);
        }



    }
}
