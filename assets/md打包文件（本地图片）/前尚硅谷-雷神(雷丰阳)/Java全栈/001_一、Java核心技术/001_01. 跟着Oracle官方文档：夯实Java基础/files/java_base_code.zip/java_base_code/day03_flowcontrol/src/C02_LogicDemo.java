/**&
 * 逻辑运算符; 算出的结果都是代表 【真或者假】
 * boolean：布尔型  true：真   false：假
 * 与: &   &&【短路与】   (必须都是真的)
 * 或：|   ||【短路或】
 * 非：!
 */
public class C02_LogicDemo {
    // 大括号里面是代码块
    public static void main(String[] args) {
        int x = 1, y = 2; //批量定义一堆变量
        int i = 3;
        //表达式：表达某种运算的一个式子; 运算不要直接单独出现，肯定是在哪里用着
        //有歧义
        i = (x + y)/100;


        //语句
        System.out.println( i > 18 );

        //语句； 每个语句都是计算机能独立执行的功能；必须用;结尾
        boolean b1 = false;
        boolean b2 = true;
        //与：与的两个东西都得是真的。结果就是真的
        System.out.println( b1 && b2);

        //或：或的两个东西有一个真的就行
        System.out.println(b1 || b2);

        //非：!(不)
        System.out.println(!b2);


        //  A && B： 两个都得是真的，才行！
        int age = 18;
        int money = 10000;
        //与（并且）：有一个假，必然是假
        // 短路与：false && 后面就不用算了
        //   位与：false & 后面都要算

        //或（或者）：有一个真，必然是真
        // 短路或： true || 后面就不用算了
        //   位或： true | 后面都要算
        System.out.println(age>=18 | ++money > 10000); //true
        // 后面的东西算了没算
        System.out.println(money);


        //你师娘教的。 起名都写英语单词
        //类名：首字母大写
        //变量名：首字母小写 maxAgeHaha； 驼峰命名法
        int 年龄 = 8;
        System.out.println(年龄);


    }
}
