package com.lfy.ch10;

public class Dog extends Animal {
    @Override
    public void makeSound() {
        System.out.println("汪汪汪！");
    }

    // 子类特有方法
    public void fetch() {
        System.out.println("狗狗捡回飞盘");
    }
}
