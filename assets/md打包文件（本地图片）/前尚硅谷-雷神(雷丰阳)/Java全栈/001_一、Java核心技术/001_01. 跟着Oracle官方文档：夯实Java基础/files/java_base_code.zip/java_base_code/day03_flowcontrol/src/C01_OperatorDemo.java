public class C01_OperatorDemo {

    public static void main(String[] args) {
        int a = 1;
        //赋值
        a = 2;

        //+= -= *= /= %=
        a += 2; //  a = a + 2;
        System.out.println(a); // 4

        a -= 3; // a = a - 3;
        System.out.println(a);

        a *= 5; // a = a*5;

        // <<=  >>=  >>>=
        a <<= 2; // a = a << 2;

        // &= ^=  ∣=  位运算

        System.out.println("==============");

        //自增 自减
        int x = 5;
        // 让x的增加一个
        //1、x = x + 1;
        //2、x += 1;
        //3、x++;
        //后++
//        x++; //让x自己增加一个
        //前++
        ++x;
        System.out.println(x);

        int y = 88;
//        y--;
        --y;
        System.out.println(y);


        //后++ 和 前++；的区别
        //后++； 先用再加
        //前++： 先加在用
        // +7 -7
        int m = 7;
        //字符串拼串； // 先用（先打印），再算
        System.out.println("m++的结果是：" + m++);
        System.out.println(m);

        int n = 9;  //先算，再用（打印）
        System.out.println("++n的结果是：" + ++n);

        //深入演示：
        int y1 = 9;
//        int x1 = y1++; //输出9
        //两步： 1、x1 = y1;   2、y1自增一个

        int x1 = ++y1; //输出10
        //两步： 1、y1自增一个   2、x1 = 新的y1值
        System.out.println("x1的值是：" + x1);





        // 前++ 后++
        int i = 7;
        System.out.println( i++ + ++i + i++ - ++i ); //猜猜输出







    }
}
