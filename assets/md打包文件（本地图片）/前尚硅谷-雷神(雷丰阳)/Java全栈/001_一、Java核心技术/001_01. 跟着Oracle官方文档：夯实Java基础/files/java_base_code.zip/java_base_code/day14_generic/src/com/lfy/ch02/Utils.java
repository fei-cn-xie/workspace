package com.lfy.ch02;

import java.util.List;

public class Utils {




    // List<? super Integer>：下界通配（可以写元素，读写操作） 接受任意类型的Integer的父类
    public static void print(List<? super Integer> list) {
        for (Object elem : list) {
            System.out.println(elem);
        }

        list.add(123);
    }


    // List<? extends Number>：上界通配（不能写元素，只读操作） 接受任意类型的Number的子类，但不能添加元素
    public static void printNumber(List<? extends Number> list) {
        //?：通配符，表示不确定的类型；使用Object接受
        for (Object elem : list) {
            System.out.println(elem);
        }

//        list.add(123);
    }

    public static void printList(List<?> list) {
        //?：通配符，表示不确定的类型；使用Object接受
        for (Object elem : list) {
            System.out.println(elem);
        }
    }

    //交换数组指定索引位置的值
    public static <T> void swap(T[] arr, int i, int j){
        //交换数组中两个元素的值
        T temp =  arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }

    public static <T> T compute(T obj) {

        System.out.println("obj = " + obj);
        return obj;
    }
}
