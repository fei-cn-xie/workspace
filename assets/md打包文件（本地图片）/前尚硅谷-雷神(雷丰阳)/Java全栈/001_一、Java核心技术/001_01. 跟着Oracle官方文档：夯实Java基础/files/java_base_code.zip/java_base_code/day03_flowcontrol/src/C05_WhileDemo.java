/**
 * while 循环：
 *
 */
public class C05_WhileDemo {
    public static void main(String[] args) {
        int age = 20;
        //当 条件为 真; {}里面的代码块 就要一直执行
        while ( age<18 ) {
            // 循环体：条件为 true 时执行
            System.out.println("工作...");
        } //循环不结束，代码就不能走到下一行


        //打印 1~5
        int i = 1;
//        System.out.println(i++); // 先打i==》1，再加i=2
//        System.out.println(i++); // 先打i==》2，再加i=3
//        System.out.println(i++); // 先打i==》3，再加i=4
//        System.out.println(i++); // 先打i==》4，再加i=5
//        System.out.println(i++); // 先打i==》5，再加i=6


        //利用 while
        //称为(犹豫派)： while - do
        while (i < 6){ //真
            //while条件每次都得先判断一下，才能决定是否要执行代码块的内容
//            System.out.println(i++);
            //等于如下
            System.out.println(i);
            i = i +1;
        }

        System.out.println("===========");

        int  j = 1;
        //称为(上车派)： do - while
        do {
            System.out.println(j++);
        }while (j < 6);

        boolean x = false;
        // while-do
        while (x){
            System.out.println("xxxxx");
        }

        //do-while
        do {
            System.out.println("yyyy");
        }while (x);

        while(true){
            //无限循环
        }

//        System.out.println("哈哈哈");


    }
}
