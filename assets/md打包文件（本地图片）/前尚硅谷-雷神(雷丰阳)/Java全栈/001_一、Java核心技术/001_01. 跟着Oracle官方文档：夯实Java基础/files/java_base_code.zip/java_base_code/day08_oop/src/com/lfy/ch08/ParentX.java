package com.lfy.ch08;

public class ParentX {

    static {
        System.out.println("ParentX 静态代码块执行...");
    }

    {
        System.out.println("ParentX 动态代码块执行...");
    }

    public ParentX() {
        System.out.println("ParentX 构造方法执行...");
    }

    public static void main(String[] args) {
        /**
         * 先静再动，先父后子
         *
         *
         * 1）、【静态】 》 【动态 》 构造】
         * 2）、类加载， 创建对象
         *      1）：类加载：ParentX 静态 == ChildX 静态
         *      2）、创建对象：先创建父（父动态》父构造），再创建子（子动态》子构造）
         * 未继承ParentX之前：
         *      1.ParentX 静态代码块执行...
         *      2.ChildX 静态代码块执行...
         *      3.ChildX 动态代码块执行...
         *      4.ChildX 构造方法执行...
         *
         *  继承ParentX之后：
         *      1.ParentX 静态代码块执行...
         *      2.ChildX 静态代码块执行...
         *      3.ParentX 动态代码块执行...
         *      4.ParentX 构造方法执行...
         *      5.ChildX 动态代码块执行...
         *      6.ChildX 构造方法执行...
         */
        Object obj =  new ChildX();
        Object pa =  new ParentX();
        Object ch = "aaa";


    }
}
