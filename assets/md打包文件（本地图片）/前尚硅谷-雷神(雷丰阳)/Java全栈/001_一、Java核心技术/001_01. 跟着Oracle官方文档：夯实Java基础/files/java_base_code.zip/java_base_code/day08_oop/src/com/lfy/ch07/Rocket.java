package com.lfy.ch07;

public class Rocket extends AbstractFly {


    @Override
    void fly() {
        System.out.println("火箭欻欻的飞....");
    }
}
