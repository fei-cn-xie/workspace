package com.lfy.ch01;

public class DataTest {


    public static void main(String[] args) {

        ShareDataOne dataOne = new ShareDataOne();

        for (int i = 0; i < 5; i++) {
            new Thread(()->{
                try {
                    dataOne.increment();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            },"A-"+i).start();
        }


        for (int i = 0; i < 5; i++) {
            new Thread(()->{
                try {
                    dataOne.decrement();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            },"B-"+i).start();
        }

    }


    public static void bbbb(String[] args) throws InterruptedException {
        ShareDataOne dataOne = new ShareDataOne();

        //无锁环境下：直接调用wait/notify 会炸：IllegalMonitorStateException（非法的监视器状态异常）
        //
        dataOne.aaa();
    }

    // 1 0 1 0 1 0 1 0 1 0
    public static void aaaa(String[] args) {
        ShareDataOne dataOne = new ShareDataOne();
//        for (int i = 0; i < 10; i++) {
//            // 对象::方法引用
//            new Thread(dataOne::increment,"A-"+i).start(); //线程就在后面等待执行
//        }
//
//        for (int i = 0; i < 10; i++) {
//            new Thread(dataOne::decrement,"B-"+i).start();
//        }

        new Thread(()->{
            for (int i = 0; i < 5; i++) {
                try {
                    dataOne.decrement();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        },"B").start();
        // 交替打印： 加减加减加减加减加减加减加减加减加减加减
        new Thread(()->{
            for (int i = 0; i < 5; i++) {
                try {
                    dataOne.increment();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        },"A").start();



    }
}
