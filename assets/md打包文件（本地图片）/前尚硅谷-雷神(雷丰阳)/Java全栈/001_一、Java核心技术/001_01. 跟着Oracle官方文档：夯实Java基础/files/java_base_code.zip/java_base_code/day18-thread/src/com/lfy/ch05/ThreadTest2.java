package com.lfy.ch05;

public class ThreadTest2 {

    public static void main(String[] args) {
        SaleTicketSafe safe = new SaleTicketSafe();

        //卖一张
//        safe.saleOneTicket();


        //
        new Thread(()->{
            for (int i = 0; i < 100; i++) {
                safe.saleOneTicket();
            }
        },"窗口1").start();
        new Thread(()->{
            for (int i = 0; i < 100; i++) {
                safe.saleOneTicket();
            }
        },"窗口4").start();



        new Thread(()->{
            for (int i = 0; i < 100; i++) {
                safe.saleOneTicket();
            }
        },"窗口2").start();

        new Thread(()->{
            for (int i = 0; i < 100; i++) {
                safe.saleOneTicket();
            }
        },"窗口3").start();


    }
}
