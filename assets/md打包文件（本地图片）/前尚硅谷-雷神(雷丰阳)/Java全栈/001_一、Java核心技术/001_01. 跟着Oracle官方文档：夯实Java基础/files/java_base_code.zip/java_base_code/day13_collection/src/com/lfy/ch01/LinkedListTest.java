package com.lfy.ch01;

import org.junit.Test;

import java.util.*;

public class LinkedListTest {




    @Test
    public void testSet01(){
        ArrayList arrayList = new ArrayList();

        arrayList.add("A");
        arrayList.add("B");
        arrayList.add("B");
        arrayList.add("D");
        arrayList.add("D");

        List list = deduplicate(arrayList);
        System.out.println(list);

    }


    public List deduplicate(List temp){

        //1、set去重
        Set set = new HashSet();
        set.addAll(temp);

        //2、把set转回list
        ArrayList arrayList = new ArrayList(set);

        return arrayList;
    }


    @Test
    public void testSet(){
        Set set = new HashSet();
        set.add("A");
        set.add("B");
        set.add("C");
        set.add("D");
        set.add("E");

        set.contains("E");

    }

    @Test
    public void test01(){
        List list = new LinkedList();

        list.add("A");
        list.add("B");
        list.add("C");
        list.add("D");
        list.add("E");

        //1、先要遍历链表，找到东西再删除
        list.remove("B");

        list.removeLast();



    }
}
