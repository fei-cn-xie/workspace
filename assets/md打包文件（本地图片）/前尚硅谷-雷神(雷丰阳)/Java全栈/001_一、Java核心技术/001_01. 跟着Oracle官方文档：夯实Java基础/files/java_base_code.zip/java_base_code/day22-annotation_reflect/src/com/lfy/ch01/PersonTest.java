package com.lfy.ch01;

public class PersonTest {
    public static void main(String[] args) {
        Person person = new Person("张三", 20, true);


        System.out.println(person);

        int age = person.getAge();
        person.setAge(age + 1);
    }
}
