public class C02_ForDemo2 {

    public static void main(String[] args) {
        for (int i = 0; i <= 9; i++) {
            System.out.println(i);
        }

        System.out.println("==========");

        for (int i = 9; i >= 0; i--) {
            System.out.println(i);
        }

        System.out.println("==========");

        int[] arr = {1, 2, 3, 6, 8, 9, 19, 22, 33, 545, 678}; //索引 0-5； 索引最大值比元素个数少个
        System.out.println(arr.length); //拿到数组的长度11；索引10（数组中有几个元素）

        //打印数组的值
        for (int i = 0; i <= arr.length - 1; i++) {
            System.out.println(arr[i]);
        }


        //普通for; 数组是固定长度的
        String[] str = {"苹果", "香蕉", "橙子"};
        for (int i = 0; i < str.length; i++) {
            System.out.println(str[i]);
        }

        //遇见对于  数组/集合 的遍历，推荐直接用 增强for
        //增强for   for(数据类型 变量名: 数组/集合){ 变量名就是当前正在遍历的元素 }
        for (String a : str) {
            System.out.println(a);
        }


    }
}
