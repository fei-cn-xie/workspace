/**
 * For循环：
 */
public class C01_ForDemo {

    public static void main(String[] args) {
        //第一种
        //1、第一次先执行 [初始化] 功能； int i = 0； 执行一次
        //2、进行 条件判断 是否为true，1).如果是真 执行 循环体代码 2).如果是假就结束
        //3、是真 执行 循环体代码；执行一次
        //4、方法体执行完成后再执行 迭代操作
        //5、进行2
        for (int i = 0; i < 5 ; i++) {
            System.out.println("haha");
        }
        //第一次：i=0(仅一次), i<5成立，执行 打印haha， 再把 i++ ；i变1
        //第二次：i=1(迭代后), i<5成立, 执行 打印haha, 再把 i++ ；i变2
        //第三次：i=2(迭代后), i<5成立, 执行 打印haha, 再把 i++ ；i变3
        //第四次：i=3(迭代后), i<5成立, 执行 打印haha, 再把 i++ ；i变4
        //第五次：i=4(迭代后), i<5成立, 执行 打印haha, 再把 i++ ；i变5
        //第六次：i=5(迭代后), i<5不成立,程序结束


        //模拟这是一个死循环
        for (;;){ //while(true) 死循环
            System.out.println("hehe");
        }


    }
}
