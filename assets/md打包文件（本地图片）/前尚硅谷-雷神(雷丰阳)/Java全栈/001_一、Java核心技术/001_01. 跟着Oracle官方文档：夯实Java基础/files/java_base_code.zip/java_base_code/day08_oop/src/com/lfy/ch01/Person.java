package com.lfy.ch01;


/**
 * 【封装性原则：类的属性应该私有】
 * 1、别人要用类中的私有属性，需要通过类中公开的getter/setter方法
 */
public class Person {

    private String name;
    private int age;
    private String email;  //getter/setter
    private boolean marry; //真/假
    // === 以上其实就是一个临时变量保存数据的


    //1、类里面有哪些属性，其实不看 成员变量的名字；而是看 类中的 getter/setter 方法名字。
    //2、反射。直接根据一个对象，直接反向分析出当时这个类是怎么写的
    public String getGmail() {
        return email;
    }

    public void setGmail(String email) {
        this.email = email;
    }



    public boolean isMarry() { //读取
        return marry;
    }

    public void setMarry(boolean marry) {
        this.marry = marry; //修改
    }

    //提供专门的获取方法：
    //1、获取数据：getter
    //2、设置数据：setter


    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    private void eat(){
        System.out.println("吃饭");
    }

    public void sleep(){
        eat();
        System.out.println("睡觉");
    }
}
