package com.lfy.ch02;

public enum Season {


//    SPRING, SUMMER, AUTUMN, WINTER; //利用无参构造器创建的

    SPRING("春天", "1-3"),
    SUMMER("夏天", "4-6"),
    AUTUMN("秋天", "7-9"),
    WINTER("冬天", "10-12");

    private String seasonName; // 春天
    private String seasonDesc; // 1-3

    //希望有汉字？
    //枚举的本质； 枚举在底层是类，构造器是私有的


//    枚举构造器私有化，不允许外部创建对象
    Season(String name, String desc){
        this.seasonName = name;
        this.seasonDesc = desc;
    }


    //为属性添加get方法
    public String getSeasonDesc() {
        return seasonDesc;
    }

    public String getSeasonName() {
        return seasonName;
    }


    /**
     * 重写 枚举的valueOf方法【由于静态没法重写】
     */
    public static Season valueOfBySeasonName(String seasonName) {
       switch (seasonName) {
           case "春":
               return SPRING;
           case "夏":
               return SUMMER;
           case "秋":
               return AUTUMN;
           case "冬":
               return WINTER;
       }
        return null; // 或者抛出自定义异常
    }

}
