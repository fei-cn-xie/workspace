package com.lfy.ch02;

// 如果临时启动线程做一个事情，没必要专门写一个类，可以直接使用匿名内部类
public class MyRunnable1_50 implements Runnable{
    @Override
    public void run() {

    }
}
