package com.lfy.ch03;

public class EvenOddPrint {

    public static void main(String[] args) throws InterruptedException {

        String name1 = Thread.currentThread().getName();
        System.out.println("线程名字："+name1);


        new Thread(()->{
            String name = Thread.currentThread().getName();
            System.out.println(name+"；1111111");
        } ,"哈哈").start();

        //打印奇数
//        new Thread(()->{
//            for (int i = 0; i < 100; i++) {
//                if(i % 2 == 1){
//                    //获取到当前线程的名字; 默认是：Thread-数字
//                    String name = Thread.currentThread().getName();
//
//                    System.out.println(name+"；"+i);
//                }
//            }
//        },"打印奇数").start();

//        Thread.sleep(1000);

        //打印偶数
        new Thread(()->{
            for (int i = 0; i < 100; i++) {
                if (i%2 == 0){
                    //获取到当前线程的名字
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    String name = Thread.currentThread().getName();
                    System.out.println(name+"；"+i);
                }
            }
        },"打印偶数").start();




    }
}
