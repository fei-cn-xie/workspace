package com.lfy.ch01.tcp;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 * 做服务器后台； 接受请求、发送响应；
 * 框架把网络底层封装了。
 *
 * Web开发（网络应用）； Java
 * Java基础：（【IO流、网络、多线程】、基础语法 【(if\while\for\声明变量\集合)】 ）
 * @author lfy
 */
//1、如何一直收发！
public class FanyiciTcpServer {

    //框架在底层会自动开线程调用我们的方法，处理请求
    //2、网络编程的项目：Netty(定制化)
    public void abc(){
    }

    public static void main(String[] args) throws IOException {
        //1、创建 ServerSocket，绑定端口
        ServerSocket ss = new ServerSocket(8080);
        System.out.println("1. 服务器启动....");

        //2、等待客户端连接
        while (true) {
            Socket socket = ss.accept(); //阻塞；每个客户端进来，都会继续往下执行
            InetAddress address = socket.getInetAddress();
            System.out.println("2. 客户端已连接..."+address.getHostAddress()+":"+socket.getPort());


            //3. 开启线程，处理客户端请求。每个客户端都是一个socket，对应线程处理
            new Thread(()->{
                try(
                        OutputStream os = socket.getOutputStream();
                        InputStream is = socket.getInputStream();
                ){

                    Scanner scanner = new Scanner(System.in);
                    while (true){
                        //3、读取客户端发送的数据
                        byte[] bytes = new byte[1024];
                        int len;
                        if ((len = is.read(bytes)) != -1) { // 数据是无穷尽的。
                            String str = new String(bytes, 0, len);
                            System.out.println("收到客户端消息：" + str);

                            //4、将数据返回给客户端
                            //5、从键盘录入数据，返回给客户端
                            String s = scanner.nextLine();
                            os.write(s.getBytes());
                            os.flush();
                        }
                    }
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }).start();

        }

    }
}
