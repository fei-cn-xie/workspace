package com.lfy.ch01;

public class USB3_0_Imp implements USB3_0 {
    @Override
    public void fastTransfer() {
        System.out.println("USB3.0 传输速度快....");
    }
}
