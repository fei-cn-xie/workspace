package com.lfy;

import java.io.Serializable;


// Serializable： 可序列化； 标记接口；
public class Student implements Serializable {

    // 固定写法： 版本号； 解决序列化兼容问题
    private static final long serialVersionUID = 1478932749823749827L;

    private String name;
    private int age;
    private boolean vip;


    // 无参构造器： 每个人必须有一个无参构造器
    public Student() {
    }


    public Student(String name, int age, boolean vip) {
        this.name = name;
        this.age = age;
        this.vip = vip;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", vip=" + vip +
                '}';

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public boolean isVip() {
        return vip;
    }

    public void setVip(boolean vip) {
        this.vip = vip;
    }
}
