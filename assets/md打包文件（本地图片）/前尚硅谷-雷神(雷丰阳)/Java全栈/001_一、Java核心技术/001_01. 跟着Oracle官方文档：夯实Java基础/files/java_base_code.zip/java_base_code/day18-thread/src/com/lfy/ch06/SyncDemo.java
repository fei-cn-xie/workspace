package com.lfy.ch06;

public class SyncDemo {

    public synchronized void a(){
        System.out.println("进入a");

        b(); // 如果 synchronized 不是 可重入锁（前面得到了，后面直接用）；

        System.out.println("退出a");
    }

    public synchronized void b(){
        System.out.println("进入b");

        System.out.println("退出b");
    }

    public static void main(String[] args) {
        SyncDemo demo = new SyncDemo();

        new Thread(demo::a).start();
    }
}
