package com.lfy.math;


//模块化：
//1、requires： 引入模块； 我需要谁
//2、exports： 导出模块； 我的什么功能别人可以使用
//3、uses： 指定服务接口的实现类； 我的功能需要谁来实现
//4、provides： 提供服务接口的实现类； 我的功能实现了谁
//5、opens： 导出模块，并且允许反射访问； 我的什么功能别人可以使用，而且可以反射
public class Abc {


}
