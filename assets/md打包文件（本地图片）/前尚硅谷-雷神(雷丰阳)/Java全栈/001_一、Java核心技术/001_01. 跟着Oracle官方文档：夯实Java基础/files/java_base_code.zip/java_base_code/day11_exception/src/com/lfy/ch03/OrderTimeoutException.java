package com.lfy.ch03;

import java.util.Date;

/**
 * 1、自定义异常类
 */
public class OrderTimeoutException  extends RuntimeException{

    private String orderId;
    private Date timeout;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public Date getTimeout() {
        return timeout;
    }

    public void setTimeout(Date timeout) {
        this.timeout = timeout;
    }

    //接受错误消息
    public OrderTimeoutException(String message) { //by zero
        super(message);
    }

    //接受错误消息和订单ID
    public OrderTimeoutException(String message, String orderId,Date timeout) { //by one
        super(message);
        this.orderId = orderId;
        this.timeout = timeout;
    }


}
