/**
 * 中断：剩下的for循环都不执行了。for退出；
 */
public class C05_BreakDemo {

    public static void main(String[] args) {
        System.out.println("打印开始");

        for (int i = 0; i < 10; i++) {
            if (i == 5){
                break; //中断; 循环体代码以及后面for循环都不执行
            }
            System.out.println("打印："+i);
        }

        System.out.println("==========");
    //标签：给这行代码做一个标记
    aaa:  for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                if (j > 3){
                    break aaa; //只能break（中断） 当前的for
                }
                System.out.println("i="+i+"，j="+j);
            }
        }

        System.out.println("打印结束");
    }
}
