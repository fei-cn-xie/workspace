package com.lfy.ch05;

import com.lfy.ch04.USB2_0;
import com.lfy.ch04.USB3_0;

public class Child extends Parent implements USB3_0, USB2_0 {


    @Override
    public void transfer() {

    }
}
