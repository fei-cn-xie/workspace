package com.lfy.ch04;


//
public class CounterTest {

    public static void main(String[] args) throws InterruptedException {
        Counter counter = new Counter();
        Thread thread = new Thread(() -> {
            for (int i = 0; i < 5000; i++) {
                try {
                    counter.increment();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        });

        Thread thread1 = new Thread(() -> {
            for (int i = 0; i < 5000; i++) {
                try {
                    counter.increment();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        thread.start();
        thread1.start();

        thread.join();
        thread1.join();
        System.out.println(counter.getCount());


    }
}
