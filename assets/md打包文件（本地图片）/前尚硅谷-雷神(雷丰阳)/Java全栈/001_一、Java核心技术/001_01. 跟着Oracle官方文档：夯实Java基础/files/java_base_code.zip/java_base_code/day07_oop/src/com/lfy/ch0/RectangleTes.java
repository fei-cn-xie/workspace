package com.lfy.ch0;

public class RectangleTes {

    public static void main(String[] args) {
        Rectangle r = new Rectangle();
        r.printRectangle();

        System.out.println("===================");


        Rectangle r1 = new Rectangle(0, 0, 10, 20);
        r1.printRectangle();



        //希望：即使用无参构造器创建的对象，默认 0, 0, 10, 20


    }
}
