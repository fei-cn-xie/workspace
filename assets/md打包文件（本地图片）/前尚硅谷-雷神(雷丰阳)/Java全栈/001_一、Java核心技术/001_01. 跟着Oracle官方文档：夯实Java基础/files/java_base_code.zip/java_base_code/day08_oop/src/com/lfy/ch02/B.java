package com.lfy.ch02;


/**
 * 所有类，都是继承自Object类
 */
public class B {


    public void add(int a,int b){

    }

    public void add(double a, double b){

    }

    public void add(String a, String b){

    }
}
