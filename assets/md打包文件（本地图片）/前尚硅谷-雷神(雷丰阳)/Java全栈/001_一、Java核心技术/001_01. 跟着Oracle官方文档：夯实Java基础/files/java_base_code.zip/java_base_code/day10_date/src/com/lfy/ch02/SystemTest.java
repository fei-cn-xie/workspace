package com.lfy.ch02;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class SystemTest {

    public static void main(String[] args) {
        System.out.println("Hello, World!");

        Scanner scanner = new Scanner(System.in);


        long l = System.currentTimeMillis();// 获取当前时间戳, 单位毫秒
        System.out.println(l);


        //1、获取当前时间 默认格式：Thu May 22 19:53:14 CST 2025
        Date date = new Date();
        System.out.println(date); // date.toString()

        long time = 1559807047979L;
        Date d = new Date(time);
        System.out.println(d);


        //2、算 当前时间 30min 以后 的时间？
        long current = System.currentTimeMillis(); //毫秒
        Date d1 = new Date(current);
        System.out.println("当前时间："+d1);
        //算 30min 以后的时间
        current += 30*60*1000;
        Date date1 = new Date(current);
        System.out.println("30min 以后的时间："+date1);


        //String.format();//格式化时间


        //1、指定日期格式化格式
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年 MM月 dd日 HH时mm:ss>SSS");

        String format = sdf.format(date1);
        System.out.println(format);



        //1、拿到 Calendar 实例
        Calendar instance = Calendar.getInstance();
        System.out.println(instance.getTime());


        // 时间往后推 30 小时
        instance.add(Calendar.HOUR, 30);
        System.out.println(instance.getTime());

    }
}
