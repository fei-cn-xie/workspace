package com.lfy.ch03;


/**
 * 1、私有的永远不能被继承
 * 2、剩下的需要具体看修饰符（注意 不写、protected）
 */
public class ExtendTest {

    public static void main(String[] args) {

//        Dog dog = new Dog();
//
////        Cat cat = new Cat();
//
//        dog.eat();
////        cat.eat();
//
//        //类名调用静态方法
//        Dog.sayHello();
//
//        //对象调用静态方法，其实是通过类名调用
//        dog.sayHello();

//        Animal animal = new Animal();



        // 子类构造方法会调用父类构造方法
//        Dog dog = new Dog();
//
//        dog.eat();


        System.out.println("----------------------");
        //1、向上转型。  子类可以转为父类的类型。
        //狗是Animal； 写所有兼容的类型都可以
        Animal dog = new Dog();
        dog.eat();


        System.out.println("----------------------");

        //狗是Dog；
        Dog dog1 = new Dog();
        dog1.eat();




        Object obj = new Dog();

        //判断类型，再做转换； 判断 这个对象 是否是 指定类型
        if (obj instanceof Dog) {
            Dog dog2 = (Dog) obj;
        } else if (obj instanceof Animal) {
            Animal animal = (Animal) obj;
        }


        //2、向下转型。  父类可以转为子类的类型。


    }
}
