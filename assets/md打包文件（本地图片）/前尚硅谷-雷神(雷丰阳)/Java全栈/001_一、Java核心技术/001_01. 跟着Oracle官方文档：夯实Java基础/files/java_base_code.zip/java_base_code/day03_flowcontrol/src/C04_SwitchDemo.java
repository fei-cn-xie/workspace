/**
 * IF 的另一种写法
 *
 */
public class C04_SwitchDemo {
    public static void main(String[] args) {
        // 1-7
        int day = 4;

        // 整型(byte\short\int\long)、字符型char 和枚举
        switch (day) {
            case 1: //列举具体的值
                System.out.println("星期一");
                break; //中断
            case 2:
                System.out.println("星期二");
                break; //中断
            case 3:
                System.out.println("星期三");
                break; //中断
            case 4:
                System.out.println("星期四");
                break; //中断
            case 5:
                System.out.println("星期五");
                break; //中断
            case 6:
                System.out.println("星期六");
                break; //中断
            case 7:
                System.out.println("星期七");
                break; //中断
        }



        day = 5;
        switch (day){
            //多种分支合并
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                System.out.println("工作日");
                break;
            case 6:
            case 7:
                System.out.println("休息日");
                break;
            default: //默认情况
                System.out.println("输入了非法的数字");
        }
    }
}
