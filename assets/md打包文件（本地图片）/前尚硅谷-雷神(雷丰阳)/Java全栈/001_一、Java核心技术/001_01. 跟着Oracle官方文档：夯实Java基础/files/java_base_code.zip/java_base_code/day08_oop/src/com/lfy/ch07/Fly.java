package com.lfy.ch07;


/**
 * 任何一个人实现这个接口都要 实现这三个方法
 */
public interface Fly {

    void flyOnLand();
    void flyInSky();
    void flyInSpace();

}
