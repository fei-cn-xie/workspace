package com.lfy.ch01;


/**
 * 封装性：
 * 1、把部分的功能抽取到一个单独的类中；
 * 2、这个类默认只想让 外部的用到；
 *
 * 静态（类级别，随着类一起加载产生的）：  直接用 Class.Xxx；
 * 非静态：（需要用对象才能拿到）
 *
 *
 * 内部类： 在类的内部定义的类；（静态/非静态）
 * 局部类： 在方法内部定义的类；
 * 匿名局部类： 没有名字的类；直接new 接口对象。这个对象中自己写实现方法。这个匿名局部类他是一次性的
 */
public class Person {

    private String msg = "hahah";

    void eat() {
        Phone phone = new Phone();

        //局部类
        class Dog {
            private String name;
            public void run() {
                System.out.println(msg + "dog run");
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getName() {
                return name;
            }
        }


        Dog dog = new Dog();
        dog.run();


    }


    /**
     * 内部类，一般都会私有
     */
    //静态内部类
    public static class Phone {

    }

    //内部类
    public class Card {

    }

    public static void main(String[] args) {

    }



}
