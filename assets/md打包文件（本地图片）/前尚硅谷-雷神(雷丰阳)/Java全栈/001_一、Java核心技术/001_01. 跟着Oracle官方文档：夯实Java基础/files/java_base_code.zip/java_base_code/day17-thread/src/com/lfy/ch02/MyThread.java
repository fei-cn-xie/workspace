package com.lfy.ch02;

public class MyThread extends Thread{


    // 后台执行这个方法。
    @Override
    public void run() {
        for (int i = 0; i < 100; i++){
            System.out.println("MyThread: " + i);
        }
    }

}
