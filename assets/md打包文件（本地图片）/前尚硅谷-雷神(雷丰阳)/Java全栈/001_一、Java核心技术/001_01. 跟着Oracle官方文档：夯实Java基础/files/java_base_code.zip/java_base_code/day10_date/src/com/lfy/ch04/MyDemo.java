package com.lfy.ch04;

public class MyDemo {


    // final 、 finally 、 finalize 区别; 雷锋、雷丰阳、雷峰塔
    //1、final： 定义常量
    //2、finally： 异常处理
    //3、finalize： 垃圾回收
    public static void main(String[] args) {

    }

}
