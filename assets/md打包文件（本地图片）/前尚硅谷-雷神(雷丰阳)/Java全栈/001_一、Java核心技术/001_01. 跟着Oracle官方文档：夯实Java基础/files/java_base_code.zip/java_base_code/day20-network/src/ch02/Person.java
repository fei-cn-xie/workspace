package ch02;

import org.openjdk.jol.info.ClassLayout;

public class Person {

    private String name;
    private int age;
    public Person(){

    }
    public Person(String name,int age){
        this.name=name;
        this.age=age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }



    // synchronized： 锁关键字
    public synchronized void sayHello(){
        System.out.println("Hello");

        // 最后两位锁标志被改掉了
        String printable = ClassLayout.parseInstance(this).toPrintable();
        System.out.println("锁里面的对象信息：");
        System.out.println(printable);
    }
}
