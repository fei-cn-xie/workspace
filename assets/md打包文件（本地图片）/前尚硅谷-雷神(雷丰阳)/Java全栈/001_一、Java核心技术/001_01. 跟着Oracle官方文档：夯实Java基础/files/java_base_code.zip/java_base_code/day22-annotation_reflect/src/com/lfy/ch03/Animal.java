package com.lfy.ch03;

public class Animal {
}
