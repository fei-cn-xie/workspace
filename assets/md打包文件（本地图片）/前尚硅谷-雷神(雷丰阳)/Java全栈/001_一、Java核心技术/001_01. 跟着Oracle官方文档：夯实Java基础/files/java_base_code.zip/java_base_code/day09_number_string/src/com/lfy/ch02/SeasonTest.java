package com.lfy.ch02;

public class SeasonTest {
    public static void main(String[] args) {
        Season season = Season.AUTUMN;


        System.out.println(season.getSeasonName());
        System.out.println(season.getSeasonDesc());




        Season value = Season.valueOfBySeasonName("春");
        System.out.println(value);
    }
}
