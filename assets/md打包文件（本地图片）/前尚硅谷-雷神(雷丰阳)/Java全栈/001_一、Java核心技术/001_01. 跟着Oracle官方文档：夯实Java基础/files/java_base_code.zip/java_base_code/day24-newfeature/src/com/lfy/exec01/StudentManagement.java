package com.lfy.exec01;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.*;

/**
 * 【学生管理系统】
 *
 * 写程序：
 * 1、 总步骤
 *    1）、分步骤（抽取为一个方法）
 *
 *  1、画流程图；
 *  2、细化里面的细节
 *
 * @author 53409
 */
public class StudentManagement {
    private final static Scanner scanner = new Scanner(System.in);

    // 存储学生信息的容器
    private final static Map<Long, Student> students = new HashMap<>();


    /**
     * 功能1：展示菜单
     */
    private static void displayMenu() {
        System.out.println("=========== 学生管理系统 V1.0 ==========");
        // V
        System.out.println("1、添加学生信息");
        System.out.println("2、删除学生信息");
        System.out.println("3、修改学生信息");
        System.out.println("4、按学号查询学生信息");
        // V
        System.out.println("5、查询所有学生信息");
        System.out.println("6、保存学生数据");
        System.out.println("7、退出系统");
        System.out.println("========================================");
    }

    /**
     * 1、展示一个可视化界面（控制台）； 提供操作按钮；  实现菜单
     * 2、规划你要做的所有事情（功能）
     */

    public static void main(String[] args) {
        loadStudents(); //加载学生数据
        //2、接收用户的选择； 只需呀new一次  try-with-resources 自动关闭资源
        while (true) {
            //1、展示菜单
            displayMenu();

            //3、根据用户的选择，执行对应的功能
            String s = scanner.nextLine();
            switch (s) {
                case "1":
                    addStudent();
                    break;
                case "2":
                    deleteStudent();
                    break;
                // 修改和添加共用同一个方法； key相同就会覆盖
                case "3":
                    addStudent();
                    break;
                case "4":
                    getStudentById();
                    break;
                case "5":
                    getAllStudent();
                    break;
                case "6":
                    saveAllStudents();
                    break;
                case "7":
                    saveAllStudents(); // 保存数据
                    System.out.println("退出系统");
                    return;
                default:
                    System.out.println("请输入正确的选项！");
            }
        }

    }


    private static void loadStudents() {
        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("students.ser"));){
            //1、读取所有数据
            List<Student> o = (List<Student>) ois.readObject();
            for (Student student : o) {
                //2、放到容器中
               students.put(student.getId(),student);
            }
        }catch (Exception e){
            System.out.println("加载失败！"+e);
        }
    }

    private static void saveAllStudents() {

        // students； 所有学生数据
        List<Student> list = students.values()
                .stream()
                .toList();

        // 使用序列化
        try(ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("students.ser"));){
            os.writeObject(list);
            System.out.println("保存成功！");
        }catch (Exception e){
            System.out.println("保存失败！"+e);
        }

    }

    private static void getAllStudent() {
        //1、拿到数据容器
        Collection<Student> values = students.values();
        //2、遍历打印所有学生
        for (Student student : values) {
            printStudent(student);
        }
    }

    private static void getStudentById() {
        System.out.println("输入学生id：");
        String id = scanner.nextLine();


        //快速错误返回
        if (id == null || id.isEmpty()){
            System.out.println("输入数据不能为null");
            return;
        }

        long l = Long.parseLong(id);

        //查询学生
        Student student = students.get(l);
        if (student == null){
            System.out.println("没有找到该学生！");
            return;
        }

        //打印学生
        printStudent(student);
    }

    private static void printStudent(Student student) {
        System.out.println(student.getId()+ "\t" + student.getName() + "\t" + student.getAge() + "\t" + student.getGradeName());
    }


    private static void deleteStudent() {
        System.out.println("输入学生id：");
        String id = scanner.nextLine();
        long l = 0;
        // 循环读取数据，直到输入数字为止
        while (true){
            //快速错误返回
            if (id == null || id.isEmpty()){
                System.out.println("输入数据不能为null");
                return;
            }
            try {
                //直到读取到数字为止
                l = Long.parseLong(id);
                break;
            }catch (Exception e){
                System.out.println("输入学生id：");
                id = scanner.nextLine();
            }
        }


        //删除
        students.remove(l);
        System.out.println("删除成功！");


    }


    //1、添加学生信息
    private static void addStudent() {
        System.out.print("输入学生信息；例如：（100,张三,18,大一）：");
        String s = scanner.nextLine();
        if (s != null && !s.isEmpty()) {
            //1、分割字符串。
            String[] split = s.split(",");
            if(split.length != 4) {
                System.out.println("输入格式不正确！");
                return;
            }

            // 如果不是数字，希望重写输入
            try {
                String id = split[0];
                long l = Long.parseLong(id);

                // 100,张三,18,大一
                // split[0] . split[1] . split[2] . split[3]
                //2、正确逻辑
                Student student = new Student(l, split[1], Integer.parseInt(split[2]), split[3]);
                //3、存储
                students.put(l, student);
                System.out.println("学号【"+l+"】：添加成功！" );
                System.out.println("添加成功！：" + s);
            }catch (Exception e){
                System.out.println("输入数据不正确！请重新输入！");
                //如果炸了，继续执行添加
                addStudent(); // 递归调用，继续添加
            }

        }


    }
}
