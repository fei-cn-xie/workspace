package c01;

public class F18Test {


    public void gagag(){

    }

    public static void main(String[] args) {
        //1、类 只是一种抽象的封装
        //2、真正有用的是按照这个类制造的对象


        //1）、制造大黄蜂战机； 用new关键字创建对象; 利用构造器创建类的对象
        F18Hornet f18a = new F18Hornet();
        //2）、真正有用的是对象   对象.xxx   拿到对象里面的xx
        //  类中定义的每一个属性，每一个对象都有自己的一份值
        f18a.callSign = "S001";
        //3）、调用方法
//        f18a.takeOff();

        f18a.showStatus();


        F18Hornet f18b = new F18Hornet();
        f18b.callSign = "S002";
//        f18b.takeOff();

        f18b.showStatus();


    }
}
