package com.lfy.ch02;

public class DayTest {

    public static void main(String[] args) {

//        //表示 7 天； 笨重的写法
//        Day01 monday = new Day01();
//        Day01 day02 = new Day01();
//        Day01 day03 = new Day01();
//        Day01 day04 = new Day01();
//        Day01 day05 = new Day01();
//        Day01 day06 = new Day01();
//        Day01 day07 = new Day01();

        //1、不能创建枚举对象
        Day monday = Day.MONDAY;
        Day tuesday = Day.TUESDAY;


        //2、打印 枚举的名字；
        System.out.println(monday);
        System.out.println(tuesday);

        //3、打印他的序号
        System.out.println(monday.ordinal());
        System.out.println(tuesday.ordinal());


        System.out.println("=============");
        //4、打印枚举的所有值
        Day[] values = Day.values();
        for (Day day : values) {
            System.out.println(day);
        }


        System.out.println("============");

        DayTest dayTest = new DayTest();
        dayTest.test(Day.SUNDAY);
    }


    public  void test(Day day){
        //1、根据星期几来决定是上班，还是休息
        switch (day) {
            case SATURDAY:
            case SUNDAY:
                System.out.println("休息");
                break;
            case MONDAY:
            case TUESDAY:
            case WEDNESDAY:
            case THURSDAY:
            case FRIDAY:
                System.out.println("上班");
                break;
            default:
                System.out.println("未知");
                break;
        }

    }
}
