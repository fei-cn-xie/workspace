package com.lfy.ch0;


/**
 * 以后只要写有参，就推荐一定写无参；为什么？、
 * 1）、因为后来整合框架的，框架都会用反射调用这个类的无参构造器去创建他的对象。
 */
public class Motor {
    public int speed;



    //推荐一定写上。
    public Motor(){

    }

    public Motor(int speed){
        this.speed = speed;
    }

    public void run(){
        System.out.println("当前摩托：速度：" + speed);
    }
}
