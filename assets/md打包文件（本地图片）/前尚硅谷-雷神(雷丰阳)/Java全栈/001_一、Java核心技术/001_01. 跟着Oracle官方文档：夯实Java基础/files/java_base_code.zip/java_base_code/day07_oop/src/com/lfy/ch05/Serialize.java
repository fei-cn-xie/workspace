package com.lfy.ch05;


/**
 * 序列化接口：
 * 定义把这个图形如何保存到硬盘上
 */
public interface Serialize {
//    void serialize();
    default void serialize(){
        System.out.println("把图形默认保存在C盘....");
    }
}
