package com.lfy.ch05;

public class Rectangle implements Drawable,Serialize{
    @Override
    public void draw() {
//        COMPANY = "";
        System.out.println(COMPANY + "：正在画矩形...");
    }

    //没有实现 serialize 方法，但是有默认实现

    public static void main(String[] args) {
        Rectangle rectangle = new Rectangle();

        rectangle.draw();


        rectangle.serialize();
    }


}
