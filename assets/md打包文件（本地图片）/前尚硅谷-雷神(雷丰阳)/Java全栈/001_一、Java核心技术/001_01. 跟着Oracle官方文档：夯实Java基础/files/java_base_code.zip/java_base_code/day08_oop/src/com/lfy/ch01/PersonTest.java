package com.lfy.ch01;

public class PersonTest {

    public static void main(String[] args) {
        Person person = new Person();

        String name = person.getName();
        System.out.println("名字是："+name);
        //设置值
        person.setName("李四");

        System.out.println(person.getName());

        int age = person.getAge();
        System.out.println("年龄是："+age);
        person.setAge(20);
        System.out.println(person.getAge());


        boolean marry = person.isMarry();
        System.out.println(marry);

        person.sleep();
    }
}
