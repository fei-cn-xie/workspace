package com.lfy.ch02;

import com.lfy.ch1.Hello;

public class HeiheiTest {

    public static void main(String[] args) {
        Hello hello = new Hello();


    }
}
