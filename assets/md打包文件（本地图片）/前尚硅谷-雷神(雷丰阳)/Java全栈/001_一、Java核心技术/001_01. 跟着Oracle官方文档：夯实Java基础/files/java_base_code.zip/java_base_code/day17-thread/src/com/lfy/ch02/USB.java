package com.lfy.ch02;

/**
 * 非函数式接口
 * 函数式接口：只有一个抽象方法的接口。
 */
@FunctionalInterface
public interface USB {
    default void open() {

    }

    default void close() {

    }

    int transfer(String data,int len);
}
