package com.lfy.ch03;


/**
 * 1、每个基本类型都有自己的包装类
 *   整数： Integer(int)、Long(long)、Short(short)、Byte(byte)
 *   浮点数：Double(double)、Float(float)
 *   布尔：Boolean(boolean)
 *   字符：Character(char)
 */
public class WrapperClasstest {

    public static void main(String[] args) {
/*
        Integer i = 10,m = 10,n = 10;
        int j = 10;
        System.out.println(m + n);
        System.out.println(i>20);
*/



        //比大小
        Integer i = 30;
        Integer j = 20;

        //比较两个对象是否相等
        //1、0：两个想等
        //  -1：前比后小
        //   1：前比后大
        int i1 = i.compareTo(j);
        System.out.println(i1);

        System.out.println("==============解码操作=========");

        // 把N进制转成 10进制的数字
        // 0x：十六进制前缀;  #
        // 07：八进制前缀;
        Integer decode = Integer.decode("0x123"); // 1*16^2 + 2*16^1 + 3*16^0
        System.out.println(decode); //291

        //CSS样式：颜色表示 #FFF #A1B2C2
        Integer decode1 = Integer.decode("#123"); // 1*16^2 + 2*16^1 + 3*16^0
        System.out.println(decode1); //291

        Integer decode2 = Integer.decode("077"); // 7*8^2 + 7*8^1
        System.out.println(decode2); //63


        // 比 decode 更灵活
        int i2 = Integer.parseInt("123", 5); //25 + 10 + 3
        System.out.println(i2);




    }
}
