package com.lfy.ch02;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalUnit;

public class LocalDateTest {
    public static void main(String[] args) {

        // 1、获取当前日期
        LocalDate date = LocalDate.now();
        System.out.println(date);

        // 2、获取指定日期
        LocalDate localDate = LocalDate.of(2000, 12, 7);
        System.out.println(localDate);


        //3、根据字符串获取日期
        LocalDate parse = LocalDate.parse("2020-12-07");
        System.out.println(parse);


        // "2020-12-07"
        int year = localDate.getYear();
        System.out.println(year);

        Month month = localDate.getMonth();

        int dayOfYear = localDate.getDayOfYear();
        System.out.println(dayOfYear);


        DayOfWeek dayOfWeek = localDate.getDayOfWeek();
        System.out.println(dayOfWeek);




        //2、获取当前时间；不带日期
        LocalTime localTime = LocalTime.now();
        System.out.println(localTime);

        int hour = localTime.getHour();
        System.out.println(hour);


        LocalTime plus = localTime.plus(10, ChronoUnit.MINUTES);
        System.out.println(plus);

        //3、获取当前日期时间
        LocalDateTime specificDateTime = LocalDateTime.of(2023, 10, 25, 14, 30, 45);

        LocalDate localDate1 = specificDateTime.toLocalDate();
        LocalTime localTime1 = specificDateTime.toLocalTime();


        //4、时区
        ZonedDateTime now = ZonedDateTime.now(ZoneId.of("Asia/Shanghai"));
        System.out.println(now);

        ZonedDateTime now1 = ZonedDateTime.now(ZoneId.of("America/New_York"));
        System.out.println(now1);


        //5、时间戳
        Instant now2 = Instant.now();
        System.out.println(now2);


        //6、时间差
        Period period = Period
                .between(
                        LocalDate.of(2023, 1, 1),
                        LocalDate.now()
                );
        int days = period.getDays();
        System.out.println(days);
        // 获取相差的总天数
        long between = ChronoUnit.DAYS.between(
                LocalDate.of(2023, 1, 1),
                LocalDate.now()
        );
        System.out.println(between);


        // 格式化
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy年MM月dd日 HH:mm:ss");

        String format = formatter.format(LocalDateTime.now());
        System.out.println(format);


    }
}
