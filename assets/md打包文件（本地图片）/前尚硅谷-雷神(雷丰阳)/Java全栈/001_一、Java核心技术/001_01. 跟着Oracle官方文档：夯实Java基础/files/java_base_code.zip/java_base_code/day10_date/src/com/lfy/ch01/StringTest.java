package com.lfy.ch01;

public class StringTest {

    public static void main(String[] args) {
        //StringBuilder【无锁，性能高】 性能 高于 StringBuffer【加锁，多线程安全。性能低】

        String s1 = "abc";
        String s2 = "abc";
        String s = s1 + s2;


        System.out.println("aaa "+ s1+" ddd "+s2+" dff");

        //1、把从1~1000000的数字拼接起来
        // 123456789101112131415161718192021...
        long start = System.currentTimeMillis();//获取当前时间戳（毫秒级别）
        String x = ""; // 字符串的不可变
        for(int i=1;i<=1;i++){
            x = x + i;  // 每次拼接，都会创建一个新的字符串对象； 10w个对象
        }
        long end = System.currentTimeMillis();
        System.out.println("拼接1~1000000数字耗费时间："+(end-start)+"ms");


        //复杂拼接。 StringBuilder； 多线程环境不安全
        StringBuilder sb = new StringBuilder();
        sb.append(""); // 给后面追加
        long start1 = System.currentTimeMillis();//获取当前时间戳（毫秒级别）
        for (int i = 1; i <= 100000; i++) {
            sb.append(i);  // 追加，不会创建新的对象. 1个对象 sb
        }
        long end1 = System.currentTimeMillis();
        System.out.println("StringBuilder 拼接1~1000000数字耗费时间：" + (end1 - start1) + "ms");



        // 所有的串，变量名，字符串常量，都在 常量池。
        String m = "123";  // 123字符串对象，保存到堆（常量池 "123"） 所在的地址  m = 123的地址
        m = "678";         // "678"字符串对象，保存到堆（常量池 "678"） 所在的地址  m = 678的地址

        //"雷丰阳"         //"雷丰阳"
        String name = "雷丰阳";  // 相同的串在常量池中，只保存一份。

        String xx = "雷";   //常量池中 “雷” 位置 0x7788
        xx += "风";         // 常量池中没有 “雷风” 字符串，位置 0x9988。

        xx = "雷阳";   // "雷阳"
        // 常量池中没有 “雷风阳” 字符串，位置 0x1234。



        //多线程下用，有锁
        StringBuffer sb1 = new StringBuffer();
        sb1.append("雷");
        sb1.append("风");
        sb1.append("阳");
        String name2 = sb1.toString();  // 把StringBuffer转换成字符串。
        System.out.println(name2);

        System.out.println("==>>>>>>>>>>>>>>>>>");

        String s3 = "雷12234";
        String substring = s3.substring(1, 3);
        System.out.println(s3);
        System.out.println(substring);

        System.out.println("==>>>>>>>>>>>>>>>>>");


        //面试题：
    }
}
