package com.lfy.ch01;

import org.junit.Test;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * 测试 各种List的源码实现
 * 1、ArrayList
 *    1）、底层数据结构（数组）：Object[] elementData；
 *    2）、创建
 *        1）、无参构造：创建一个长度为 0 的 Object[]数组
 *        2）、带容量构造：创建一个长度为 capacity 的 Object[]数组
 *    3）、添加元素：
 *       1. 如果第一次添加，数组是空的，调用 grow()扩容； 默认先扩容为 10
 *       2. elementData[size++] = 你的元素; size 代表 元素的个数
 *       3. 如果添加后，超过了数组的长度，调用 grow()扩容
 *          扩容的策略： 扩容为原来的 1.5 倍
 *          扩容后，拷贝原来的元素到新的数组中
 *   总结：工作原理：
 *      ArrayList 底层使用数组保存所有元素，第一次添加元素，会初始化长度为10 的null数组。
 *      每次添加进一个元素元素数量的size+1；如果数组不够，就调用grow()扩容，每次扩容为原来的 1.5 倍。
 *      扩容就是把老数组里面的每一个元素复制（值拷贝）到新数组中去。以后给新数组放元素。
 *      老数组会被置为null，等待垃圾回收。
 *   如何解决 ArrayList 的两大难？
 *     1）、扩容难；
 *     2）、添加/删除难；
 *
 * 2、LinkedList： 预习链表结构； 添加删除效率高
 */
public class Collection_SourceTest {


    // debug： 给程序打断点，然后一步一步调试源码; 可以让我们控制程序一行行的推进，我们就知道程序的执行流程
    @Test  // a(){  b();  } // 回看异常讲解部分
    public void testListSource(){

        List list = new ArrayList();



        // 不 debug 调试源码，我们直接看源码  ctrl + alt + 鼠标左键点击
        list.add(123);


        System.out.println("ArrayList 创建完成！");
    }


    public static void main(String[] args) {
        new Collection_SourceTest().a();
    }

    public void a(){
        System.out.println("a1");
        int i = b();
        System.out.println("a2："+i);
    }

    public int b(){
        System.out.println("b1");
        String x = c();
        System.out.println("b2:"+x);
        return 2;
    }

    public String c(){
        System.out.println("c");
        return "x";
    }


}
