package com.lfy.ch02;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

public class ThreadTest03 {

    public static void main(String[] args) throws ExecutionException, InterruptedException {
        //测试有返回值的异步任务
        System.out.println("主线程开始执行");

        //1、创建这个有返回值的异步任务
        MyCallable callable = new MyCallable();

        // FutureTask： 未来任务，未来有返回值的任务
        //2、用这个FutureTask包装这个callable；  FutureTask 本身就是 Runnable接口的实现类
        FutureTask<String> task = new FutureTask<>(callable);

        //3、启动线程，执行这个FutureTask
        new Thread(task).start();


        //4、获取异步任务的结果
        String s = task.get();// 这里会阻塞，直到异步任务执行完毕

        // 这个不阻塞
        System.out.println("主线程执行完毕： 后台结果："+s);

    }
}
