package com.lfy.ch06;

/**
 * 图形对象类： 抽象类，不能实例化
 * 1. 专门给人当爹的。
 *
 * 以前：
 *    1）、创建子类对象之前，父类对象会先创建。（【浪费空间】）
 * 现在：
 *    1）、利用抽象类不能实例化，只能被继承。（子类直接创建自己的对象）
 *
 * 抽象类可以只定义骨架，实现由子类完成。（和接口一样）
 */
public abstract class GraphicObject {
    int x, y; // 坐标


    abstract void draw(); // 抽象方法，子类必须实现。

    abstract void destroy(); // 抽象方法，子类必须实现。

    //移动方法: 已经写好逻辑，子类可以直接使用。
    public void moveTo(int newX, int newY) {
        //移动逻辑
        this.x = newX;
        this.y = newY;
    }



}
