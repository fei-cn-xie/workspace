package com.lfy.ch02.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class UdpClient {

    public static void main(String[] args) {
        //1、创建客户端的套接字
        try(DatagramSocket socket = new DatagramSocket(20000);) {
            System.out.println("客户端启动...准备发数据");
            InetAddress address = InetAddress.getByName("127.0.0.1");
            for (int i = 0; i < 20; i++) {
                String str = "你好：" + i;
                byte[] bytes = str.getBytes();
                // 说清楚 数据包的 内容、长度、目的地地址和端口号
                DatagramPacket packet = new DatagramPacket(bytes,bytes.length, address,10000);
                socket.send(packet);
                Thread.sleep(1000);
            }


        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
