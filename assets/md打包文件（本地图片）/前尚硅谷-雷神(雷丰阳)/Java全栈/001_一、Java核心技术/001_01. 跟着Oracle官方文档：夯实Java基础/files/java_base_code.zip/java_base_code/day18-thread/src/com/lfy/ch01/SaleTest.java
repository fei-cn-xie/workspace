package com.lfy.ch01;

/**
 * 三个窗口共同卖100张票
 * 1、写法1： SaleTicketWindow 卖出 300张
 */
public class SaleTest {

    public static void main(String[] args) {
        //1、三个窗口同时卖票
        SaleTicketWindow window1 = new SaleTicketWindow();
        SaleTicketWindow window2 = new SaleTicketWindow();
        SaleTicketWindow window3 = new SaleTicketWindow();

        //2、启动卖票
        window1.start();
        window2.start();
        window3.start();
    }
}
