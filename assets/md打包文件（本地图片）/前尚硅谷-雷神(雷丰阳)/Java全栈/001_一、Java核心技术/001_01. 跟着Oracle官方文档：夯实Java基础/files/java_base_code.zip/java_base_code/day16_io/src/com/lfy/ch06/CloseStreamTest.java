package com.lfy.ch06;

import java.io.*;

public class CloseStreamTest {



    // 如何优雅地关闭流？
    // try-catch-finally
    // try-with-resources：try的是开辟一些资源， 结束后，会自动帮你关闭资源
    // 资源的声明顺序和关闭顺序相反； [Oracle官网的写法：先关输入，后关输出;]  [市面上遵循的：先关输出，后关输入]
    public void closeStream2() throws IOException {


        // () 里面的所有资源，都必须是实现了 Closeable 接口的；
        try (
                FileInputStream fis = new FileInputStream("C:\\Users\\53409\\Desktop\\java_all_in\\视频\\day15 - IO流\\视频\\8、Java基础 - IO流 - 小练习：视频加解密.mp4");
                FileOutputStream fos = new FileOutputStream("C:\\Users\\53409\\Desktop\\hello.mp4");
                BufferedInputStream bis = new BufferedInputStream(fis);
                BufferedOutputStream bos = new BufferedOutputStream(fos);
        ){


            byte[] bytes = new byte[100]; // byte 就可以忽略大小了。多大都是交互内存；
            int len; // NIO（IO多路复用[后来讲]）：三大件：Channel、Buffer、Selector
            while ((len = bis.read(bytes)) != -1) {
                bos.write(bytes, 0, len);
            }

        }catch (Exception e){

        }

        // 不用在 finally 里写关闭流了。

    }


    /**
     * 标准写法
     * @throws IOException
     */
    public void closeStream() throws IOException {
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        try {
            FileInputStream fis = new FileInputStream("C:\\Users\\53409\\Desktop\\java_all_in\\视频\\day15 - IO流\\视频\\8、Java基础 - IO流 - 小练习：视频加解密.mp4");
            FileOutputStream fos = new FileOutputStream("C:\\Users\\53409\\Desktop\\hello.mp4");


            // 带缓冲区的 FileInputStream 和 FileOutputStream
            bis = new BufferedInputStream(fis);
            bos = new BufferedOutputStream(fos);


            byte[] bytes = new byte[100]; // byte 就可以忽略大小了。多大都是交互内存；

            int len; // NIO（IO多路复用[后来讲]）：三大件：Channel、Buffer、Selector
            while ((len = bis.read(bytes)) != -1) {
                bos.write(bytes, 0, len);
            }
            ;

        } catch (IOException e) {

        } finally {
            if(bis != null){
                bis.close();
            }

            if (bos != null){
                bos.close();
            }

        }


    }
}
