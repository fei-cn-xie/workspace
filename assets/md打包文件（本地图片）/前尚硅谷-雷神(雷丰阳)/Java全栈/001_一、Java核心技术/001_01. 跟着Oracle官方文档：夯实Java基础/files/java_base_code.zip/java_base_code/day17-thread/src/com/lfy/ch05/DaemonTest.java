package com.lfy.ch05;


/**
 * 线程生命周期
 */
public class DaemonTest {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("main线程执行...");

        //让他成为main的守护线程； 守护神...（主体灭亡，守护也结束）
        Thread thread = new Thread(() -> {
            while (true) { //看着代码，是永远执行
                try {
                    Thread.sleep(300);
//                    this.wait();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                System.out.println("daemon 守护线程....");
            }
        });

        //设置为守护线程
        thread.setDaemon(true);


        //线程开始
        thread.start();


        Thread.sleep(5000);

        System.out.println("main线程执行完毕...");

        // 多线程的资源竞争；  锁机制
        // 多个人 上厕所，只有一个坑位； 厕所门的就得有一把锁。

    }
}
