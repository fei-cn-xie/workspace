package com.lfy.ch01;


/**
 * 1、运行时异常：JVM不强制要求必须处理异常
 */
public class ErrorTest {

    public static void main(String[] args) {
//        new ErrorTest().a();

//        new ErrorTest().b(); // ArithmeticException: 算术异常（数学运算错误）
//        new ErrorTest().c(); // NullPointerException: 空指针异常（访问了null对象的方法或属性）
        new ErrorTest().d(); // ArrayIndexOutOfBoundsException: 数组索引（下标）越界异常（访问了不存在的位置）

    }

    // OutOfMemoryError: 堆内存溢出（创建的对象太多，对象太大了，内存装不下了）；
    // StackOverflowError： 递归太深，导致【栈溢出】；（方法嵌套调用太深了，栈撑不住了）
    public void a(){ //递归方法
        a();
    }


    public void b(){
        int i = 1/0;
    }

    public void c(){
        String s = null;
        s.length();
    }

    public void d(){
        int[] arr = {1,2,3,4};
        System.out.println(arr[0]); //
        System.out.println(arr[4]); // ArrayIndexOutOfBoundsException: 数组索引越界异常（访问了不存在的位置）

    }
}
