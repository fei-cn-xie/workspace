package com.lfy.ch02;


/**
 * Runnable： 可运行的
 * 表示一个可以在后台运行的任务  alt+enter
 */
public class MyRunnable implements Runnable{

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            System.out.println("后台执行...."+i);
        }
    }
}
