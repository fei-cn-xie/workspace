package com.lfy.ch04;

public class CharacterTest {

    public static void main(String[] args) {
        char c = 'a';
        Character ch = Character.valueOf('1');


        boolean letter = Character.isLetter(ch);
        System.out.println(letter);


        char upperCase = Character.toUpperCase(c);
        System.out.println(upperCase);

        char x = '\\';
        System.out.println(x);

        String s = "\\nabc";  //  \nabc
        System.out.println(s);

    }
}
