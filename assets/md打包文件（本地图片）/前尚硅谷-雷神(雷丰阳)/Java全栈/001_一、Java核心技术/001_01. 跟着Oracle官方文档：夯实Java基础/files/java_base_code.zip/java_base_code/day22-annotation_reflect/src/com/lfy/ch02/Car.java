package com.lfy.ch02;


// 引入 lombok； org.projectlombok:lombok:1.18.22
// idea 插件：Lombok Plugin

import lombok.*;


@AllArgsConstructor // 自动生成全参构造器
@NoArgsConstructor // 自动生成无参构造器
//@ToString // 自动使用所有属性生成 toString 方法
@EqualsAndHashCode // 自动使用所有属性生成 equals 和 hashCode 方法
@Data // 自动生成所有属性的 getter/setter 方法了；自带toString功能；
public class Car {

    private String brand;
    private String color;
    private int price;
    private String name;
}
