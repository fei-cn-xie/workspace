package com.lfy.java8.lambda;

/**
 * 所有函数式接口的对象创建，可以简单使用 Lambda 表达式。
 * 函数式接口： 只有一个抽象方法的接口。
 */
public class LambdaTest {

    public static void main(String[] args) {
        //接口创建对象：
        //1、写一个实现类；为实现类创建对象
        //2、不写实现类，直接创建对象； 匿名实现类
        HelloInterface hi = new HelloInterface() {
            @Override
            public void sayHello() {
                System.out.println("Say Hello!");
            }
        };


        //3、使用 Lambda 表达式：  (参数表) -> { 方法体 }
        HelloInterface hi2 = () -> {
            System.out.println("Say Hello!2222....");
        };

        //方法调用
        hi2.sayHello();

    }
}
