package com.lfy.ch04;

import java.math.BigDecimal;

public class BigDecimalTest {

    public static void main(String[] args) {
        System.out.println(0.01 + 0.09);


        BigDecimal a = new BigDecimal("0.01");
        BigDecimal b = new BigDecimal("0.09");


        BigDecimal add = a.add(b);
        System.out.println(add);


    }
}
