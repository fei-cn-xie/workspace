public class C06_ContinueDemo {
    public static void main(String[] args) {
        for (int i = 0; i < 5; i++) {
            if(i == 3){
                continue; //继续执行下次循环，后面for代码就不看了；
            }
            System.out.println(i);
        }


        System.out.println("=========");


        // i=0; i<5 => 打印 0； i=1
        // i=1; i<5 => 打印 1； i=2
        // i=2; i<5 => [xxx]； i=3
        // i=3; i<5 => 打印 3； i=4
        int i = 0;
        while (i < 5) {
            if (i == 2) {
                i++; // 必须手动更新，否则死循环在i=2
                continue;
            }
            System.out.println("i=" + i);
            i++;
        }


    }
}
