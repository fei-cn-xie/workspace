package com.lfy.ch04;

public interface USB2_0 {
    void transfer();
}
