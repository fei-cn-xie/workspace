package com.lfy.ch01;

public class ExceptionTest {

    public static void main(String[] args) {

        ExceptionTest test = new ExceptionTest();

        test.a();
        // a1
        // b1
        // c...
        // b2 Hello
        // a2:2

    }

    public void a(){
        System.out.println("a1");
        int i = b();
        System.out.println("a2："+i);
    }

    public int b(){
        System.out.println("b1");
        String c = c();
        System.out.println("b2："+c);
        return 2;
    }

    public String c(){
        int a = 0;
        System.out.println("c...");
        int i = 1/a; //在这修改代码逻辑即可; 编译器不检查这个代码
        return "Hello";
    }
}
