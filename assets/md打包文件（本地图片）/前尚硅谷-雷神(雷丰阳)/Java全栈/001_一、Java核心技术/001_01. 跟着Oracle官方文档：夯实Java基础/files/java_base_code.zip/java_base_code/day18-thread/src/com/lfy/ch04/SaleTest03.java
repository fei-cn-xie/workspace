package com.lfy.ch04;

public class SaleTest03 {

    public static void main(String[] args) throws InterruptedException {
        SaleTickV3 saleTickV3 = new SaleTickV3();
        new Thread(saleTickV3::sale,"窗口1").start();
        new Thread(saleTickV3::sale,"窗口2").start();
        new Thread(saleTickV3::sale,"窗口3").start();
        new Thread(saleTickV3::sale,"窗口4").start();
    }
}
