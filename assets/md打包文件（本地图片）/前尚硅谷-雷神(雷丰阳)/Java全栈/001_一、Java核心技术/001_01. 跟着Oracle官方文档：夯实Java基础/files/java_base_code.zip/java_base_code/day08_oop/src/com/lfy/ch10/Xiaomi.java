package com.lfy.ch10;

public class Xiaomi implements USB3_0, UPhone3_0{
    @Override
    public void call() {
        System.out.println("打电话...");
    }

    @Override
    public void fastTransfer() {
        System.out.println("快速传输...");
    }

    public static void main(String[] args) {
        Xiaomi xiaomi = new Xiaomi();
        xiaomi.call();
        xiaomi.fastTransfer();
        System.out.println("===================");


        // 前面类型限定，决定了你能掉哪些方法？调谁的方法看后面的对象是谁。 肯定调的是子类或者实现类的方法。
        USB3_0 xiaomi2 = new Xiaomi();
        xiaomi2.fastTransfer();


        UPhone3_0 xiaomi3 = new Xiaomi();
        xiaomi3.call();
    }
}
