package com.lfy.ch01;


import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.concurrent.TimeUnit;

/**
 * 应用启动，一个Java的进程就启动了;
 * C:\Users\53409>jps
 * 22000
 * 25328 Jps
 * 26580 Launcher
 * 9644 ThreadDemo
 * 进程id    应用名
 *
 * 1、后来我们的所有代码都是在这个进程中运行的（有可能会额外的开线程运行）
 * 2、应用只要开始执行，操作系统会分配一个进程给这个应用（包含了应用的执行环境[jvm]）
 * 3、每个Java应用启动，就是启动一个JVM进程
 * 4、每个Java应用启动，至少有一个main线程在运行
 */
public class ThreadDemo {


    //银行：  银行内部 10个服务员，10个窗口轮流服务客户（线程）
    // 一个线程类似一个服务员
    public static void main(String[] args) throws InterruptedException {
        System.out.println("a");
        //中间做事： 3s
        //同步执行（阻塞）： b 3s 以后打印
        //异步执行（非阻塞）： 打印b不用等待。打印A后立即执行
        new Thread(() -> {
            try {
                Thread.sleep(3000); // main 当前自己休眠3s
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }).start(); //异步的。

       System.out.println("b");
    }

    // main线程在运行
    public static void aaaa(String[] args) throws InterruptedException, IOException {
        new Thread();
//        System.out.println("main start");
//        //休眠
//        Thread.sleep(100000);

        // 单核CPU：很多任务看起来是都在执行，其实是交替执行

        //Java启动别的进程; Java调用底层能力，启动一个进程
        ProcessBuilder processBuilder = new ProcessBuilder("ping", "baidu.com");
        processBuilder.redirectErrorStream(true); // 合并标准错误和标准输出

        // 启动进程
        Process process = processBuilder.start();


        // 读取进程的输出
        try (BufferedReader reader = process.inputReader(Charset.forName("GBK"));) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        }

        // 设置超时并等待进程结束（最多等待10秒）
        if (!process.waitFor(10, TimeUnit.SECONDS)) {
            process.destroyForcibly();
            throw new RuntimeException("Netstat command timed out");
        }
        // 检查退出码
        int exitCode = process.exitValue();
        if (exitCode != 0) {
            throw new IOException("Netstat command failed with exit code: " + exitCode);
        }
    }
}
