package com.lfy.ch04;

public class ThreadJoinTest {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("main start...");

        // 多核CPU，线程后面后台并行运行

        // 创建第一个工作线程
        Thread worker1 = new Thread(() -> {
            try {
                Thread.sleep(1000); // 模拟耗时操作
                System.out.println("📦 Worker 1: 包裹打包完成");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        // 创建第二个工作线程
        Thread worker2 = new Thread(() -> {
            try {
                Thread.sleep(2000); // 更长的耗时操作
                System.out.println("🚚 Worker 2: 包裹运输完成");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });


        // 启动线程
        worker1.start();
        worker2.start();



        //2、想等 worker1/worker2 执行完毕后，再继续执行下面的代码

        // worker1 执行需要 1s
        worker1.join(); // 让当前线程等待 worker1 完成
        System.out.println("✅ 老板: 包裹打包已确认完成");


        // worker2 执行需要 2s
        worker2.join(); // 让当前线程等待 worker2 完成
        System.out.println("✅ 老板: 包裹运输已确认完成");
        System.out.println("🎉 老板: 订单处理完毕！客户已通知");


        // 如果多个线程，我们需要等他们都完成，我们只需要等待一个最长时间

        System.out.println("main end...");

    }
}
