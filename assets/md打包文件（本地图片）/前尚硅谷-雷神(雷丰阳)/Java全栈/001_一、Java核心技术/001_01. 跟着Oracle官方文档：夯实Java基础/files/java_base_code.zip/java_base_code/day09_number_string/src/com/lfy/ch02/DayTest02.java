package com.lfy.ch02;

public class DayTest02 {
    public static void main(String[] args) {
        Day monday = Day.MONDAY;

        // 别人会给我传递一个字符串 monday； 把这个字符串转化成枚举类型

        //传递一个和 枚举名字 一模一样的字符串，就可以得到枚举类型的对象
        Day sunday = Day.valueOf("SUNDAY");
        System.out.println(sunday);

//
//        Season spring = Season.valueOf("SPRING");
//        System.out.println(spring.getSeasonName());


        //能适配中文系统
//        Season s = Season.valueOf("春");
//        System.out.println(s);


        //用类调用的，必须写一个静态方法
        Season.valueOf("春");
    }

//    public static Day getDay(String day) {
//
//    }
}
