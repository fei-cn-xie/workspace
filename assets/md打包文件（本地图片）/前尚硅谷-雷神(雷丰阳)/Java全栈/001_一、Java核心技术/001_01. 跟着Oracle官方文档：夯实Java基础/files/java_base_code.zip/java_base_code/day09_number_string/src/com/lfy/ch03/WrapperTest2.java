package com.lfy.ch03;

public class WrapperTest2 {
    public static void main(String[] args) {
        int parsedInt = Integer.parseInt("456");
        System.out.println("parseInt(\"456\") → " + parsedInt);

        // 2. 字符串转Integer对象
        Integer value = Integer.valueOf("789");
        System.out.println("valueOf(\"789\") → " + value);

        // 3. int转字符串
        String intStr = Integer.toString(123);
        System.out.println("toString(123) → " + intStr);

        // 4. 比较两个数字
        int compareResult = Integer.compare(5, 10);
        System.out.println("compare(5,10) → " + compareResult + " (5<10)");

        // 5. 求和
        int sumResult = Integer.sum(3, 5);
        System.out.println("sum(3,5) → " + sumResult);

        // 6. 最大值/最小值
        System.out.println("max(10,20) → " + Integer.max(10, 20));
        System.out.println("min(10,20) → " + Integer.min(10, 20));

        // 7. 字节反转（十六进制展示）
        int reversedBytes = Integer.reverseBytes(0xAABBCCDD);
        System.out.println("reverseBytes(0xAABBCCDD) → 0x" +
                String.format("%08X", reversedBytes));

        // 8. 统计二进制1的个数
        System.out.println("bitCount(9) → " + Integer.bitCount(9) + " (9=1001)");

        // 9. 统计前导零
        System.out.println("numberOfLeadingZeros(8) → " +
                Integer.numberOfLeadingZeros(8) + " (8=000...1000)"); // int 32； 28个前导0

        // 10. 进制转换
        System.out.println("toBinaryString(15) → " + Integer.toBinaryString(15));
        System.out.println("toHexString(15) → " + Integer.toHexString(15));
        System.out.println("toOctalString(15) → " + Integer.toOctalString(15));
    }
}
