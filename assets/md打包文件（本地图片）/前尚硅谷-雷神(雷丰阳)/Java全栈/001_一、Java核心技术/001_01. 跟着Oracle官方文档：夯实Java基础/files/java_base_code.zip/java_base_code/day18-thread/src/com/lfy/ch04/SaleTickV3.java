package com.lfy.ch04;

public class SaleTickV3 {

    private int ticketNum = 100; //实例变量，跟着对象走



    // 多线程：如果没有竞争，不加锁，效率高；如果有竞争，【加锁】，反而效率比单线程串行还低。
    // 解决竞争就需要加锁； 把并发（多个一起执行）变成了串行（一个一个执行）
    // 多个线程对同一个 ticketNum 产生竞争，导致超卖；
    // 业务功能
    public void sale(){
        // 思考：为什么会超卖？
        while (ticketNum > 0){
            try {
                Thread.sleep(100); // 放大错误，结果卖了 168 张
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread().getName() + " 卖出一张，剩余：" + --ticketNum);
        }
    }

    public int getTicketNum() {
        return ticketNum;
    }
}
