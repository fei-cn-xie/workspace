package com.lfy.ch06;

public class ObjectTest {
    public static void main(String[] args) {
//        GraphicObject graphicObject = new GraphicObject();
    }
}
