package com.lfy.ch03;

import java.util.Comparator;


/**
 * 比较器：比较商品的价格的类
 */
public class GoodsComparator implements Comparator<Goods> {
    @Override
    public int compare(Goods o1, Goods o2) {
        return (int)(o1.getPrice() - o2.getPrice());
    }
}
