package com.lfy.ch09;


// Ctrl + N： 搜索Java的某个类、接口等
// Ctrl + F12: 查看当前类的所有成员
// Object类： 有toString()、equals(Object obj)、hashCode()等方法

import java.util.Objects;

public class PersonHah{
    private String name;
    private int age;


    // 对这个类创建出来的对象的描述。给人看的，便于调试。
//    @Override
//    public String toString() {
//        return "PersonHah的信息是：名字name=（"+name+"）； 年龄age=（"+age+"）";
//    }


    // equals 和 hashCode 方法必须一起重写，而且自动生成。 alt + insert

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PersonHah personHah)) return false;
        return getAge() == personHah.getAge() && Objects.equals(getName(), personHah.getName());
    }

    @Override
    public int hashCode() { // 每个对象的唯一id（identify【身份证号】）。
        // 每个属性的hashCode（），然后组合到一起。算出整个对象的hashCode（）值。
        return Objects.hash(getName(), getAge());
    }

    /**
     * 正确重写equasl步骤：
     * 1. 检查是否为同一对象（if (this == o)）。
     * 2. 检查对象类型是否一致（if (o == null || getClass() != o.getClass())）。
     * 3. 强制类型转换后逐个比较关键属性。
     * @param obj
     * @return
     */
//    @Override
//    public boolean equals(Object obj) {
//        // a.equals(b)
//        //1、内存地址
//        if (this == obj) return true;
//
//
//        //2、类型不一样就返回false
//        if(obj == null || this.getClass() != obj.getClass()){
//            return false;
//        }
//
//        //3、类型转换过来，再比较属性
//        PersonHah person = (PersonHah) obj;
//
//        // 比较属性值是否相等
//        return this.name.equals(person.name) && this.age == person.age;
//    }



    public PersonHah(){

    }

    public PersonHah(String name, int age) {
        this.name = name;
        this.age = age;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public static void main(String[] args) {
        PersonHah zhangsan1 = new PersonHah("张三", 20);

        PersonHah zhangsan2 = new PersonHah("张三", 20);


        // 对象==，比较的是内存地址。必然不等
        System.out.println(zhangsan1 == zhangsan2);

        // 判断两个对象的内容是否相等，用的是equals方法
        System.out.println(zhangsan1.equals(zhangsan2));

        // 打印对象hashCode值（内存地址）: Tab 自动补全
        System.out.println(zhangsan1);


    }
}
