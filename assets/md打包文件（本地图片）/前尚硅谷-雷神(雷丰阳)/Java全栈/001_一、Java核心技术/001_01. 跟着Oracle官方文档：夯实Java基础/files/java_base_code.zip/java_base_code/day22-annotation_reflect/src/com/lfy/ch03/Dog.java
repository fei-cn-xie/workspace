package com.lfy.ch03;


import com.lfy.ch01.Leifengyang;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Leifengyang(age = 10)
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Dog extends Animal implements Safe<Integer> {
    public String hello;
    private String name;
    private int age;


    // 不让人直接调用该方法，每次由框架自己反射执行；
    // 1、获取当前用户信息，是否admin； 放到if中执行
    // method.invoke();
    // 2、打印日志，疑似入侵行为
//    @Admin
    public void eat() {
        System.out.println("狗狗【"+name+"】在...eat");
    }


//    @Anyone
    private void walk(String street) {
        System.out.println("狗狗【"+name+"】在...【"+street+"】散步");
    }

    @Override
    public Integer safe() {
        System.out.println("狗狗【"+name+"】已经打1针疫苗了");
        return 1;
    }
}
