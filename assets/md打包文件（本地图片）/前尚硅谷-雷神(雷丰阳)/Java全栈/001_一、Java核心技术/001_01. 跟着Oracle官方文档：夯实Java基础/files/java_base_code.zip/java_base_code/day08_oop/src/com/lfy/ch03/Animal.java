package com.lfy.ch03;


/**
 * 子继承父： 父类私有的不能继承，剩下都能继承
 */
// 动物
public class Animal {
    // 公共属性（protected 允许子类直接访问）
    String name; //受保护

    // 父类构造方法
    public Animal() {
        System.out.println("Animal 构造方法执行...");
    }

    // 公共方法（子类可继承）
    public void eat() {
        System.out.println(name + "正在吃东西...");
    }

    public static void sayHello(){
        System.out.println("Animal .... Hello");
    }
}
