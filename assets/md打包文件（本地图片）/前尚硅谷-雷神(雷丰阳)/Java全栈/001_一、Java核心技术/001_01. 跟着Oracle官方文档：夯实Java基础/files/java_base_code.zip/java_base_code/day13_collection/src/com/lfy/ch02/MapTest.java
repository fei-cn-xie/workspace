package com.lfy.ch02;

import org.junit.Test;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;


/**
 * Map保存 K-V 映射关系的；
 * 1）、Key 不可重复，重复就会覆盖之前的值
 * 2）、Value 可以重复
 *
 * Map 优点：
 * 1、KV映射存储
 * 2、按照 Key 找 Value 特别快。
 * 3、单独提取 Key、单独提取 Value；
 */
public class MapTest {


    @Test
    public void testMapQuery(){
        Map map = new HashMap();
        map.put("张三","13800138000");
        map.put("李四","13900138000");
        map.put("王五","13700137000");
        map.put("赵柳","13700137000");


        //1、手机号 139 开头，给他们发送短信，说你中奖了
        System.out.println(map);

        //2、遍历Map
        //1）、遍历所有的 键值（一对KV组合，人家称为一个 Entry[条]）
        Set entrySet = map.entrySet();
        for (Object o : entrySet) {
            // 一条数据是 key + value 组成的对象，叫 Entry
            Map.Entry entry = (Map.Entry) o;
            Object key = entry.getKey();
            Object value = entry.getValue();
            if(value.toString().startsWith("139")){
                System.out.println("恭喜你【"+key+"】，中奖了");
            }
            System.out.println("key:"+key+" ；value:"+value);
        }


        //2）、拿到Map中所有的 Key（键）
        Set keySet = map.keySet();
        for (Object o : keySet) {
            System.out.println("key~:"+o);
            Object o1 = map.get(o);
            System.out.println("value~:"+o1);
        }

        //3）、拿到Map中所有的 Value（值）
        Collection values = map.values();
        for (Object value : values) {
            System.out.println("值是："+value);
            // 通过值，不能直接快速知道是哪个Key（除非自己挨个遍历判断）；
        }


    }


    /**
     * 测试一个类的对象能调用哪些方法；测试 API（Application Programming Interface）【预定义好的一堆功能】
     */
    @Test
    public void testMap(){
        // 每次保存的是键值对，（Key - Value） y=f(x) （一一映射关系）
        Map map = new HashMap();
        //1、人和手机号； {A,B,C}
        // 1)、用手机号，查找这个人，以及详细信息
        // 2)、用人的名字，查找手机号
        map.put("张三","13800138000");
        map.put("李四","13900138000");
        map.put("王五","13700137000");

        System.out.println(map);

        //2、查询张三手机号
        Object o = map.get("张三");
        System.out.println(o);
        Object o1 = map.get("13800138000");
        System.out.println(o1);

        Object tq = map.get("田七");
        System.out.println("田七手机号："+tq);

        //如果有返回真正值，没有返回默认值(假的值: 随便返回一个值，不至于后面空指针异常出错，不至于崩溃)；
        //虽然返回默认值，但是不代表Map中有这个键，只是返回了一个默认值；
        Object qq = map.getOrDefault("田七", "13800138009");
        System.out.println("田七手机号（带默认）："+qq);
        System.out.println(map);

        //3、修改; put 增加和之前一样的键，则会覆盖之前的值
        map.put("张三", "13800138001");
//        map.putAll(map);
        System.out.println(map);
        map.replace("张三","13800138002");
        System.out.println(map);

        //4、判断如果没有再保存

        if(map.containsKey("王五")){
            System.out.println("有这个键，不保存了");
        }else {
            map.put("王五","13700137001");
        }
        System.out.println(map);

        //5、判断有没有 + 保存 二合一; putIfAbsent没有就保存，有就不保存
        map.putIfAbsent("赵柳","139900137002");
        System.out.println(map);



        //6、删除
        map.remove("张三");
        System.out.println(map);



    }
}
