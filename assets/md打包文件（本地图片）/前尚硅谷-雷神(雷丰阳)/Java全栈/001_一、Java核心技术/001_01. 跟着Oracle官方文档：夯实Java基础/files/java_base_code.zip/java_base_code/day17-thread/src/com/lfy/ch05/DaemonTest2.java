package com.lfy.ch05;


/**
 * 守护线程： 守护的是[用户线程]（整个应用进程），一旦所有的用户线程都结束了，守护线程也会随之结束。
 * 如果想要实现某个线程结束后，某个守护结束
 * 1）、使用 interrupt 方式
 * 2）、使用 回调机制 方式（Redisson 续期【看门狗守护取消掉】）
 *
 * 守护线程：守护的都是main。main结束就全结束。守护其他线程不能用 setDaemon 方式。
 */
public class DaemonTest2 {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("主线程：开始...");
        Thread thread = new Thread(()->{
            System.out.println("大号线程：开始....");

            // 这种写法也是守护的main
            Thread thread1 = new Thread(()->{
                while (true){
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException e) {
//                        throw new RuntimeException(e);
                    }
                    System.out.println("小号守护线程：运行中....");
                }
            });
            thread1.start();


            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
//                throw new RuntimeException(e);
            }
            // 打断不一定
            thread1.interrupt();
            System.out.println("大号线程：结束....");
        });

//        thread.setDaemon(true);
        thread.start();



        // 模拟main方法执行很久
        Thread.sleep(5000);
        System.out.println("主线程：结束...");


    }
}
