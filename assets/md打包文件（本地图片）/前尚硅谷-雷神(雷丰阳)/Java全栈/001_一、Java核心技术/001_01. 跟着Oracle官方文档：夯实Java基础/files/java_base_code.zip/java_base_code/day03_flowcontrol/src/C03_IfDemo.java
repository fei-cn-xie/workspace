/**
 * IF 走哪个分支
 * 1、如果18岁了，我就工作
 * 2、如果18岁了，我就工作，否则，我就好好学习
 */
public class C03_IfDemo {

    public static void main(String[] args) {
        int age = 22;
        //1、单if： age > 18 ： 真假
        if (age > 18) {
            System.out.println("我要去工作");
        }


        //2、if-else
        if (age > 18){ //如果真，则执行下面
            System.out.println("我要去工作");
        }else { //否则
            System.out.println("我要去学习");
        }


        //3、if-else if - else很多种； ABCD
        // 90分以上：A
        // 80-90：  B
        // 60-80：  C
        // 60以下：  D
        int score = 65;
        if (score > 90){
            System.out.println("A");
        }else if (score > 80 ){ //能走到这里，已经小于90了
            System.out.println("B");
        }else if(score > 60){ //能走到这里，已经小于80了
            System.out.println("C");
        }else { //以上都不满足
            System.out.println("D");
        }


        //判断下面的写法是否正确； 条件一定是从小范围给大范围扩
        if (score > 90){
            System.out.println("A");
        }else if (score > 80 ){ //能走到这里，已经小于90了
            System.out.println("B");
        }else if(score > 60){ //能走到这里，已经小于80了
            System.out.println("C");
        }else { //以上都不满足
            System.out.println("D");
        }






        int health = 75; //血量
        boolean hasKey = true; //要是
        boolean foundExit = false; //是否找到出口

        if (health > 0) { // 外层条件：角色是否存活
            System.out.println("角色存活！");
           if(hasKey){ //说明有钥匙
               if (foundExit){
                   System.out.println("终于要出去了...");
               }else {
                   System.out.println("继续找出口");
               }
           }else {
               System.out.println("需要找到钥匙");
           }

        } else {
            System.out.println("角色已死亡，游戏结束。");
        }




    }
}
