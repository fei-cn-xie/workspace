package com.lfy.optional;

import org.junit.Test;

import java.util.Optional;
import java.util.function.Consumer;


/**
 * com.lfy.math
 */
public class OptionalTest {



    //1、拿到 Optional 对象

    @Test
    public void test(){
        String hello1 = getHello();
        if (hello1 != null){
            System.out.println("以前统计字符串长度："+hello1.length());
        }else {
            hello1 = "hello";
        }

        // 后面使用 hello1 有默认值。


        //1、利用一个值得到的 Optional 对象
        //  ofNullable： 放入一个值，如果为空，返回一个空的 Optional 对象
        // 1）、Optional.of()： 里面必须放入一个非空的值
        // 2）、Optional.ofNullable()： 如果放入的值是 null，返回一个空的 Optional 对象
        Optional<String> hello = Optional.ofNullable(getHello());


        // 如果方法有返回值，打印. 如果方法没返回值，给他一个默认值。
//        Consumer consumer = System.out::println;
        hello.ifPresent(System.out::println);
        hello.ifPresentOrElse(System.out::println, ()-> System.out.println("hello"));

        // Optional 提供检测方法、提供分支逻辑
        boolean present = hello.isPresent();
        boolean empty = hello.isEmpty();
        System.out.println(present);
        System.out.println(empty);


        // 使用 orElse 提供默认值
        String abc = hello.orElse("666");
        System.out.println("abc："+abc);


        //2、快捷处理NPE且给默认值
        String str = Optional.ofNullable(getHello())
                             .orElse("888");
        System.out.println("str："+str);

    }

    public String getHello(){
//        return "nullxxxxx";
        return null;
    }
}
