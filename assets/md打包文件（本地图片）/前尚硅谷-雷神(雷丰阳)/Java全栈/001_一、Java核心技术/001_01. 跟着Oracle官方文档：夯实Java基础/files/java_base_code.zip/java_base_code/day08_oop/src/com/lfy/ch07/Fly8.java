package com.lfy.ch07;

public interface Fly8 {

    default void flyOnLand(){
        System.out.println("在陆地上飞");
        fly();
    };
    default void flyInSky(){
        System.out.println("在天空中飞");
        fly();
    };
    default void flyInSpace(){
        System.out.println("在太空中飞");
        fly();
    };

    void fly();
}
