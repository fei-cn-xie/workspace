package com.lfy.ch04;


// 问题：++i 不是原子操作，导致并发问题；
// 1）、多个线程都在执行第一步操作。
// volatile 关键字可以保证内存可见性，可以禁止指令重排序，但是不能保证操作的原子性（多个步骤，不可被分割）。
public class Counter {


    // 即使内存可见，++ 也有问题
    private volatile int count = 0;

    //        Thread.sleep(1);
//        count++;
    //其实是3步：
    //1、读count  // 多个人同时走这一行  100
    //2、算count  // 101
    //3、改count  // 101
    public synchronized void increment() throws InterruptedException {
        count++;
    }

    public int getCount() {
        return count;
    }
}
