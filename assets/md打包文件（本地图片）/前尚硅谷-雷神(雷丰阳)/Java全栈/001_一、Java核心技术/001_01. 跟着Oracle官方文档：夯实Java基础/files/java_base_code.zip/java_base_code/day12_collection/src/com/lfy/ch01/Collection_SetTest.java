package com.lfy.ch01;

import org.junit.Test;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Set： 无序，不重复的集合
 */
public class Collection_SetTest {

    @Test
    public void testSet(){
        //多态写法； 依赖倒置原则： 依赖规范，不依赖具体实现
        Set set = new HashSet();
        set.add("A");
        set.add("B");
        set.add("C");
        set.add("D");
        set.add("E");
        set.add("F");
        set.add(1);
        set.add(2);
        set.add(3);

        System.out.println("初始："+set);
        set.add("B");
        System.out.println("添加重复元素："+set);

        for (Object o : set) {
            System.out.println(o);
        }


        // 集合中元素的个数
        int size = set.size();
        System.out.println("size:"+size);

        set.remove("B");
        System.out.println("删除元素："+set);

        set.removeAll(Set.of("A","B"));

        int size2 = set.size();
        System.out.println("size:"+size2);


        Iterator iterator = set.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }

    }
}
