package com.lfy.ch01;

import java.io.FileInputStream;

public class DataTest {


    public static void main(String[] args) {

        ShareDataOne dataOne = new ShareDataOne();

        for (int i = 0; i < 5; i++) {
            new Thread(()->{
                try {
                    dataOne.increment();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            },"A-"+i).start();
        }

    }
}
