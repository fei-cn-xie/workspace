package com.lfy.ch03;

import java.text.DecimalFormat;

/**
 * 专门用来格式化数字：DecimalFormat
 */
public class DecimalFormatTest {
    public static void main(String[] args) {
        //1、"###,###.###", 123456.789

        double num = 122344456.7;
        System.out.println(num);

        //1、创建指定格式的格式化器
        DecimalFormat df = new DecimalFormat("###,###.###");
        //2、格式化数字
        String format = df.format(num);
        //3、获取格式化后的字符串
        System.out.println(format);


        //2、 ###.##
        DecimalFormat df2 = new DecimalFormat("###.##");
        String format1 = df2.format(num);
        System.out.println(format1);

        //3、"000000.000"
        DecimalFormat df3 = new DecimalFormat("000000.000");
        String format2 = df3.format(num);
        System.out.println(format2);

        //4、 $###,###.###
        DecimalFormat df4 = new DecimalFormat("$###,###.###");
        String format3 = df4.format(num);
        System.out.println(format3);


    }
}
