package com.lfy.ch1;


/**
 * 1、本类内部，无论任何权限修饰符，大家都能用
 * 2、本包内部，privte别人调用不了，剩下的都可以
 * 3、其他包。 private 和 默认，都调用不了。 protected 和 public 可以调用。
 *      protected: 其他包的子类，也能调用。
 *      public: 万物都能
 *
 *
 */
public class Hello {

    private int age = 10;

    protected String name = "张三";

    /**
     * public：（万物皆可调）只要导入这个类，就能使用这个【方法、属性、构造器】等。
     *
     */
   protected void haha(){
        System.out.println("哈哈哈哈：age = " +age);
    }


    public void heihei(){
        haha();
    }
}
