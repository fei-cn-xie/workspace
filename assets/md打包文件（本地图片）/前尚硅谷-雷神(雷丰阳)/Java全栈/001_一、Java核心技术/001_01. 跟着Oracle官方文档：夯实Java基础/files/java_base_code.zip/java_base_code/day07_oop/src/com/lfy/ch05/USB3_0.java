package com.lfy.ch05;


/**
 * USB3.0接口
 * 1. 接口里面成员变量都是常量不可被改
 */
public interface USB3_0 {

    //定义的成员变量必须是【常量】 public static final String SPEED = "100MB/s";
    String SPEED = "100MB/s";  // 这个东西不可以再次赋值（常量）


    //【抽象方法】（默认 public abstract） public abstract void transfer();
    void transfer(int a,int b); //规定U盘如何传输数据. 需要有人去实现（实现类）


    //默认方法（Java 8+，有方法体）: default 关键字编写默认的实现；
    default void fastTransfer() { // 即使没有任何是去实现，默认方法也提供了实现细节。
        accerlate10(10);
        System.out.println("默认快速传输数据");
    }




    // 以下的东西；以前类怎么规定的，接口就怎么规定
    //静态方法（Java 8+）: static关键字编写； USB3_0.test();
    static void testFast() {
        System.out.println("测试快速静态方法");
    }

    // 私有方法（Java 9+，只能在接口内部调用）
    private int accerlate10(int speed) {
        testSlow();
        return speed*10;
    }



    // 非static 可以调用 static; 反之不行
    private static void testSlow() {
        System.out.println("测试慢速静态方法");
    }




}
