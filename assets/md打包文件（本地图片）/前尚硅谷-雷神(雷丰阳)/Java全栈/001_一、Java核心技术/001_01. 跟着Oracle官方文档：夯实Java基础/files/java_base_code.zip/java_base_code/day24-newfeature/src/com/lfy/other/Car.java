package com.lfy.other;

public record Car(String name, String color) {
}
