package com.lfy.ch02;


/**
 * 第一种创建线程的方式： 实现Runnable接口； 启动 new Thread(new MyRunnable()).start();
 * 第二种创建线程的方式： 继承Thread类；  启动 new MyThread().start();
 *
 * ======= 以上 都是需要实现 Runnable接口规定的 run 方法 =======
 * 由于以上的方式，都是重写 run 方法。 run方法签名（如何定义）： void run(); 没有参数，没有返回值
 *
 * 第三种创建线程的方式： 实现Callable接口；
 *
 *
 */
public class ThreadTest02 {
    public static void main(String[] args) {
        System.out.println("主线程开始执行");

        //new Thread().start();

        MyThread myThread = new MyThread();

        //异步启动
//        myThread.start();

        //同步执行，不会开启新线程； 就是调用一个普通方法，在当前线程中执行。
        myThread.run();

        System.out.println("主线程执行完毕");
    }
}
