package com.lfy.ch02;

public class SaleTest {

    public static void main(String[] args) {
        // Runnable： 可以跑的异步任务
        Runnable r = new SaleTicket();
//        Runnable r2 = new SaleTicket();
//        Runnable r3 = new SaleTicket();

        //多个线程卖不同的票
//        new Thread(r).start();
//        new Thread(r2).start();
//        new Thread(r3).start();

        new Thread(r, "窗口1").start();
        new Thread(r, "窗口2").start();
        new Thread(r, "窗口3").start();

    }
}
