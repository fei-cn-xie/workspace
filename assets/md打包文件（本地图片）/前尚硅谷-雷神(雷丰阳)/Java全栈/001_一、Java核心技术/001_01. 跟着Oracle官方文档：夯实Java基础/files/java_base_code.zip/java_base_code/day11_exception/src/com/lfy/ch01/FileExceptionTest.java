package com.lfy.ch01;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class FileExceptionTest {

    public static void main(String[] args) throws Exception{
        test(); //调用者感知到异常，必须处理
    }


    // 1、使用throws声明方法将会抛出异常，但是本方法自己不处理。调用者自己想办法处理
    public static void test() throws FileNotFoundException {

        //编译时异常，编译不通过
        //1、用 try...catch 捕获异常，并自己处理; 别人不会感知到你的任何异常。
//        try {
//            new FileInputStream("a.txt");
//        }catch (Exception e) {
//            System.out.println("文件不存在");
//        }

        //2、在方法上声明抛出异常，让别人感知到你的异常。
        FileInputStream fileInputStream = new FileInputStream("a.txt");

        //继续敲；

    }
}
