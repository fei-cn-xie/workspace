package ch01.haha.hehe;

public class C {
}
