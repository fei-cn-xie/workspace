package com.lfy.ch03;

import java.util.Arrays;

public class GoodsTest {
    public static void main(String[] args) {
        Goods goods1 = new Goods("小米1", 1000);
        Goods goods2 = new Goods("小米2", 2999);
        Goods goods3 = new Goods("小米3", 1788);
        Goods goods4 = new Goods("小米4", 1300);
        Goods goods5 = new Goods("小米5", 3500);
        Goods goods6 = new Goods("小米6", 5100);

        Goods[] goodsArr = {goods1, goods2, goods3, goods4, goods5, goods6};

        //系统退出
        System.exit(0);
        //系统垃圾回收
//        System.gc();



        //自己串一个比较器
        GoodsComparator comparator = new GoodsComparator();
        //使用自定义的比较器进行排序
        Arrays.sort(goodsArr,comparator);

        for (Goods goods : goodsArr) {
            System.out.println(goods.getName() + "的价格是：" + goods.getPrice());
        }

        System.out.println("===============");

        // 字符串比较规则：小长度在前，大长度在后；  小字母在前，大字母在后；
        // 1、串长度相等，比较内容
        //    1）先比较第一个字符，依次比较
        // 2、串长度不等，比较长度
        //

    }
}
