package com.lfy.ch04;

public class Company {

    private LfyUSB lfyUSB;


    /**
     * 向上的类型，父类
     * 设计模式：依赖倒置原则； 依赖抽象，不依赖具体实现类
     */
    private USB3_0  usb3_0 = new LfyUSB();




}
