package com.lfy.ch03;


import org.junit.Test;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.*;

/**
 * 测试 Path 类
 * 1、Path 接口，代表一个平台无关的路径； Paths 工具类，提供静态方法来创建 Path 对象
 */
public class PathTest {





    @Test
    public void testPath02() throws IOException {
        Path path = Paths.get("E:\\dev\\soft\\Trae CN\\Trae CN.exe");

        // 检查文件是否存在
        boolean exists = Files.exists(path);
        System.out.println(exists);

        // 检查是否为目录/常规文件
        boolean isDir = Files.isDirectory(path);
        System.out.println("文件夹?"+isDir);
        boolean isFile = Files.isRegularFile(path);
        System.out.println("文件?"+isFile);

        // 获取文件大小（需处理IOException）
        //        long size = Files.size(path);

        long size = Files.size(path);
        System.out.println("文件大小：" + size );



        Path path2 = Paths.get("/home/user/documents/report.pdf");

        // 遍历路径的每一部分
        for (Path element : path2) {
            System.out.println("元素: " + element);
        }

        // /home/documents
        Path p1 = Paths.get("/home/./user/../documents/");
        Path p2 = Paths.get("/home/documents");

        // 规范化路径：去掉多余的 . 和 ..  /home/documents
        Path normalize = p1.normalize();
        System.out.println(normalize);

    }

    @Test
    public void testURI() throws IOException {
        Path base = Paths.get("E:\\dev\\soft");
        //1、转成URI访问位置；  file:///C:/home/user; 直接粘到浏览器上访问；
        // https://www.jd.com/
        URI uri = base.toUri();
        System.out.println(uri);

        //2、返回绝对路径，没有协议；
        Path absolutePath = base.toAbsolutePath();
        System.out.println(absolutePath);

        //3、返回真实路径； 必须存在； 不存在会抛出异常
        Path realPath = base.toRealPath();
        System.out.println(realPath);

    }

    @Test
    public void testPath03() throws URISyntaxException {
        // 在linux下，以 / 开头，在windows下以盘符开头 C:/ 开头； 都是绝对路径
        Path base = Paths.get("/home/user");
        Path target = Paths.get("/home/user/documents/file.txt");

        Path relativize = base.relativize(target);// 相对路径：documents/file.txt
        System.out.println(relativize);


        // 算出绝对路径
        Path resolve = base.resolve(relativize);// 绝对路径： /home/user/documents/file.txt

        System.out.println(resolve);
    }


    @Test
    public void testPath1() throws IOException {
        Path path = Paths.get("E:\\dev\\soft\\Trae CN\\Trae CN.exe");

        System.out.println("文件名：" + path.getFileName());
        System.out.println("根路径：" + path.getRoot());
        System.out.println("父目录：" + path.getParent());


        // 整个磁盘：
        FileSystem fileSystem = path.getFileSystem();
        System.out.println("文件系统：" + path.getFileSystem());


        //文件存储：磁盘分区：
        Iterable<FileStore> fileStores = fileSystem.getFileStores();

        for (FileStore fileStore : fileStores) {
            // 空间以字节为单位； b --1024-- kb -- 1024 -- mb -- 1024 -- gb
            System.out.println(fileStore + " 总空间：" + fileStore.getTotalSpace() / 1024 / 1024 / 1024 + " 可用空间：" + fileStore.getUsableSpace() / 1024 / 1024 / 1024);
        }


    }


    @Test
    public void testPath2() {
        //1、获取当前目录的绝对路径
        Path baseDir = Paths.get("/home/user");
        //2、从 baseDir 路径解析出文档目录的绝对路径
        Path docsDir = baseDir.resolve("documents"); // 解析为 /home/user/documents
        System.out.println(docsDir);


        // /home/user/documents/report.pdf
        Path fullPath = docsDir.resolve("report.pdf"); // /home/user/documents/report.pdf
        System.out.println(fullPath);


        Path otherPath = baseDir.resolve("/etc/config"); // 结果为 /etc/config
        System.out.println(otherPath);


        // 使用resolveSibling()替换最后一级路径
        Path p = Paths.get("/data/old.log");

        //  .resolveSibling("new.log"); // /data/new.log
        Path path = p.resolveSibling("new.log");// 结果为 /data/new.log
        System.out.println(path);

    }


    @Test
    public void testPath() throws URISyntaxException {
        // 创建路径对象; 文件是否存在和路径没有关系
        Path path = Paths.get("E:\\dev\\tools\\FSCapture_v9.6.exe");
        System.out.println(path);

        Path path2 = Paths.get("E:", "dev", "tools", "FSCapture_v9.6.exe");
        System.out.println(path2);

        Path path1 = Path.of("E:\\dev\\tools\\FSCapture_v9.6.exe");
        System.out.println(path1);


        /**
         * 1、http://example.com/languages/java/
         * 2、sample/a/index.html#28
         * 3、../../demo/b/index.html
         * 4、file:///~/calendar
         */
        Path path3 = Paths.get(new URI("file:///demo/b/index.html"));
        System.out.println(path3);
    }
}
