package com.lfy.cha04;

public class BedAndBreakfast {


    //类变量，静态变量
    public static int capacity = 0;

    //实例变量，非静态变量
    private  boolean full = false;

    // 成员变量初始化（为他们指定初始值）

    {
        System.out.println("动态代码块执2 行了...");
    }
    //动态代码块; 成员变量初始化
    {
        System.out.println("动态代码块执1 行了...");
        //对象级别的； 实例变量、类变量
        capacity = 200;
        full = true;

        // i=0; capacity = capacity + i; capacity = 0;
        // i=1; capacity = 1;
        // i=2; capacity += 2; capacity = 1 + 2;
        // i=3; capacity += 3; capacity = 1 + 2 + 3;
        // ...
        for (int i = 0; i < 100; i++) {
            capacity += i;
        }
    }


    static {
        //类级别的
        capacity = 100;
//        full = false; //错误的
        System.out.println("静态代码块2 执行了...");
    }
    //静态代码块
    static {
        //类级别的
        capacity = 100;
//        full = false; //错误的
        System.out.println("静态代码块1 执行了...");
    }




    public BedAndBreakfast(){
        System.out.println("构造器执行了...");
    }


    // 初始化代码块 优先 与 构造器

    public static void main(String[] args) {
        //Java程序要准备执行。
        //JVM把所有的类都先加载进来。静态代码块执行。


        BedAndBreakfast bedAndBreakfast = new BedAndBreakfast();
    }


    public void haha(){
        //final: 最终的；声明常量（不可变量）
        final int a = 10;

    }


}
