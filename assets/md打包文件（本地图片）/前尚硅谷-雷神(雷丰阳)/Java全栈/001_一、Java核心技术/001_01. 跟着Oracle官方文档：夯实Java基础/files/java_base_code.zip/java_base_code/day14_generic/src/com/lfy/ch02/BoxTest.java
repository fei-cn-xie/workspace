package com.lfy.ch02;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class BoxTest {


    // 下界通配；可以写
    @Test
    public void testPrint2(){
        List<Number> integers = new ArrayList<>();
        Utils.print(integers);
        System.out.println(integers);
    }


    // 上界通配；可以读，不可以写
    @Test
    public void testPrint(){


        List<Long> integers = new ArrayList<>();
        integers.add(1L);
        integers.add(2L);
        Utils.printNumber(integers);
    }

    // T泛型：可以写，可以读
    @Test
    public void testUtils(){
        ArrayList<String> strings = new ArrayList<>();
        ArrayList<Integer> integers = new ArrayList<>();
        integers.add(1);
        integers.add(2);

        Utils.printList(integers);
    }


    @Test
    public void testUtils2(){
        String[] a = new String[]{"1","2"};
        Utils.swap(a, 0, 1);

        System.out.println(Arrays.toString(a));
    }


    @Test
    public void testUtil(){
        String compute = Utils.compute("123");

        Integer compute1 = Utils.compute(123);

        Box<String> compute2 = Utils.compute(new Box<String>());
    }


    @Test
    public void boxTest2(){
        //1、创建box的时候，指定了泛型类型，所以，在编译时期，就知道里面装的是String类型的对象
        Box<String> box = new Box<String>();

        //类型精确限定。
        box.setData("1111");


        String data = box.getData();
        System.out.println(data.length());


    }

    @Test
    public void boxTest(){
        Box box = new Box();
        box.setData("hello");


        Object data = box.getData();
        // Object 装东西，将来用的时候，需要强制类型转换
        String str = (String) data;
        System.out.println(str);

        box.setData(10);
        data = box.getData();
        Integer num = (Integer) data;
        System.out.println(num);
    }
}
