package com.lfy.ch05;


/**
 * 可以被画出来的图形
 */
public interface Drawable {


    // 常量，常量名全大写  public static final String COMPANY = "雷丰阳";
    String COMPANY = "雷丰阳";

    // 画图的方法
    void draw();

    default void haha(){

    };

    // 以上是接口最常用的东西....

}
