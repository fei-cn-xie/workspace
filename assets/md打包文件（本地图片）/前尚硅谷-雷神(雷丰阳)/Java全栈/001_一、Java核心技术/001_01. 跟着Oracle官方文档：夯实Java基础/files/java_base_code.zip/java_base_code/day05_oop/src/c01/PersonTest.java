package c01;

public class PersonTest {

    public static void main(String[] args) {
        //1、创建某个类的对象
        Person person = new Person();

        //2、Person类定义的功能、方法、属性
        person.name = "张三";
        person.eat();
        person.walk();

        //对象之间 是独立运行自己的功能...
        System.out.println("===================");

        Person p1 = new Person();
        p1.name = "李四";
        p1.walk();
        p1.eat();
    }
}
