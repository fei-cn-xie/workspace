package com.lfy.ch05;

public class ThreadSaleTest {

    public static void main(String[] args) {
        SaleTicketSafe safe = new SaleTicketSafe();


        // 超卖存在
        new Thread(safe::saleTicket,"窗口1").start();
        new Thread(safe::saleTicket,"窗口2").start();
        new Thread(safe::saleTicket,"窗口3").start();
        new Thread(safe::saleTicket,"窗口4").start();
    }
}
