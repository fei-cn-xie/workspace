package c01;

public class F18Test01 {


    /**
     * 自注释
     * @param args
     */
    public static void main(String[] args) {
            //1、没有赋值，属性都是默认0值或null值。
            //2、如果要赋值，挨个赋值又很麻烦。

        //1）、我们希望创建对象的时候就有值？
        //   1.1）、直接在定义的时候给定属性的默认值；问题; 以后造的所有对象都是这个值。
        F18Hornet f18a = new F18Hornet();  //无参构造器制造飞机
        f18a.showStatus();


        F18Hornet f18b = new F18Hornet();
        f18b.showStatus();


        //   1.2）、利用构造器，在创建对象的时候，把不一样的东西传入进来
        F18Hornet f18c = new F18Hornet("F0001"); // "F0001" 实参  // 1个参数的构造器制造飞机
        F18Hornet f18d = new F18Hornet("F0002"); // "F0002" 实参
        F18Hornet f18e = new F18Hornet("F0003"); // "F0003" 实参


        f18c.showStatus();
        f18d.showStatus();
        f18e.showStatus();


        //    1.3）、利用构造器（构造函数[没有返回值的特殊函数]），在创建对象的时候，把不一样的东西传入进来
        F18Hornet x18a = new F18Hornet("X01",4);
        F18Hornet x18b = new F18Hornet("X02",6);
        F18Hornet x18c = new F18Hornet("X03",12);

        x18a.showStatus();
        x18b.showStatus();
        x18c.showStatus();

        //赋值运算，
        x18a.missiles = x18a.missiles -  1;



    }
}
