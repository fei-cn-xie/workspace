package com.lfy.ch0;

public class PointTest {

    public static void main(String[] args) {
        Point point = new Point();  //alt + enter

        point.printPoint();

        System.out.println("==============");
        Point point1 = new Point(10, 15);
        Point point2 = new Point(12, 15);
        Point point3 = new Point(15, 25);

        point1.printPoint();
        point2.printPoint();
        point3.printPoint();

    }
}
