package com.lfy.ch02;


/**
 * 泛型的几种写法：
 * 1、泛型类：Box<T>
 * 2、静态方法： public static <T> T compute(T obj)
 * 3、通配符写法;
 *    <?>：无界：未知类型； 可读不可写
 *    <? extends T>：上界：T的子类；  可读不可写
 *    <? super T>：下界：T的父类； 可写可读
 *
 *
 * Box类：装数据
 *  什么类型的数据都可以装，但是希望获取到的数据的类型是固定的，精确的，不需要强制类型转换
 *  T: Type 泛型，代表类型
 *  <T>：泛型声明
 */
public class Box<T> {



    private T data;

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
