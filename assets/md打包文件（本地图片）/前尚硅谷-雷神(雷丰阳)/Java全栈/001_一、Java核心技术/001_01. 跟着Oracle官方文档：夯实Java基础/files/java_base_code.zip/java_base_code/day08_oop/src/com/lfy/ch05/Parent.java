package com.lfy.ch05;


// final：最终版本。不能改；
// 类上加了final 修饰符，表示该类不能被继承
public  class Parent {

    //final 修饰的方法不能被重写
    public final void testParent() {
        System.out.println("父类方法");
    }
}
