package com.lfy.ch01;

/**
 * 锁原理：
 * 1、ShareDataOne 创建了一个对象，这个对象保存到堆内存中
 * 2、ShareDataOne 对象的方法说要加锁。 锁就是当前这个对象
 * 3、多个线程调用对象的方法时候，要看锁标志；
 *      （锁标志代表有人在用，JVM把线程wait掉。）
 *      （锁标志没有人占用，JVM就执行这个线程）
 * 4、每个对象在堆内存中保存有一个固定格式
 */
public class ShareDataOne {

    //  count = 0;
    private int count = 0; //资源  1 0 1 0




    // 锁是谁？ 谁调用方法就把谁当成锁。 目前this对象
    // 锁：怎么就锁住了。（多个线程都公用一把锁，就锁住了）
    public synchronized  void increment() throws InterruptedException {
        //        int a = 1;
        //        a++;
        count++; //不具有原子
        // 读取count的值
        // 计算+1结果
        // 写入结果
    }

}