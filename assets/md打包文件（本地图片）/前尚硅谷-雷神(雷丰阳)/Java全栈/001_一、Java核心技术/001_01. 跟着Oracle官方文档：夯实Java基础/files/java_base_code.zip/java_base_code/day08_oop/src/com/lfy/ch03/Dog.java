package com.lfy.ch03;

public class Dog extends Animal{



    // super() 关键字调用父类构造方法
    public Dog(){
//        this(); //调用自己的
//        this.name = "旺财"; // 给父类属性赋值
//        this.eat();
//
//        System.out.println("=========");
        //调用父类构造方法； 创建子类对象之前，必须先创建父类对象，否则编译不通过。
//        super(); //默认存在的，可以不写。
//        super.name = "旺财"; // 给父类属性赋值
//        super.eat();
        System.out.println("Dog 构造方法执行...");
    }

    @Override //重写父类方法
    public void eat() {
//        super.eat();
        System.out.println("Dog eat 哈哈哈");
    }
    public static void sayHello(){
        System.out.println("Dog .... Hello");
    }

}
