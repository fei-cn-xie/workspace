package com.lfy.other;

import org.junit.Test;

import java.io.Reader;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;


public class FeatureTest {

    @Test
    public void test4(){

        String _hahah = "hahaha";
        System.out.println(_hahah.substring(1));




        String name = "Alice";
        String str = "Hello "+ name +", today is: "+ LocalDate.now() +" 哈哈";
        System.out.println(str);


        // \{具名参数}；  需要IDEA 新版本
//        String info = STR."Hello \{name}, today is \{LocalDate.now()}";



        // _：丢弃
        List<Integer> list = List.of(1, 2, 3,3,3,2,1);
//        for (Integer _: list){
//            System.out.println("哈哈: " );
//        }


        // Function
        // 鼠标放到 灰色的，黄色波浪线的有提示
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                System.out.println("hahaha");
            }
        };

        new Thread(runnable).start();


        List.of(1, 2, 3)
            .forEach(System.out::println);



    }


    @Test
    public void test3() {

        // 重写 toString 方法，才能打印好看
        Person person = new Person("张三", 20);
        System.out.println(person);

        person.getAge();
        person.getName();
        person.setName("李四");


        var data = new PersonData("张三2", 22);
        System.out.println(data);
        System.out.println(data.age());
        System.out.println(data.name());


        Object obj = "abc";
        // 传统方式: obj 是 String 的 实例吗
        if (obj instanceof String) {
            String str = (String) obj;
            System.out.println(str.length());
        }

        // Pattern Matching方式
        if (obj instanceof String abc){
            System.out.println(abc.length());
        }


        Object xxx = 123;


        // 判断类型 + 变量赋值 + 强制类型转换
        String formatter = switch (xxx) {
            case Integer i -> String.format("int %d", i); // int 123
            case String s  -> String.format("string %s", s); //string 123
            default        -> "unknown";
        };
        System.out.println(formatter);
    }

    @Test
    public void test1() {
        int a = 1;

        // 以前的switch-case如果要写返回值？
//        switch (a) {
//            case 1:
//                System.out.println("a = 1");
//                return;
//            case 2:
//                System.out.println("a = 2");
//                break;
//            default:
//                System.out.println("a = other");
//        }

        String str = "b";

        int x;

        switch (str) {
            case "a":
                x = 1;
                break;
            case "b":
                x = 2;
                break;
            default:
                x = 3;
                break;
        }

        System.out.println(x);
        System.out.println("===============");


        int day = 7;

        String dayType = switch (day) {
            case 6, 7 -> "周末";
            case 1, 2, 3, 4, 5 -> "工作日";
            default -> "非法值";
        };

        System.out.println(dayType);


        String text = "Hello\nJava";
        System.out.println(text.indent(4));


        String text2 = "String text = \"Hello\\nJava\"; \n" +
                "System.out.println(text.indent(4));";


        System.out.println(text2);

        //大文本块
        String text3 = """
                String text = "Hello\\nJava";
                System.out.println(text.indent(4));     aaaaa
                            aaaa
                """;
        System.out.println(text3);
    }

//    private int a = 1;

    //局部变量：方法里面
    //Java基础变量：
    // 4种位置的变量：
    // 1.实例变量：非static修饰的成员变量
    // 2.局部变量：方法里面
    // 3.形式参数：方法定义的时候
    // 4.类变量： static修饰的成员变量


    @Test
    public void test() {
        List<String> list = new ArrayList<>();

        // var 关键字：类型推断
        var a = new HashMap<>();
        System.out.println(a.getClass());

        var b = 1;
        System.out.println(b);


        var c = "abc";
        System.out.println(c.getClass());

    }
}
