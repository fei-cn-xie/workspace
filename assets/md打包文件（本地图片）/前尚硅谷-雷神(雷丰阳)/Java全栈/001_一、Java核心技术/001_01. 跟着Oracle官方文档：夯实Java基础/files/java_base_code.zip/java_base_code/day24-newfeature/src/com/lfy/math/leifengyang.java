package com.lfy.math;

/**
 * @author leifengyang
 */
public class leifengyang {

    public static void main(String[] args) {

        //git
        String abcD = "ABCD";
        System.out.println(abcD.substring(1, 3));

    }
}
