package com.lfy.ch03;

public class Mimi {

    private String miName; //实例属性
    private Mimi(){}

    private void dance(){
        System.out.println(miName+"： 跳舞");
    }

}
