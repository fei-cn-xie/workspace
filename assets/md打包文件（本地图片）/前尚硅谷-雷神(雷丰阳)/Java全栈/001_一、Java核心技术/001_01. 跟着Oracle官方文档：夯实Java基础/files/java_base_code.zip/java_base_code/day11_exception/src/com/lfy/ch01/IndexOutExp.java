package com.lfy.ch01;

/**
 * 1、异常多匹配的时候。
 *   写法：由小到大 == 由子到父
 */
public class IndexOutExp {
    public static void main(String[] args) {
        String[] friends = { "lisa", "bily", "kessy" };
        // 写法1： 异常代码用try-catch包起来
//        for (int i = 0; i < 5; i++) {
//
//            // 正常运行了 5 次
//            try{
//                System.out.println("第"+i+"次"+friends[i]);
//            }catch (ArrayIndexOutOfBoundsException e){
//                System.out.println("第"+i+"次没有了；"+e);
//            }finally {
//                System.out.println("第"+i+"次；执行完毕");
//            }
//        }

        // 写法2： try-catch 包整个循环
//        try {
//
//            for (int i = 0; i < 5; i++) { // i=3
//                System.out.println("第"+i+"次"+friends[i]);
//            }
//
//        }catch (ArrayIndexOutOfBoundsException e){
//            System.out.println("数组越界了；"+e);
//        }finally {
//            System.out.println("执行完毕");
//        }



        //写法3：catch 单独捕获异常

        try {
            int a = 10;
            int i = 10/a; // 程序可能炸的地方
            int[] arr = new int[3];
            System.out.println(arr[2]); // 程序可能炸的地方
            // 100 行
            String s = null;
            s.length(); // 程序可能炸的地方
        } catch (ArithmeticException e) {
            System.out.println("算术异常"+e);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("数组越界异常"+e);
        } catch (RuntimeException e){ // 异常的父类； 能匹配所有更详细的异常
            System.out.println("运行时异常"+e);
        }

        System.out.println("执行完毕");



        // 写法4：捕获所有异常
        try {
            int a = 10;
        }catch (Exception e){
            //拿到所有异常，
            System.out.println("捕获了所有异常"+e);
        }

    }
}
