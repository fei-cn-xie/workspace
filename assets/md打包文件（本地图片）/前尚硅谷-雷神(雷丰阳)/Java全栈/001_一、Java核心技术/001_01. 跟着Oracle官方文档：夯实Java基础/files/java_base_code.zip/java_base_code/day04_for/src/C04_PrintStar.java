public class C04_PrintStar {

    public static void main(String[] args) {
        /**
         *   第i行，打印i个   *
         *   第i行，打印i个   **
         *   第i行，打印i个   ***
         *   第i行，打印i个   ****
         *   第i行，打印i个   *****
         */

        for (int i = 1; i < 6; i++) { //外层控制行 i < 6（就是行数）
            for (int j = 0; j < i; j++) { //内层控制列 j < i（就是列数）
                //i=1；j=0
                //i=2；j=0，j=1
                //i=3；j=0，j=1, j=2
                //i=4; j=0，j=1, j=2, j=3
                //i=5; j=0，j=1, j=2, j=3, j =4
                System.out.print("*"); //没有换行
            }
            //换行
            System.out.println();
        }

        System.out.println("==================");

        // 9*9 乘法表
        for (int i = 1; i < 10; i++) {
            for (int j = 1; j <= i; j++) {
                // 	"\t" 是 tab 符  1x1=1
                //拼串！ j + "x1"  2x1
                System.out.print(j + "x1"+ i +"=" + (i*j) + "\t");
            }
            //换行
            System.out.println();
        }

    }
}
