package com.lfy.ch01;


import org.junit.Test;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * 读取文本文件：
 *   1、.txt .java .c 文件： 纯文本
 *   2、.doc .xls .ppt 文件； 不属于文本文件
 */
public class FileReaderTest {


    @Test
    public void tryCatchTest() throws IOException {
        FileReader fr = null;
        FileWriter fw = null;
        try {
            //1、尝试执行可能出现异常的代码块
            fr = new FileReader("kubla222.txt");
            fw = new FileWriter("outtest.txt");

            char[] cbuf = new char[1024];
            int size = 0;
            while((size = fr.read(cbuf)) != -1){
                fw.write(cbuf, 0, size);
            }
        } catch (FileNotFoundException e) {
//            throw new RuntimeException(e);
            System.out.println("文件不存在");
        } catch (IOException e) {
//            throw new RuntimeException(e);
            System.out.println("文件读写异常");
        } finally {
            // 一定会走； 关流； 底层出问题，建议把异常直接抛出。
            // 小心空指针异常； 使用防空判断
            if(fw != null){
                fw.close();
            }

//            System.out.println("准备关闭fr："+fr);
            if(fr != null){
                fr.close();
            }

        }



    }

    /**
     * 流的关闭方法，是先把数据flush，再close
     * @throws IOException
     */
    @Test
    public void flushTest() throws IOException {
        FileWriter fw = new FileWriter("hellox.txt");

        // 字符流，写的数据，默认在内存缓冲区，不会写入到文件中。
        //
        fw.write("h");
        fw.write("e");

        fw.flush(); // 把缓冲区的数据，写入到文件中。

        fw.write("l");
        fw.write("l");

        fw.flush();
        fw.write("o"); // 断电； 丢失o。
        // 刷新缓冲区，但不关闭流。
//        fw.flush();
        System.out.println("flush");

        fw.close();
    }


    @Test
    public void copyText() throws IOException {
        FileReader fr = new FileReader("kubla.txt");

        FileWriter fw = new FileWriter("outtest.txt");


        char[] cbuf = new char[1024];
        int size = 0;
        while((size = fr.read(cbuf)) != -1){
            fw.write(cbuf, 0, size);
        }


        fw.close();
        fr.close();

    }




    @Test
    public void writerFileTest() throws IOException {
        FileWriter writer = new FileWriter("hello.txt");

        // write 每次会把文件内容覆盖；  ctrl /
        writer.write("hello world 2222");
        writer.write("\n");
        writer.write("雷丰阳....");
        writer.write("\n");
        writer.write("雷丰阳222....");


        // append 每次会在文件末尾追加内容； 仅对当次有效。如果文件关了，下次打开文件，还是从头开始写。
        writer.append("你好666");
        writer.append("你好666");
        writer.append("你好666");

        writer.close();
    }


    @Test
    public void readerTest1() throws IOException {

        FileReader fr = new FileReader("kubla.txt");


        // 返回读取到的字符数，直到文件末尾返回-1
        char[] cbuf = new char[10];
        int size = 0;

        while ((size = fr.read(cbuf)) != -1){
            // 最后一桶
            String words = new String(cbuf, 0, size);
            System.out.print(words);
        }



        fr.close();

    }


    @Test
    public void readerTest() throws IOException {
        FileReader fr = new FileReader("kubla.txt");


        char c = '中'; // 2字节

        // 读取单个字符（1字节、2字节、3字节、4字节）
//        int read = fr.read();
//        System.out.println((char)read);
//        read = fr.read();
//        System.out.println((char)read);
//        read = fr.read();
//        System.out.println((char)read);


        // 返回读取到的字符，直到文件末尾返回-1
        int data;
        while ((data = fr.read()) != -1){
            System.out.print((char)data);
        }

        fr.close();

    }
}
