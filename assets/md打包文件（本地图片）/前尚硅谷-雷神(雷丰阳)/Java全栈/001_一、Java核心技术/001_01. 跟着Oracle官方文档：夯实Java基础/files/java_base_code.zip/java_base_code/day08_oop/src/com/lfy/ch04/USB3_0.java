package com.lfy.ch04;


/**
 * 接口可以继承
 * 如果 A 实现了 USB3_0 接口，那么 A 就实现了 USB2_0 接口
 */
public interface USB3_0 extends USB2_0 {
    default void fastTransfer(){
        System.out.println("USB3_0 接口默认 快速传输");
    }
}
