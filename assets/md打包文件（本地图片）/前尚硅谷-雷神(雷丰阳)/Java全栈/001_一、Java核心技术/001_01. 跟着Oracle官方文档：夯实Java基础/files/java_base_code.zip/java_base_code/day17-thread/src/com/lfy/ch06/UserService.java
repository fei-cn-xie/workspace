package com.lfy.ch06;


/**
 * 用户服务（功能）
 *
 * 调用者想要后台运行目标方法，调用者自己去new Thread，而不是让 目标类 自己去 new Thread，
 * 设计规则：
 * 1、
 */
public class UserService {

    public static void main(String[] args) {
        System.out.println("用户执行功能1...");

        OrderService orderService = new OrderService();

        new Thread(()->{
            //目标方法
            orderService.createOrder();
        }).start();


        System.out.println("用户执行功能2...");
        System.out.println("用户执行功能3...");
    }
}
