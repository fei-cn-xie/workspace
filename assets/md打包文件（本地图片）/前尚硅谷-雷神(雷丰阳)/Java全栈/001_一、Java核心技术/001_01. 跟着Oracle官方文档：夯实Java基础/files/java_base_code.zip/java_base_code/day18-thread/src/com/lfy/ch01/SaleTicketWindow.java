package com.lfy.ch01;


/**
 * 模拟这个窗口卖100张票，模拟多个窗口同时卖票
 */
public class SaleTicketWindow extends Thread {


    // 类变量/方法，直接通过类可以调用。不用通过对象
    static int ticketNum = 100; // 静态变量； 这个变量是跟着类走的， 所有对象共享的
    //int ticketNum = 100; //实例变量； 这个变量是创建对象以后，跟着对象实例的

    @Override
    public void run() {
        //实现卖票
//        int ticketNum = 100;  // 只是当前方法用的。其他人不能共享
        while (ticketNum > 0){
            System.out.println(Thread.currentThread().getName() + "卖出了一张；剩余：" + --ticketNum);
        }
    }
}
