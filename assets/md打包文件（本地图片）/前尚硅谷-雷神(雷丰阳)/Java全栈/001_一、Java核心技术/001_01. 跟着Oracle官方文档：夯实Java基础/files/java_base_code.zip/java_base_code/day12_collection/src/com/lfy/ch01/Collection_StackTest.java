package com.lfy.ch01;

import org.junit.Test;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.Stack;

/**
 * Stack： 栈； 子弹夹。 先进后出（First In Last Out） FILO
 *
 *
 */
public class Collection_StackTest {


    @Test
    public void testStack() {
        Stack stack = new Stack();


        //1、给栈添加元素
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        stack.push(5); //最后的是栈顶元素

        //2、查看栈顶元素
        Object peek = stack.peek();
        System.out.println(peek);

        peek = stack.peek();
        System.out.println(peek);

        peek = stack.peek();
        System.out.println(peek);

        //3、弹出栈顶元素（从栈顶移除一个元素）
//        Object pop = stack.pop();
//        System.out.println(pop);
//
//        pop = stack.pop();
//        System.out.println(pop);
//
//        pop = stack.pop();
//        System.out.println(pop);
//
//        Object peek1 = stack.peek();
//        System.out.println(peek1);

        //4、遍历栈
        Iterator iterator = stack.iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }





    }

}
