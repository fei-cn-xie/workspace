package com.lfy.ch0;


/**
 * 推荐：
 * 1、只要你写了有参构造器，就必须写无参构造器
 */
//矩形类
public class Rectangle  {
    int x,y; //坐标起点
    int width,height; //长宽


    //无参构造器
    public Rectangle(){
        //默认所有东西都为0值
//        Rectangle rectangle = new Rectangle(0, 0, 10, 20);
//        this();//本人无参构造器

        this(0,0,10,20); //本人对应的有参构造器

    }

    public Rectangle(int x, int y, int width, int height){
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void printRectangle(){
        System.out.println("矩形坐标点："+x+","+y+" 宽高："+width+","+height);
    }


}
