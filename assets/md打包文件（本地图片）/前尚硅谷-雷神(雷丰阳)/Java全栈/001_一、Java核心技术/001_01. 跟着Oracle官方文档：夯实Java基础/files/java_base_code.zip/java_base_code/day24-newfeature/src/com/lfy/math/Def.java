package com.lfy.math;


/**
 *  Abc、Def都属于 com.lfy.math 包（模块）
 */
public class Def {
}
