package com.lfy.other;


/**
 * 专门用来数据封装
 * @param name
 * @param age
 */
// 自动有构造器、getter、setter、toString、equals、hashCode方法
public record PersonData(String name, int age) {
}
