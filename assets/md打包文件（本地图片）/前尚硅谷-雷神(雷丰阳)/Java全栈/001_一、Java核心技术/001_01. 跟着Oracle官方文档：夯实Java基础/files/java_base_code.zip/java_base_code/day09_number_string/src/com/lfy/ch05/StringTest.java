package com.lfy.ch05;

/**
 * 换行和回车本质是一个东西（效果），但是底层存储不一样
 */
public class StringTest {

    public static void main(String[] args) {

        String s1 = new String("Hello");
        String s2 = new String("Hello");
        System.out.println(s1.intern() == s2.intern());



        String greeting = "Hello world!"; // 常量池，不可变的
        char c = greeting.charAt(0);
        System.out.println(c);


        // 字符数组，就是字符串； 但是可变
        char[] helloArray = { 'h', 'e', 'l', 'l', 'o', '.' };
        helloArray[2] = 'H';

        String helloString = new String(helloArray);



        // 回文串：反着写是一样的
        String palindrome = "Dot saw I was Tod";
        int length = palindrome.length();


        System.out.println(length);


        //1、反转字符串： hello world -> dlrow olleh
        String a = "leifengyang";
        String reverse = reverse(a);
        System.out.println(reverse);


        //拼接字符串
        String xx = "a" + "b";


        //原字符串和被链接的都不动，返回一个新的字符串对象
        String concat = palindrome.concat(xx);
        System.out.println(concat);


        //大文本
        String html = """
              <html>
                  <body>
                      <p>Hello, world</p>
                  </body>
              </html>
              """;
        System.out.println(html);

        System.out.println("=================");

        String anotherPalindrome = "Niagara. O roar again!";
        String roar = anotherPalindrome.substring(11, 15);
        System.out.println(roar);

        System.out.println("===================");
        String s = "zhangsan；lisi；wangwu";
        // zhangsan   lisi  wangwu
        String[] split = s.split("；");
        for (String name : split) {
            System.out.println(name);
        }

        String aaa = "abcaaa";
        int i = aaa.indexOf('a');
        int i1 = aaa.lastIndexOf('a');
        boolean b = aaa.contains("bc");
        System.out.println(i);
        System.out.println(i1);
        System.out.println(b);

        System.out.println("===========");

        String bbb = "abc ddef";
        String replace = bbb.replace(" ", "_");
        System.out.println(replace);


    }

    public static String reverse(String s) {

        //直接转为数组
        char[] charArray = s.toCharArray();

        //1、把字符串转换成字符数组
        char[] chars = new char[s.length()];
        for (int i = 0; i < chars.length; i++) {
            chars[i] = s.charAt(i);
        }

        // [h,e,l,l,o, ,w,o,r,l,d]
        char[] result = new char[s.length()];

        //反转逻辑
        int j = 0;
        for (int i = chars.length - 1; i >= 0; i--) {
            result[j++] = chars[i];
        }


        // 数据结构算法、设计模式
        return new String(result);


    }
}
