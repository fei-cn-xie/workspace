package com.lfy.ch01.tcp;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;


/**
 * 模拟一个服务器 接受数据
 */
public class TcpServer {

    public static void main(String[] args) throws IOException {
        //1、创建一个 ServerSocket（服务端）; 监听本机的 8080；
        // 127.0.0.1：就是本机地址;  localhost：就是本机地址;
        ServerSocket serverSocket = new ServerSocket(8080);
        System.out.println("服务器启动了...");


        //2、准备接受客户端的连接； 如果用完就要关闭； try-with-resources;
        try(Socket  socket = serverSocket.accept();
            InputStream is = socket.getInputStream(); //别人发给我的数据
            OutputStream os = socket.getOutputStream(); //我发给别人的数据
        ) { //阻塞方法: 方法停止到这里，就等数据
            System.out.println("接受到了客户端连接....");

            //3、读取客户端发送的数据
            byte[] bytes = new byte[1024];
            int len = 0;
            while ((len = is.read(bytes))!= -1){ // 由于网络流，无终止，所以可能一直卡到这里；
                // 要么对方明确说传输结束，要么对方直接关闭连接
                String str = new String(bytes, 0, len);
                System.out.println("服务器收到数据："+str);
            }

            System.out.println("哈哈啊哈.....");

        }catch (Exception e){
            System.out.println("服务器异常："+e);
        }


    }
}
