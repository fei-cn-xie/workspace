package com.lfy.ch03;

/**
 * 订单不存在异常
 */
public class OrderNotExistException extends RuntimeException{

    public OrderNotExistException(String message) {
        super(message);
    }
}
