package c01;

/**
 * 1、自定义一个类（现实生活中产品PPT、产品说明书、产品图纸）
 *   1）、属性  Flied
 *   2）、构造器 Constructor
 *   3）、方法 Method
 */
public class F18Hornet {

    //基本类型() 、 引用类型（String,F18Hornet ）

    //1）、属性：也叫 成员变量；
    //    1. 每个没有赋值的变量都会有一个初始默认值; 数字: 0/0.0；  布尔(boolean): false  String/引用类型： null
    public String callSign; //呼号； 四川8633;
    int speed;// 速度  km/h
    int missiles = 4;// 剩余导弹数量； 出厂默认值就是4个
    boolean isAirborne; //是否在空中


    //以下定义了三种不同制造对象的办法
    //2）、构造器(特殊方法)： 按照类的图纸制造对象的方法； 每种构造器就是一种制造飞机的办法
    public F18Hornet(){ //无参构造器
        //啥也不写...
        // Tab 工程师
    }


    public F18Hornet(String a){ //制造飞机的时候传入飞机的呼号； a形参
        callSign = a;  //制造飞机的时候直接把呼号，赋值给正确的变量名
    }

    public F18Hornet(String sign,int num){
        callSign = sign;
        missiles = num;
    }


    //3）、定义方法： 将来有哪些可以使用的功能
    //3.1）、起飞方法
    public void takeOff() {
        if (isAirborne){ //在空中
            System.out.println(callSign + "；已在空中...");
        }else {
            System.out.println(callSign + "；正在起飞...");
            speed = 300;
            isAirborne = true; //起飞后就是在空中了
            System.out.println(callSign + "：当前时速："+ speed +" km/h");
        }
    }

    //3.2）、着陆
    public void land(){
        if (isAirborne){ //在空中...需要进行着陆
            isAirborne = false;
            System.out.println(callSign + "；正在着陆...");
            speed = 0;
            System.out.println(callSign + "：着陆完成：确认下时速："+ speed +" km/h");
            missiles = 4;
            System.out.println(callSign + "：着陆完成：导弹补充完毕：剩余"+ missiles);
        }
    }

    //3.3）、加速
    public void accelerate(int x){
//        speed = speed + x;
        speed += x;
        System.out.println(callSign +"；已加速至： "+speed+" km/h");
    }

    //3.4）、发射导弹；有多种功能
    //   0：默认发射一颗
    //   1：发射指定型号导弹
    //   2：发射指定数量导弹
    //   3：发射指定型号，指定数量导弹
    public void fireMissile(){
        if (isAirborne){
            if (missiles > 0){
                missiles--;
                System.out.println(callSign +"；发射一枚【默认：响尾蛇】导弹；还剩："+ missiles);
            }else {
                System.out.println(callSign +"；导弹已全部用完，请补充弹药");
            }
        }else {
            System.out.println(callSign +"；请先起飞才能发射导弹");
        }
    }

    // 同一个方法的多种实现方式；重载(Overload)； 方法名一样，参数的个数和类型不一样就行
    // 1：发射指定型号导弹
    public void fireMissile(String type){
        if (isAirborne){
            if (missiles > 0){
                missiles--;
                System.out.println(callSign +"；发射一枚【"+type+"】导弹；还剩："+ missiles);
            }else {
                System.out.println(callSign +"；导弹已全部用完，请补充弹药");
            }
        }else {
            System.out.println(callSign +"；请先起飞才能发射导弹");
        }
    }
    public void fireMissile(int num){
        if (isAirborne){
            if (missiles > 0 && num < missiles){
                missiles -= num;
                System.out.println(callSign +"；发射"+ num +"枚【默认：响尾蛇】导弹；还剩："+ missiles);
            }else {
                System.out.println(callSign +"；导弹已全部用完, 或不足，请补充弹药");
            }
        }else {
            System.out.println(callSign +"；请先起飞才能发射导弹");
        }
    }

    public void fireMissile(String type,int num){
        if (isAirborne){
            if (missiles > 0){
                missiles -= num;
                System.out.println(callSign +"；发射"+num+"枚【默认："+ type +"】导弹；还剩："+ missiles);
            }else {
                System.out.println(callSign +"；导弹已全部用完，请补充弹药");
            }
        }else {
            System.out.println(callSign +"；请先起飞才能发射导弹");
        }
    }




//    public void fireMissileByType(String type){
//    }
//    public void fireMissileByNum(int num){
//    }
//    public void fireMissileByTypeAndNum(String type,int num){
//    }


    //3.5）、飞机仪表盘上面显示状态
    public void showStatus(){
        System.out.println("=== " + callSign + "状态 ===");
        System.out.println("当前速度: " + speed + "km/h");
        System.out.println("剩余导弹: " + missiles);
        System.out.println("飞行状态: " + (isAirborne ? "空中" : "地面"));
//        System.out.println("F18：呼号："+callSign+
//                "； 当前速度：" +speed + "km/h" + "； 剩余导弹："+missiles+"； 飞行中状态："+isAirborne);
    }


}
