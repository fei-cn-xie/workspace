package com.lfy.ch04;




public class LfyUSB implements USB3_0{




    @Deprecated
    @Override //重写父类的方法
    public void transfer() {

    }

    @Override
    public void fastTransfer() {
        System.out.println("USB3_0 子类 闪电传输");
    }


    // Douyin
    public static void main(String[] args) {
        LfyUSB lfyUSB = new LfyUSB();

//        lfyUSB.transfer();

        lfyUSB.fastTransfer();
    }
}
