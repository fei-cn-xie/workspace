package com.lfy.ch03;

import org.junit.Test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

/**
 * Properties（Property 属性）： 很多的属性的集合； 每个属性都有对应的值。
 * 【外部的配置文件】，作为配置文件，来保存一些固定的数据。方便修改（代码不用改）。
 */
public class PropertiesTest {


    @Test
    public void test01(){
        //1、写一个斗地主的游戏 的发牌程序；
        // 模拟【三个人】斗地主洗牌和发牌，要留【三张底牌】，发牌结束，打印三个人的手牌以及【底牌】（要整好序）。
        // 打印每个人的手牌 以及底牌

        String[] num = {"A","2","3","4","5","6","7","8","9","10","J","Q","K"}; //牌号
        String[] color = {"方片","梅花","红桃","黑桃"}; //花色

//        for (String c : color)

        // 所有牌的集合
        List list = new ArrayList();
        // 遍历所有牌组合
        for (String c : color) {
            for (String n : num) {
                String poke =  c + n;
                list.add(poke);
            }
        }
        list.add("大王");
        list.add("小王");


        //2、洗牌
        Collections.shuffle(list);
        System.out.println(list);

        //3、发牌
        List zhangsan = new ArrayList();
        List lisi = new ArrayList();
        List wangba = new ArrayList();
        List diPai = new ArrayList();

        // 52-3 = 49
        // size：52 张牌， 0，1，2，3，4，5，......，49,50, 51
        for (int i = 0; i < list.size(); i++) {
            Object currentPoke = list.get(i);
            if(i>= list.size()-3){ //最后三次的遍历 放到底牌中
                diPai.add(list.get(i));
                continue; //继续下一次循环，不执行下面的代码了。
            }

            // Java Swing + 网络编程
            if(i%3 == 0){
                zhangsan.add(currentPoke);
            }
            if(i%3 == 1){
                lisi.add(currentPoke);
            }
            if (i%3 == 2){
                wangba.add(currentPoke);
            }
        }

        //请编写自定义的 Comparator 实现类，对牌按照排面数字进行排序
//        Comparator comparator = new Comparator() {
//            @Override
//            public int compare(Object o1, Object o2) {
//                String string = o1.toString();
//                char c = string.charAt(2);
//                String string1 = o2.toString();
//                return 0;
//            }
//        };
//        Collections.sort(zhangsan,comparator);
        Collections.sort(zhangsan);
        Collections.sort(lisi);
        Collections.sort(wangba);
        Collections.sort(diPai);
        System.out.println("张三的手牌：" + zhangsan);
        System.out.println("李四的手牌：" + lisi);
        System.out.println("王八的手牌：" + wangba);
        System.out.println("底牌：" + diPai);






    }


    @Test
    public void testCollections(){
        // 设计规范： Xxxs 是 Xxx 的工具类；(第三方框架) (XxxUtil是Xxx的工具类)

        // Collection： 接口
        // Collections： 工具类

        // 不能进行CRUD
        List<Object> objects = Collections.emptyList();


        List list = new ArrayList();
        list.addAll(List.of(1,2,3,9,6,8,5,4));

        Collections.sort(list);
        System.out.println(list);


        //洗牌：打乱
        Collections.shuffle(list);
        System.out.println(list);

        Collections.shuffle(list);
        System.out.println(list);

        Collections.shuffle(list);
        System.out.println(list);

        Collections.sort(list);
        System.out.println(list);
        Collections.reverse(list);
        System.out.println(list);

//        Collections.sort(list,new Comparator<Object>() {
//
//            @Override
//            public int compare(Object o1, Object o2) {
//                // o1 - o2;
//                return 0;
//            }
//        });

        //
        List.of(1,2,3,9,6,8,5,4);//不可变集合
        List list1 = Arrays.asList(1, 2, 3, 4,9,5,4); //可变
//        Arrays.sort(list1);
    }

    /**
     * 把外部文件的属性内容，加载到 Properties
     * 规定：
     * key=value
     * key1=value1
     * key2=value2
     *
     * @throws IOException
     */
    @Test
    public void loadProperties() throws IOException {
        Properties properties = new Properties();

        FileInputStream stream = new FileInputStream("ai.properties");
        properties.load(stream);

        System.out.println(properties);


        Object o = properties.get("ai.model");
        System.out.println(o);
    }


    @Test
    public void testProperties() throws IOException {
        //1、获取系统属性集合 Properties还是Map结构
        Properties properties = System.getProperties();
        System.out.println(properties);

        Object os = properties.get("os.name");
        System.out.println(os);
        Object java = properties.get("java.version");
        System.out.println(java);

        //2、Properties 唯一一个 可以和 IO流 结合使用的Map； 不写路径，默认在当前项目下创建文件。
        FileOutputStream outputStream = new FileOutputStream("system.properties");
        //3、把 properties 存到文件中。
        properties.store(outputStream, "System Properties");
        System.out.println("保存成功！");

    }
}
