package com.lfy.ch05;


import java.io.FileOutputStream;
import java.io.PrintStream;

/**
 * 日志：
 *  程序员以后把一些程序运行的信息（记录下来【记录日志】）输出到一个日志文件中（方便后来排查），
 */
public class LogUtils {


    // 日志框架的基本做法
    public static void logError(String msg,Exception ex){
        try {
            System.setOut(new PrintStream(new FileOutputStream("error.log.txt", true)));
            System.out.println("时间：" + System.currentTimeMillis() + "  内容：" + msg +"  异常信息：" + ex.getMessage() + "  堆栈信息：" + ex);
        }catch (Exception e) {
            e.printStackTrace(); //打印异常信息到控制台
        }
    }

    public static void log(String msg) {
        try {
            System.setOut(new PrintStream(new FileOutputStream("log.txt", true)));
            System.out.println("时间：" + System.currentTimeMillis() + "  内容：" + msg);
        }catch (Exception e) {
            e.printStackTrace(); //打印异常信息到控制台
        }

    }
}
