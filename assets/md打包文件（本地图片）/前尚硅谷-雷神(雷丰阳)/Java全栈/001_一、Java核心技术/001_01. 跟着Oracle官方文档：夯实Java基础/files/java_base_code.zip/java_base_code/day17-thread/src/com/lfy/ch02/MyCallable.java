package com.lfy.ch02;

import java.util.concurrent.Callable;


// 以后使用实现 Runnable 接口的方式去来定义任务比较好。
// 因为类没有多继承，接口有，所有用接口更灵活。
public class MyCallable implements Callable<String> {
    @Override
    public String call() throws Exception {
        String a = ""; //0123456789
        for (int i = 0; i < 10; i++) {
            //模拟比较慢
            Thread.sleep(500);
            a += i;
        }

        // 有返回值
        return a;
    }
}
