package com.lfy.ch02;

public interface Operation {
    int compute(int a, int b);
}
