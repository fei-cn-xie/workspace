package com.lfy.ch03;

public class F18 {


    // 成员：(实例变量【不加static的属性】)
    //  1）、属性
    //  2）、方法
    int missiles;//导弹数量
    String callSign;//呼叫信号

    private static   int numberOfF18s = 0;


    public F18(){
        numberOfF18s++;
    }

    public F18(int missiles, String callSign){
        this.missiles = missiles;
        this.callSign = callSign;
    }


    /**
     * 实例方法：只能对象.的
     */
    public void fire(){
        //1、实例方法：可以调用非static的变量和方法（实例变量、实例方法）
        System.out.println("F18发射导弹！剩余：" + --missiles);
        haha();

        //2、实例方法：可以调用static的变量和方法（类变量、类方法）
        System.out.println(numberOfF18s);
        summary();



    }

    public void haha(){
        System.out.println("hahahaha");
    }

    public static void summary(){
        //3、类方法：能调用static的变量和方法（类变量、类方法）
        System.out.println("F18（总计："+numberOfF18s+" 架）");

        //4、类方法：不能调用非static的变量和方法（实例变量、实例方法）
    }

}
