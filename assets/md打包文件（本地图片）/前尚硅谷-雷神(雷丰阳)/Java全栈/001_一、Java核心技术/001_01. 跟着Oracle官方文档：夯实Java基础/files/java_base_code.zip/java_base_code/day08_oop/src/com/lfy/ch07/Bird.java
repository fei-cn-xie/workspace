package com.lfy.ch07;

public class Bird extends AbstractFly {

    @Override
    void fly() {
        System.out.println("小鸟自由自在....");
    }
}
