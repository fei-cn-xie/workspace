package com.lfy.ch01;

public class FinallyTest1 {

    public static void main(String[] args) {
        // catch 的返回 会被 finally 覆盖掉
        int test = FinallyTest1.test("123");
        System.out.println(test);
    }

    public static int test(String str){
        try{
            int i = Integer.parseInt(str);
            return i;
        }catch(NumberFormatException e){
            return -1;
        }finally{
            // finally 里面的代码会执行，返回值会被覆盖掉
            System.out.println("test结束");
            return 555;
        }
    }
}
