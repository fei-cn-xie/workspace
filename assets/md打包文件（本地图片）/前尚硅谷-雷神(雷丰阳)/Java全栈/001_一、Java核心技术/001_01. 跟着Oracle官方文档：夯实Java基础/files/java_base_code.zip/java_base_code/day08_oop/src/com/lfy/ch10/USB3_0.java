package com.lfy.ch10;

public interface USB3_0 {

    void fastTransfer();
}
