package com.lfy.ch02;

public class SaleTicket implements Runnable {

    int ticketNum = 100;  //实例变量，跟着对象走

    @Override // 定义多线程运行的时候，执行这个代码
    public void run() {
        sale();
    }


    // 抽取卖票办法
    public void sale(){
        while (ticketNum > 0){
            System.out.println(Thread.currentThread().getName() + "卖出一张；剩余" + --ticketNum);
        }
    }
}
