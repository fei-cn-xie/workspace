package com.lfy.java8.lambda;




// 有且仅有一个方法未被覆写，即是函数式接口
@FunctionalInterface  // 标记这是一个函数式接口
public interface HelloInterface {

    void sayHello();

//    default void sayGoodbye() {
//        System.out.println("Goodbye!");
//    }
}
