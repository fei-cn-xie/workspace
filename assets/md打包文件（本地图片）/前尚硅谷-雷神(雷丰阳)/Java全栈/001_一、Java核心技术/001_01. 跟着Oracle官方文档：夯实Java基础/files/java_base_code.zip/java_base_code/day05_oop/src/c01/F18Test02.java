package c01;

public class F18Test02 {
    public static void main(String[] args) {
//        F18Hornet f18 = new F18Hornet("雷雷1号",4);

        //关键字（Java里面提前定死的）
        int a;
        a = 1;
        //在Java中只要不是
        // 8种基本类型 [整数：byte/short/int/long  小数：float/double  字符：char  布尔：boolean]
        // 剩下的都是引用类型 ：String、Person、F18Hornet、Order、Payment；
        // 引用类型：都要用new 关键字创建对象。

        //类（自己写、别人写）都要用 new 关键字创建对象。
        F18Hornet f18;
        f18 = new F18Hornet("雷雷1号",4);

        // 值传递（Java中是把参数的值传给下一个人）


        f18.showStatus();

        //1、发射导弹
        f18.fireMissile();

        f18.takeOff();
        System.out.println("------------------");
        f18.takeOff();
        System.out.println("------------------");

        f18.accelerate(50);

        f18.accelerate(100);
        System.out.println("------------------");
        f18.fireMissile();
        f18.fireMissile();
        f18.fireMissile();
        f18.fireMissile();
        System.out.println("------------------");
        f18.fireMissile();

        f18.land();

        f18.showStatus();

        System.out.println("~~~~~~~~~~~~~~~~~~~~~~");

        f18.takeOff();
//        f18.fireMissile();
//        f18.fireMissile(2);
//        f18.fireMissile("民兵3");
        f18.fireMissile("标准3",3);

        new String().getBytes();

    }
}
