package com.lfy.ch03;

import java.util.Arrays;

public class StudentTest {

    public static void main(String[] args) {
        Student s1 = new Student("张三1", 20);
        Student s2 = new Student("张三2", 19);
        Student s3 = new Student("张三3", 24);
        Student s4 = new Student("张三4", 14);
        Student s5 = new Student("张三5", 23);


        //1、为数组里面的student排序
        Student[] students = {s1, s2, s3, s4, s5};

        // 需要你告诉JVM，怎么给数组里面的元素排序的
        Arrays.sort(students);

        //打印排序后的结果
        for (Student student : students) {
            System.out.println(student);
        }

        //1）、自己挨个遍历排序(不想)
        //2）、调用数组的sort方法排序（说清楚排序规则）
        //   1)、实现 Comparable 接口
        //   2)、写一个Comparator 比较器

    }
}
