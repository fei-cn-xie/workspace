package com.lfy.ch1;

public class HelloTest {

    public static void main(String[] args) {
        //1、创建对象，才可以调用方法
        Hello hello = new Hello();


        hello.haha();


    }
}
