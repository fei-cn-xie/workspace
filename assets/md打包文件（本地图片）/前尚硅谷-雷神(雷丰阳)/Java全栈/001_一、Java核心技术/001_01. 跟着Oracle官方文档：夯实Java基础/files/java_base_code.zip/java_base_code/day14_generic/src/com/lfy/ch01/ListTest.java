package com.lfy.ch01;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class ListTest {

    //@Test 功能是 junit 库的，必须先导入 junit 库


    // 体会：泛型(提前占位)；给具体的类型，留个空位，将来用什么类型，再具体说明；还能实现类型精确
    // 泛型：编译期间就确定好（）；
    @Test
    public void test02(){
        // E：泛型名字;
        List<String> list = new ArrayList<>();
        List<Integer> list2 = new ArrayList<>();

        list.add("aaaa");
        list.add("bbbbb");

        String s = list.get(0);

    }


    @Test
    public void test01(){
        //<>：菱形符号； 泛型
        List list = new ArrayList();
        list.add("aaaa");
        list.add(1234);


        // 所有人都是Object类型的引用； 向下转型；  父类型可以引用子类对象（多态机制）
        String o = (String) list.get(0);
        o.substring(0,2);

    }
}
