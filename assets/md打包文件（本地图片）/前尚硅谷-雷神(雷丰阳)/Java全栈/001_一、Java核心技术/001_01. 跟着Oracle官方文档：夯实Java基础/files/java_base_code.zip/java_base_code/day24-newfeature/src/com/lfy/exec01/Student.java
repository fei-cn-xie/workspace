package com.lfy.exec01;


import lombok.Data;

import java.io.Serializable;

/**
 * 学生类: 学号、姓名、年龄、班级
 */


public class Student implements Serializable {

    private Long id;
    private String name;
    private Integer age;
    private String gradeName;

    public Student() {
    }

    public Student(Long id, String name, Integer age, String gradeName) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gradeName = gradeName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getGradeName() {
        return gradeName;
    }

    public void setGradeName(String gradeName) {
        this.gradeName = gradeName;
    }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", gradeName='" + gradeName + '\'' +
                '}';
    }
}
