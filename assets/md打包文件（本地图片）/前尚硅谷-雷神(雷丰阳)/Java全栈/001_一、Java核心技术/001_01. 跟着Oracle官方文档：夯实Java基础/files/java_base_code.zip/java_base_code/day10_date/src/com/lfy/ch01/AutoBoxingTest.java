package com.lfy.ch01;


/**
 * 自动装箱和拆箱
 * 包装类就是一个大箱子；
 * 1、 Integer a = 1; [自动装箱]
 * 2、 int c = a;     [自动拆箱]
 *
 * 优先使用包装类； 不用管类型转换，自动
 * 装箱： 基本类型 -> 包装类
 * 拆箱： 包装类 -> 基本类型
 *
 * 包装类有缓存机制；（-128~127）
 */
public class AutoBoxingTest {

    public static void main(String[] args) {
        String abc ="雷丰阳";
        Integer a = 1;
        int b = 2;
        int c = a;

        System.out.println(a + b);


        System.out.println("=====================");
        Integer x = 1;
        Integer y = 1;
        System.out.println(x == y);
        System.out.println("=====================");

        // 缓存机制; 不是永远 new Integer 返回; -128~127 之间; 放到缓存；
        Integer i = Integer.valueOf(128);  // 从那个缓存数组中拿到指定位置的对象。
        Integer j = Integer.valueOf(128);
        System.out.println( i == j); // false:1   true:2

//        Long.valueOf(128);




    }
}
