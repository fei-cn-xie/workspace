package com.lfy.ch02;


/**
 * 测试线程的创建和启动
 */
public class ThreadTest {


    // main方法期间，其他线程运行完，main方法才结束
    public static void main(String[] args) {
        System.out.println("main 方法启动...");


        //1、后台执行打印 1-10;
        //1）、创建一个可执行的任务对象
        Runnable runnable = new MyRunnable();
        //2）、创建一个线程对象，让他执行这个任务
        Thread thread = new Thread(runnable);
        //3）、启动线程，他才可以在后台执行
        thread.start();

        //效果： 这个线程做的事情，不会阻塞当前线程代码的执行


        //Java 里面底层启动线程的唯一办法，就是 调用Thread类的start方法
        //匿名内部类； 多线程如何执行？ 等待CPU时间片轮换（并发、并行）
        // 单核CPU：并发执行，CPU时间片轮换执行
        // 多核CPU：并行执行，多个CPU同时执行不同线程

        Runnable r2 = new Runnable(){
            @Override
            public void run() {
                for (int i = 1; i <= 100; i++) {
                    System.out.println("匿名内部类执行：" + i);
                }
            }
        };

//        new Thread(r2).start();

        //lambda表达式： 函数式接口的对象创建
        //写法很简单：  从小括号开始复制粘贴到方法结束，然后在 () 和 {} 之间，加上 ->

        Runnable r3 = () -> {
            for (int i = 1; i <= 100; i++) {
                System.out.println("匿名内部类执行：" + i);
            }
        };


        USB usb = new USB() {
            @Override
            public int transfer(String data, int len) {
                System.out.println("传输数据：" + data);
                System.out.println("传输长度：" + len);
                return 1;
            }
        };

        // 参数数据类型可以省略，JVM 自动推断（因为接口定义死了）
        USB u2 = (a,b) -> {
            System.out.println("传输数据：" + a);
            System.out.println("传输长度：" + b);
            return 1;
        };


        USB u3 = (a,b)-> 1; //只有一行代码，这个执行结果，默认就是返回值，可以省略{}


        //启动一个后台线程； 更多用法； 线程池
        new Thread(() -> {
            //只关注真正的业务逻辑，其他什么都不用关心
            System.out.println("后台线程执行 R4...");
        }).start();

        System.out.println("main 方法结束...");


        // 启动一个系统的后台线程
        Thread.ofPlatform().start(()->{
            System.out.println("后台线程执行 R5...");
        });


        // 启动一个虚拟的后台线程(后来更省)
        Thread.ofVirtual().start(()->{
            System.out.println("后台线程执行 R6...");
        });

        //重量级别： 进程(操作系统调度) > 线程(操作系统调度) > 虚拟线程(语言自己调度)
        //轻量的好处： 创建成本低，切换速度快，消耗资源少

    }
}
