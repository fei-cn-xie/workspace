package com.lfy.ch07;

public class FlyTest {

    public static void main(String[] args) {
        AbstractFly bird = new Bird();
        bird.flyInSky();
        bird.flyOnLand();
        bird.flyInSpace();


        System.out.println("==========");

        Rocket rocket = new Rocket();
        rocket.flyOnLand();
        rocket.flyInSky();

        System.out.println("============");
        BirdX birdX = new BirdX();
        birdX.flyOnLand();
        birdX.flyInSky();
        birdX.flyInSpace();
    }
}
