package com.lfy.ch08;

public class TestX {
    public static void main(String[] args) {
        // 静态 》 实例 》 构造器
//        ParentX p = new ParentX();

        // 父 > 子

        ChildX childX = new ChildX();
    }
}
