package com.lfy.ch02.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;


// 心跳：医疗；
public class UdpServer {

    public static void main(String[] args) throws SocketException {

        //1、创建 UDP服务器
        try(DatagramSocket socket = new DatagramSocket(10000);){
            System.out.println("服务器启动，等待收数据...");
            //准备接受数据的包
            byte[] bytes = new byte[1024]; //
            DatagramPacket packet = new DatagramPacket(bytes, bytes.length);
            //收数据
            while (true){
                socket.receive(packet); // 阻塞等待接收数据;
                System.out.println("收到数据包");

                byte[] data = packet.getData(); // 封装数据的字节数组
                int length = packet.getLength();//数据的真实长度
                //打印数据
                System.out.println("收到："+new String(data, 0, length));


                //继续往出发
//                socket.send(new DatagramPacket(data, length, "",));
            }


        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }
}
