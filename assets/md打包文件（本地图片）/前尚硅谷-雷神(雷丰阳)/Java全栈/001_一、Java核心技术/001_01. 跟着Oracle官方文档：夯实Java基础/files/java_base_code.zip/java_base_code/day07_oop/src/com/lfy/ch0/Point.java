package com.lfy.ch0;

public class Point {
    //定义坐标点； 属性初始化默认值；数字：0/0.0  布尔：false  引用类型：null
    int x;
    int y;


    //无参构造器
    public Point(){

    }

    //有参构造器； 把形参的值，赋值给属性；  x= 10; y = 15
    //1）、如果形参的名字和属性名一样，为了避免混淆，一定需要用this关键字区分；
    //2）、否则就可以不用写
    public Point(int x,int y){
        this.x = x;
        this.y = y;
        // 变量都有一个作用域，局部变量； 形参x,y； 以后这个代码块里面用的都是离自己最近的同名变量；
        // 【就近原则】this：当前对象
        // 不用this：x=0,y=0

    }


    public void printPoint(){
        System.out.println("x="+x+",y="+y);
    }

}
