package com.lfy.ch05;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.junit.Test;

public class CommonsIOTest {



    // AI: 给用使用 commons-io 库， 编写20个案例

    @Test
    public void testCommonsIO() {
        // IOUtils
        // FileUtils

    }

}
