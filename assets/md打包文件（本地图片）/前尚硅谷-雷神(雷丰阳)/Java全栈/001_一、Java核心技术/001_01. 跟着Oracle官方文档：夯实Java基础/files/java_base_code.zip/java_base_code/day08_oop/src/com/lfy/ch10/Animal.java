package com.lfy.ch10;

public class Animal {
    public void makeSound() {
        System.out.println("动物发出声音");
    }

    public static void main(String[] args) {
        // 【就近原则】
        // 向上转型：父类引用指向子类对象
        Animal animal1 = new Dog();
        Animal animal2 = new Cat();

        // 运行时多态：根据实际对象类型调用相应的方法
        animal1.makeSound(); // 输出"汪汪汪！"（动态绑定到Dog的方法）
        animal2.makeSound(); // 输出"喵喵喵！"（动态绑定到Cat的方法）


    }
}
