package com.lfy.ch01;

import org.junit.Test;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/**
 * 字符 变为 字节： 编码(变成01进行存储)
 * 字节 变为 字符： 解码(将01还原成字符)
 */
public class LuanCodeTest {



    @Test
    public void test02(){
        // 1. 原始字符串（包含中文和特殊符号）
        String original = "你好，世界！🌍";

        // 2. 使用UTF-8编码为字节流；  正确编码解码（UTF-8）
        byte[] utf8Bytes = original.getBytes(StandardCharsets.UTF_8);
        String decodedUtf8 = new String(utf8Bytes, StandardCharsets.UTF_8);
        System.out.println("正确解码: " + decodedUtf8); // 输出正常


        // 3. 错误操作：用GBK解码UTF-8字节（模拟乱码场景）
        String gibberish = new String(utf8Bytes, Charset.forName("GBK"));
        System.out.println("乱码结果: " + gibberish); // 输出：浣犲ソ锛屼笘鐣岋紒馃實

        // 4. 逆向修复乱码
        byte[] recoveredBytes = gibberish.getBytes(Charset.forName("GBK"));
        String recovered = new String(recoveredBytes, StandardCharsets.UTF_8);
        System.out.println("修复后: " + recovered); // 输出：你好，世界！🌍
    }

    // UTF-8 是默认的
    @Test
    public void test01(){ // ([][])  ([][])  ([][])  ([][])  (补零[])
        //默认使用的是utf-8编码  (【】【】)  (补零【】)
        // 两个字符 ([][])([][])([][])
        //简单字符：ASCII码表  只有一个字节; 其他字符集基本兼容 ASCII；
        String s = "哈";  //

        //得到这个字符的字节数组；   默认UTF8进行编码
        byte[] bytes = s.getBytes(StandardCharsets.UTF_8); // 3个字节 的数组
        System.out.println(bytes.length);

        // 默认使用utf-8解码
        String s1 = new String(bytes, StandardCharsets.UTF_8);
        System.out.println("不乱："+s1);

        // 使用 GBK 错误的算法进行解码; 2个字节   [11100100 10111101]  [00000000   10100000]
        String s2 = new String(bytes, Charset.forName("GBK"));
        System.out.println("乱："+s2);

        // 继续使用原来错误的算法进行编码 成 字节数组
        byte[] originByte = s2.getBytes(Charset.forName("GBK"));
        // 使用正确的算法进行解码
        String s3 = new String(originByte, StandardCharsets.UTF_8);
        System.out.println("不乱："+s3);

    }
}
