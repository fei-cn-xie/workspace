import sys #导入sys库用于查看Python的版本
import pandas as pd #导入pandas
import numpy as np
print('当前使用 Python 版本为： ' + sys.version)
print('当前使用 Pandas 版本为： ' + pd.__version__)
print('当前使用 Numpy 版本为： ' + np.__version__)


print(dir(pd))
