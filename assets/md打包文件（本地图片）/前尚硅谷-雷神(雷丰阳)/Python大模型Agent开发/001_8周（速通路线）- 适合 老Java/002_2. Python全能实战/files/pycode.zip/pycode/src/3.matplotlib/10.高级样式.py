import data.sales_data as sd
import matplotlib.pyplot as plt
import numpy as np

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 黑体或微软雅黑
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
# 导入数据
df_sales, df_orders = sd.load_data()

# 1. 内置样式
def plot01():
    # 查看所有可用样式
    print(plt.style.available)

    # 使用样式
    plt.style.use('seaborn-v0_8-dark')  # 或 'ggplot', 'fivethirtyeight' 等
    plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 黑体或微软雅黑
    plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题


    # 绘图示例
    fig, ax = plt.subplots(figsize=(12, 6))
    daily_sales = df_sales.groupby('日期')['销售额'].sum()
    ax.plot(daily_sales.index, daily_sales.values, linewidth=2.5)
    ax.set_title('使用 Seaborn 样式的销售趋势', fontsize=16, fontweight='bold')
    ax.set_xlabel('日期', fontsize=12)
    ax.set_ylabel('销售额（元）', fontsize=12)
    plt.tight_layout()
    plt.show()

    # 恢复默认样式
    plt.style.use('default')

# rcParams
def plot02():
    # 设置全局参数
    plt.rcParams.update({
        'font.size': 11,
        'font.family': 'Microsoft YaHei',
        'axes.labelsize': 12,
        'axes.titlesize': 14,
        'axes.titleweight': 'bold',
        'axes.grid': True,
        'grid.alpha': 0.3,
        'lines.linewidth': 2,
        'figure.figsize': (12, 6),
        'figure.dpi': 100,
        'savefig.dpi': 300,
        'legend.fontsize': 10,
        'xtick.labelsize': 10,
        'ytick.labelsize': 10
    })


# 配色方案
def plot03():
    # 定义配色方案
    color_palette = {
        'primary': '#2C3E50',
        'secondary': '#E74C3C',
        'success': '#27AE60',
        'info': '#3498DB',
        'warning': '#F39C12',
        'danger': '#C0392B',
        'light': '#ECF0F1',
        'dark': '#34495E'
    }

    # 应用配色
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))

    # 子图1：使用主色调
    gender_sales = df_sales.groupby('客户性别')['销售额'].sum()
    axes[0, 0].bar(gender_sales.index, gender_sales.values, 
                color=[color_palette['info'], color_palette['secondary']])
    axes[0, 0].set_title('性别销售对比', fontsize=14, fontweight='bold')

    # 子图2：渐变色
    category_sales = df_sales.groupby('商品品类')['销售额'].sum().sort_values(ascending=False)
    colors_gradient = plt.cm.Blues(np.linspace(0.4, 0.9, len(category_sales)))
    axes[0, 1].barh(range(len(category_sales)), category_sales.values, color=colors_gradient)
    axes[0, 1].set_yticks(range(len(category_sales)))
    axes[0, 1].set_yticklabels(category_sales.index)
    axes[0, 1].set_title('商品品类销售排名', fontsize=14, fontweight='bold')
    axes[0, 1].invert_yaxis()

    # 子图3：多色折线
    daily_profit = df_sales.groupby('日期')['利润'].sum()
    axes[1, 0].plot(daily_profit.index, daily_profit.values, 
                    color=color_palette['success'], linewidth=2.5)
    axes[1, 0].fill_between(daily_profit.index, daily_profit.values, 
                            alpha=0.3, color=color_palette['success'])
    axes[1, 0].set_title('每日利润趋势', fontsize=14, fontweight='bold')
    axes[1, 0].grid(True, alpha=0.3)

    # 子图4：饼图配色
    top5_region = df_sales.groupby('区域')['销售额'].sum().nlargest(5)
    pie_colors = [color_palette['info'], color_palette['success'], 
                color_palette['warning'], color_palette['secondary'], 
                color_palette['primary']]
    axes[1, 1].pie(top5_region.values, labels=top5_region.index, 
                autopct='%1.1f%%', colors=pie_colors, startangle=90)
    axes[1, 1].set_title('Top 5 区域销售占比', fontsize=14, fontweight='bold')

    plt.suptitle('专业配色方案示例', fontsize=18, fontweight='bold', y=0.995)
    plt.tight_layout()
    plt.show()

plot03()