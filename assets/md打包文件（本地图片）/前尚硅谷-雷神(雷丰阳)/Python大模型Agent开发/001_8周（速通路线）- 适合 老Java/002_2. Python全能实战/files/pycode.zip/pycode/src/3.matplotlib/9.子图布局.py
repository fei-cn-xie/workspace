import data.sales_data as sd
import matplotlib.pyplot as plt

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 黑体或微软雅黑
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 导入数据
df_sales, df_orders = sd.load_data()

### 1. 基础子图布局
def plot01():
    fig, axes = plt.subplots(2, 2, figsize=(12, 6))
    fig.suptitle('电商销售数据分析仪表盘', fontsize=18, fontweight='bold', y=0.995)

    # 子图1：每日销售额趋势
    daily_sales = df_sales.groupby('日期')['销售额'].sum()
    axes[0, 0].plot(daily_sales.index, daily_sales.values, color='steelblue', linewidth=2)
    axes[0, 0].set_title('每日销售额趋势', fontsize=14, fontweight='bold')
    axes[0, 0].set_xlabel('日期')
    axes[0, 0].set_ylabel('销售额（元）')
    axes[0, 0].grid(True, alpha=0.3)

    # 子图2：商品品类销售占比
    category_sales = df_sales.groupby('商品品类')['销售额'].sum()
    axes[0, 1].pie(category_sales.values, labels=category_sales.index, 
                autopct='%1.1f%%', startangle=90)
    axes[0, 1].set_title('商品品类销售占比', fontsize=14, fontweight='bold')

    # 子图3：Top 10 区域销售额
    region_sales = df_sales.groupby('区域')['销售额'].sum().nlargest(10)
    axes[1, 0].barh(range(len(region_sales)), region_sales.values, color='coral')
    axes[1, 0].set_yticks(range(len(region_sales)))
    axes[1, 0].set_yticklabels(region_sales.index, fontsize=9)
    axes[1, 0].set_title('Top 10 区域销售额', fontsize=14, fontweight='bold')
    axes[1, 0].set_xlabel('销售额（元）')
    axes[1, 0].invert_yaxis()

    # 子图4：客户年龄分布
    axes[1, 1].hist(df_sales['客户年龄'], bins=30, color='lightgreen', edgecolor='black')
    axes[1, 1].set_title('客户年龄分布', fontsize=14, fontweight='bold')
    axes[1, 1].set_xlabel('年龄')
    axes[1, 1].set_ylabel('频数')
    axes[1, 1].grid(axis='y', alpha=0.3)

    plt.tight_layout()
    plt.show()

### 2. 不规则子图布局
def plot02():
    fig = plt.figure(figsize=(16, 10))
    gs = fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)

    # 大图：占据上方2行
    ax1 = fig.add_subplot(gs[0:2, :])
    daily_sales = df_sales.groupby('日期')['销售额'].sum()
    ax1.plot(daily_sales.index, daily_sales.values, color='steelblue', linewidth=2.5)
    ax1.fill_between(daily_sales.index, daily_sales.values, alpha=0.3)
    ax1.set_title('每日销售额趋势（主图）', fontsize=16, fontweight='bold')
    ax1.set_ylabel('销售额（元）', fontsize=12)
    ax1.grid(True, alpha=0.3)

    # 小图1：左下
    ax2 = fig.add_subplot(gs[2, 0])
    gender_sales = df_sales.groupby('客户性别')['销售额'].sum()
    ax2.bar(gender_sales.index, gender_sales.values, color=['#3498db', '#e74c3c'])
    ax2.set_title('性别销售对比', fontsize=12, fontweight='bold')
    ax2.set_ylabel('销售额（元）')

    # 小图2：中下
    ax3 = fig.add_subplot(gs[2, 1])
    profit_margin = (df_sales['利润'] / df_sales['销售额'] * 100).dropna()
    ax3.hist(profit_margin, bins=30, color='lightcoral', edgecolor='black')
    ax3.set_title('利润率分布', fontsize=12, fontweight='bold')
    ax3.set_xlabel('利润率（%）')

    # 小图3：右下
    ax4 = fig.add_subplot(gs[2, 2])
    top5_category = df_sales.groupby('商品品类')['销售数'].sum().nlargest(5)
    ax4.pie(top5_category.values, labels=top5_category.index, autopct='%1.0f%%')
    ax4.set_title('Top 5 品类销量', fontsize=12, fontweight='bold')

    plt.suptitle('电商销售综合分析', fontsize=18, fontweight='bold', y=0.995)
    plt.show()

### 3. 双Y轴图表
def plot03():
    # 数据准备
    daily_data = df_sales.groupby('日期').agg({
        '销售额': 'sum',
        '利润': 'sum'
    }).reset_index()
    daily_data['利润率'] = (daily_data['利润'] / daily_data['销售额'] * 100)

    fig, ax1 = plt.subplots(figsize=(14, 6))

    # 左Y轴：销售额
    ax1.set_xlabel('日期', fontsize=12)
    ax1.set_ylabel('销售额（元）', color='#3498db', fontsize=12)
    line1 = ax1.plot(daily_data['日期'], daily_data['销售额'], 
                    color='#3498db', linewidth=2.5, label='销售额')
    ax1.tick_params(axis='y', labelcolor='#3498db')
    ax1.grid(True, alpha=0.3)

    # 右Y轴：利润率
    ax2 = ax1.twinx()
    ax2.set_ylabel('利润率（%）', color='#e74c3c', fontsize=12)
    line2 = ax2.plot(daily_data['日期'], daily_data['利润率'], 
                    color='#e74c3c', linewidth=2.5, linestyle='--', label='利润率')
    ax2.tick_params(axis='y', labelcolor='#e74c3c')

    # 合并图例
    lines = line1 + line2
    labels = [l.get_label() for l in lines]
    ax1.legend(lines, labels, loc='upper left', fontsize=11)

    plt.title('销售额与利润率双轴分析', fontsize=16, fontweight='bold', pad=20)
    plt.tight_layout()
    plt.show()


plot03()