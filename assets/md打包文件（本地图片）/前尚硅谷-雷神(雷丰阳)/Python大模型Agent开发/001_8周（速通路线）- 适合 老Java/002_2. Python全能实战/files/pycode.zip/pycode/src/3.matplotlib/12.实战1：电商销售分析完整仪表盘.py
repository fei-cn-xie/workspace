import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from matplotlib.gridspec import GridSpec

# 数据加载与预处理
df_sales = pd.read_excel('docs/data/电商销售数据.xlsx')
df_sales['日期'] = pd.to_datetime(df_sales['日期'])
df_sales['进货价格'] = df_sales['进货价格'].str.replace('¥', '').astype(float)
df_sales['实际售价'] = df_sales['实际售价'].astype(float)
df_sales['利润率'] = (df_sales['利润'] / df_sales['销售额'] * 100)

# 设置样式
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

# 创建画布
fig = plt.figure(figsize=(20, 14))
gs = GridSpec(3, 3, figure=fig, hspace=0.3, wspace=0.3)

# ========== 子图1：销售额与利润双轴趋势（大图） ==========
ax1 = fig.add_subplot(gs[0, :])
daily_data = df_sales.groupby('日期').agg({
    '销售额': 'sum',
    '利润': 'sum'
}).reset_index()
daily_data['利润率'] = (daily_data['利润'] / daily_data['销售额'] * 100)

color1 = '#2C3E50'
ax1.set_xlabel('日期', fontsize=12)
ax1.set_ylabel('销售额（元）', color=color1, fontsize=12, fontweight='bold')
line1 = ax1.plot(daily_data['日期'], daily_data['销售额'], 
                 color=color1, linewidth=3, label='销售额', marker='o', markersize=4)
ax1.fill_between(daily_data['日期'], daily_data['销售额'], alpha=0.2, color=color1)
ax1.tick_params(axis='y', labelcolor=color1)
ax1.grid(True, alpha=0.3)

ax1_twin = ax1.twinx()
color2 = '#E74C3C'
ax1_twin.set_ylabel('利润率（%）', color=color2, fontsize=12, fontweight='bold')
line2 = ax1_twin.plot(daily_data['日期'], daily_data['利润率'], 
                      color=color2, linewidth=2.5, linestyle='--', 
                      label='利润率', marker='s', markersize=4)
ax1_twin.tick_params(axis='y', labelcolor=color2)

lines = line1 + line2
labels = [l.get_label() for l in lines]
ax1.legend(lines, labels, loc='upper left', fontsize=11, framealpha=0.9)
ax1.set_title('销售额与利润率趋势分析', fontsize=16, fontweight='bold', pad=15)

# ========== 子图2：商品品类销售排名 ==========
ax2 = fig.add_subplot(gs[1, 0])
category_sales = df_sales.groupby('商品品类')['销售额'].sum().sort_values(ascending=True)
colors_gradient = plt.cm.RdYlGn(np.linspace(0.3, 0.9, len(category_sales)))
bars = ax2.barh(range(len(category_sales)), category_sales.values, color=colors_gradient)
ax2.set_yticks(range(len(category_sales)))
ax2.set_yticklabels(category_sales.index, fontsize=10)
ax2.set_xlabel('销售额（元）', fontsize=11)
ax2.set_title('商品品类销售排名', fontsize=13, fontweight='bold')
ax2.grid(axis='x', alpha=0.3)

# 添加数值标签
for i, (bar, value) in enumerate(zip(bars, category_sales.values)):
    ax2.text(value, i, f' ¥{value/10000:.1f}万', 
             va='center', fontsize=9, fontweight='bold')


# ========== 子图3：性别销售对比（分组柱状图） ==========
ax3 = fig.add_subplot(gs[1, 1])
gender_category = df_sales.groupby(['商品品类', '客户性别'])['销售额'].sum().unstack()
x = range(len(gender_category))
width = 0.35
bars1 = ax3.bar([i - width/2 for i in x], gender_category['男'], 
                width, label='男性', color='#3498DB', alpha=0.85)
bars2 = ax3.bar([i + width/2 for i in x], gender_category['女'], 
                width, label='女性', color='#E74C3C', alpha=0.85)
ax3.set_xticks(x)
ax3.set_xticklabels(gender_category.index, rotation=45, ha='right', fontsize=9)
ax3.set_ylabel('销售额（元）', fontsize=11)
ax3.set_title('不同性别商品偏好分析', fontsize=13, fontweight='bold')
ax3.legend(fontsize=10)
ax3.grid(axis='y', alpha=0.3)

# ========== 子图4：区域销售热力图 ==========
ax4 = fig.add_subplot(gs[1, 2])
top_regions = df_sales.groupby('区域')['销售额'].sum().nlargest(6).index
df_filtered = df_sales[df_sales['区域'].isin(top_regions)]
heatmap_data = df_filtered.pivot_table(
    values='销售额',
    index='商品品类',
    columns='区域',
    aggfunc='sum',
    fill_value=0
)
im = ax4.imshow(heatmap_data.values, cmap='YlOrRd', aspect='auto')
ax4.set_xticks(range(len(heatmap_data.columns)))
ax4.set_yticks(range(len(heatmap_data.index)))
ax4.set_xticklabels(heatmap_data.columns, rotation=45, ha='right', fontsize=9)
ax4.set_yticklabels(heatmap_data.index, fontsize=9)
ax4.set_title('区域×品类销售热力图', fontsize=13, fontweight='bold')

# 添加数值
for i in range(len(heatmap_data.index)):
    for j in range(len(heatmap_data.columns)):
        value = heatmap_data.values[i, j]
        if value > 0:
            text_color = 'white' if value > heatmap_data.values.max()/2 else 'black'
            ax4.text(j, i, f'{value/10000:.0f}万',
                    ha="center", va="center", color=text_color, fontsize=8)

# ========== 子图5：客户年龄分布 ==========
ax5 = fig.add_subplot(gs[2, 0])
male_age = df_sales[df_sales['客户性别'] == '男']['客户年龄']
female_age = df_sales[df_sales['客户性别'] == '女']['客户年龄']
ax5.hist([male_age, female_age], bins=25, 
         label=['男性', '女性'],
         color=['#3498DB', '#E74C3C'],
         alpha=0.7,
         edgecolor='black',
         linewidth=0.5)
ax5.set_xlabel('年龄', fontsize=11)
ax5.set_ylabel('频数', fontsize=11)
ax5.set_title('客户年龄分布', fontsize=13, fontweight='bold')
ax5.legend(fontsize=10)
ax5.grid(axis='y', alpha=0.3)

# ========== 子图6：利润率箱线图 ==========
ax6 = fig.add_subplot(gs[2, 1])
categories = df_sales['商品品类'].unique()
profit_margin_by_cat = [df_sales[df_sales['商品品类'] == cat]['利润率'].dropna().values 
                        for cat in categories]
bp = ax6.boxplot(profit_margin_by_cat, 
                 tick_labels=categories,
                 patch_artist=True,
                 notch=True,
                 showmeans=True)
colors_box = plt.cm.Set3(range(len(categories)))
for patch, color in zip(bp['boxes'], colors_box):
    patch.set_facecolor(color)
    patch.set_alpha(0.7)
ax6.set_xticklabels(categories, rotation=45, ha='right', fontsize=9)
ax6.set_ylabel('利润率（%）', fontsize=11)
ax6.set_title('各品类利润率分布', fontsize=13, fontweight='bold')
ax6.grid(axis='y', alpha=0.3)

# ========== 子图7：Top 10 区域销售占比 ==========
ax7 = fig.add_subplot(gs[2, 2])
top10_regions = df_sales.groupby('区域')['销售额'].sum().nlargest(10)
colors_pie = plt.cm.tab20(range(len(top10_regions)))
wedges, texts, autotexts = ax7.pie(
    top10_regions.values,
    labels=top10_regions.index,
    autopct='%1.1f%%',
    startangle=90,
    colors=colors_pie,
    pctdistance=0.85,
    wedgeprops=dict(width=0.6, edgecolor='white', linewidth=2)
)
for text in texts:
    text.set_fontsize(8)
for autotext in autotexts:
    autotext.set_color('white')
    autotext.set_fontweight('bold')
    autotext.set_fontsize(8)
ax7.set_title('Top 10 区域销售占比', fontsize=13, fontweight='bold')

# 总标题
fig.suptitle('电商销售数据综合分析仪表盘', 
             fontsize=20, fontweight='bold', y=0.995)

# 保存图表
plt.savefig('电商销售分析仪表盘.png', dpi=300, bbox_inches='tight')
plt.show()

print("✅ 仪表盘生成完成！")