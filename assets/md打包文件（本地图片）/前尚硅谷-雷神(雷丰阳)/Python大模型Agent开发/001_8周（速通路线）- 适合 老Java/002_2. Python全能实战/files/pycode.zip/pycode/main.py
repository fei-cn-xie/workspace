# 打印 numpy 版本
import numpy as np

print(np.__version__)

print("hello world")
