#构建一个数据集
import pandas as pd

df = pd.DataFrame({
    'A': [10, 20, 30],
    'B': [40, 50, 60],
    'C': [70, 80, 90]
}, index=['x', 'y', 'z'])
print(df)

#可以选择插入的位置，1代表在第二列新增一列
df.insert(1,'m',[22,33,44],allow_duplicates=True)
print(df)

df['n']=[55,66,77]
print(df)

df.loc['z1'] = [0,0,0,0,0]
print(df)

# 按标签删除行
df1 = df.drop(labels='y',axis=0)
print(df1)

df2 = df.drop(labels=['x', 'z'],axis=0)
print(df)
print(df2)

df3 = df.drop('B', axis=1)
print(df)
print(df3)

df4 = df.drop(columns=['A', 'C'])
print(df)
print(df4)

df.drop('A', axis=1, inplace=True)
print(df)

df.drop('aaa', axis=1, errors='ignore')
# 报错，因为列 'aaa' 不存在。


print(df)
# 修改单个值
df.loc['y', 'B'] = 99
print(df)

# 直接修改整列
df['m'] = [100, 200, 300,400]
print(df)

# loc修改整列
df.loc[:, 'B'] = [100, 200, 300,400]
print(df)

# 修改多列
df.loc[:, ['m', 'B']] = df[['m', 'B']] * 10
print(df)

# 按条件修改； 当列 A 的值大于 150 时，将对应的列 B 设为 0。
df.loc[df['m'] > 1500, 'B'] = 0
print(df)

# 修改单个元素 i = index（索引） ； loc = location（定位）
df.iloc[1, 0] = 999  # 第二行第一列
print(df)

# 修改整行
df.iloc[2] = [1, 2, 3, 4]
print(df)

# 修改整列
df.iloc[:, 1] = [11, 22, 33,44]
print(df)

# df['A'] :选择列；  df.loc['x','A'] :标签选择行/列   df.iloc[0,1] :索引选择行/列

df.at['x','B'] = 666

df.iat[0,0] = 777

print(df)

# 通过函数映射修改
df['B'] = df['B'].apply(lambda x: x * 2)
print(df)

# 使用字典映射修改
df['B'] = df['B'].replace({44: 999, 66: 600})
print(df)

df.index = ['a', 'b', 'c', 'd']
df.columns = ['A', 'B', 'C', 'D']
df.rename(index={'a': 'A', 'b': 'B'}, columns={'B': 'BB'}, inplace=True)
print(df)