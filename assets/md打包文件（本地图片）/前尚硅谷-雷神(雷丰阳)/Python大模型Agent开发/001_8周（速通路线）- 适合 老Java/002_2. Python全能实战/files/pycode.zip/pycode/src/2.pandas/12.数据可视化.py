import matplotlib.pyplot as plt
import pandas as pd
plt.rcParams['font.sans-serif'] = ['SimHei']  # 中文显示
plt.rcParams['axes.unicode_minus'] = False

df_orders = pd.read_csv('docs/data/用户下单数据.csv',encoding='gbk')
print(df_orders)

# 学历分布柱状图
df_orders['文化程度'].value_counts().plot(kind='bar')
plt.title('用户学历分布')
plt.xlabel('学历')
plt.ylabel('人数')
plt.show()

# 交易金额分布直方图
df_orders['交易金额'].plot(kind='hist', bins=50)
plt.title('交易金额分布')
plt.xlabel('交易金额')
plt.show()

# 性别消费对比
df_orders.groupby('性别')['交易金额'].mean().plot(kind='bar')
plt.title('不同性别平均消费')
plt.ylabel('平均交易金额（元）')
plt.show()
