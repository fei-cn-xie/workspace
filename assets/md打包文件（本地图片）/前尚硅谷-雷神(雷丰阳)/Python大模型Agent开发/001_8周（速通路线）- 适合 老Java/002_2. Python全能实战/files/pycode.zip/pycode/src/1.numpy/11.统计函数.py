import numpy as np

data = np.array([23, 45, 67, 89, 12, 34, 56, 78, 90, 11])

# 平均值
mean = np.mean(data)
print(f"平均值: {mean}")  # 50.5

# 中位数
median = np.median(data)
print(f"中位数: {median}")  # 50.5

data2 = np.array([2,4,6,8,10])
# 标准差
std = np.std(data2)
print(f"标准差: {std}")  # 28.17...

# 方差
var = np.var(data2)
print(f"方差: {var}")  # 793.65

# 最大/最小值
print(f"最大值: {np.max(data)}")  # 90
print(f"最小值: {np.min(data)}")  # 11

# 极差
print(f"极差: {np.ptp(data)}")  # 79 (90-11)

# 百分位数
print(f"25%分位数: {np.percentile(data, 25)}")
print(f"75%分位数: {np.percentile(data, 75)}")


x = np.array([1, 2, 3, 4, 5])
y = np.array([2, 4, 5, 4, 5])

# 相关系数矩阵
corr_matrix = np.corrcoef(x, y)
print("相关系数矩阵:\n", corr_matrix)
# [[1.         0.77459667]
#  [0.77459667 1.        ]]

# 协方差矩阵
cov_matrix = np.cov(x, y)
print("协方差矩阵:\n", cov_matrix)




