import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

# 设置样式
sns.set_theme(style='ticks', palette='Set2')
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 加载数据
penguins = sns.load_dataset('penguins')
penguins_clean = penguins.dropna()

# 创建综合分析
fig = plt.figure(figsize=(18, 12))

# 1. 物种分布
ax1 = plt.subplot(3, 4, 1)
sns.countplot(data=penguins_clean, x='species', palette='Set2')
plt.title('企鹅物种分布')
plt.ylabel('数量')

# 2. 岛屿分布
ax2 = plt.subplot(3, 4, 2)
sns.countplot(data=penguins_clean, x='island', hue='species', palette='Set2')
plt.title('不同岛屿的物种分布')
plt.xticks(rotation=45)

# 3. 性别分布
ax3 = plt.subplot(3, 4, 3)
sns.countplot(data=penguins_clean, x='sex', hue='species', palette='Set2')
plt.title('性别分布')

# 4. 喙长分布
ax4 = plt.subplot(3, 4, 4)
sns.histplot(data=penguins_clean, x='bill_length_mm', hue='species', 
             kde=True, bins=20, palette='Set2')
plt.title('喙长分布')

# 5. 喙长 vs 喙深
ax5 = plt.subplot(3, 4, 5)
sns.scatterplot(data=penguins_clean, x='bill_length_mm', y='bill_depth_mm',
                hue='species', style='species', s=100, palette='Set2')
plt.title('喙部特征关系')

# 6. 鳍长 vs 体重
ax6 = plt.subplot(3, 4, 6)
sns.scatterplot(data=penguins_clean, x='flipper_length_mm', y='body_mass_g',
                hue='species', style='sex', s=100, palette='Set2')
plt.title('鳍长与体重关系')

# 7. 体重箱线图
ax7 = plt.subplot(3, 4, 7)
sns.boxplot(data=penguins_clean, x='species', y='body_mass_g', palette='Set2')
plt.title('不同物种的体重分布')
plt.ylabel('体重 (g)')

# 8. 鳍长小提琴图
ax8 = plt.subplot(3, 4, 8)
sns.violinplot(data=penguins_clean, x='species', y='flipper_length_mm',
               hue='sex', split=True, palette='Set2')
plt.title('鳍长分布（按性别）')

# 9. 喙长回归
ax9 = plt.subplot(3, 4, 9)
sns.regplot(data=penguins_clean, x='bill_length_mm', y='bill_depth_mm',
            scatter_kws={'alpha': 0.5})
plt.title('喙长与喙深回归')

# 10. 体重与鳍长回归
ax10 = plt.subplot(3, 4, 10)
sns.regplot(data=penguins_clean, x='flipper_length_mm', y='body_mass_g',
            scatter_kws={'alpha': 0.5}, color='coral')
plt.title('鳍长与体重回归')

# 11. 特征相关性热力图
ax11 = plt.subplot(3, 4, 11)
numeric_cols = ['bill_length_mm', 'bill_depth_mm', 'flipper_length_mm', 'body_mass_g']
corr = penguins_clean[numeric_cols].corr()
sns.heatmap(corr, annot=True, fmt='.2f', cmap='coolwarm', center=0,
            square=True, linewidths=1)
plt.title('特征相关性矩阵')

# 12. 物种特征对比
ax12 = plt.subplot(3, 4, 12)
species_means = penguins_clean.groupby('species')[numeric_cols].mean()
species_means_norm = (species_means - species_means.min()) / (species_means.max() - species_means.min())
sns.heatmap(species_means_norm.T, annot=True, fmt='.2f', cmap='YlOrRd',
            cbar_kws={'label': '标准化值'})
plt.title('物种特征对比（标准化）')
plt.xlabel('物种')
plt.ylabel('特征')

plt.tight_layout()
plt.savefig('企鹅物种特征分析.png', dpi=300, bbox_inches='tight')
plt.show()

# 统计摘要
print("=" * 50)
print("企鹅数据分析摘要")
print("=" * 50)
print(f"总样本数: {len(penguins_clean)}")
print(f"\n各物种数量:")
print(penguins_clean['species'].value_counts())
print(f"\n各物种平均体重 (g):")
print(penguins_clean.groupby('species')['body_mass_g'].mean().round(2))
print(f"\n各物种平均鳍长 (mm):")
print(penguins_clean.groupby('species')['flipper_length_mm'].mean().round(2))