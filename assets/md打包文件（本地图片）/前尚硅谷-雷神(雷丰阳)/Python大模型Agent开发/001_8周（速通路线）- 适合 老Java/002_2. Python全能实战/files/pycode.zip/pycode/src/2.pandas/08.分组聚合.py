import pandas as pd
df_sale=pd.read_excel(r'docs/data/电商销售数据.xlsx',
                       dtype={'订单号':str},
                       sheet_name='销售数据')#导入销售数据sheet表
print(df_sale.head())

#全表描述统计
print(df_sale.describe().round())

#订单号计数
print("订单号计数:",df_sale['订单号'].count())

#商品品类计数
print("商品品类计数:",df_sale['商品品类'].value_counts())

#销售数求和
print("销售数求和:",df_sale['销售数'].sum())

#利润求最大值
print(df_sale['利润'].max())

#利润求最小值
print(df_sale['利润'].min())

#利润求平均值
print(df_sale['利润'].mean())

#利润求四分位数
#四分位数 （Quartile）：将数据分为4等份的3个分割点
#- Q1（25%分位数）：第1个四分位数，有25%的数据小于或等于此值
#- Q2（50%分位数）：第2个四分位数，即中位数，有50%的数据小于或等于此值
#- Q3（75%分位数）：第3个四分位数，有75%的数据小于或等于此值
print("利润四分位数:",df_sale['利润'].quantile([0.25,0.5,0.75]))
#销售额求众数
print("销售额众数:",df_sale['销售额'].mode())

#销售额求方差
print("销售额方差:",df_sale['销售额'].var())

#销售额求标准差
print("销售额标准差:",df_sale['销售额'].std())

#相关系数
print(df_sale.corr(numeric_only=True))

print("实际售价与利润的相关系数:",df_sale['实际售价'].corr(df_sale['利润']))

#利润求最大值
print(df_sale['利润'].max())
#利润求最小值
print(df_sale['利润'].min())
#利润求平均值
print(df_sale['利润'].mean())

#利润自动分组
profit_qcut=pd.qcut(df_sale['利润'],10)
print("利润自动分组:\n",profit_qcut)
#利润自动分组计数
print("利润自动分组计数:\n",profit_qcut.value_counts())

df_sale['qcut分组']=profit_qcut
print(df_sale.head(10))

#手动分组
profit_cut=pd.cut(df_sale['利润'],bins=[-300000,-200000,-100000,0,100000,200000,300000,400000,500000,600000,700000,800000,900000])
df_sale['cut分组']=profit_cut
print(df_sale.head(10))

#各商品品类订单号计数
print("各商品品类订单号计数:\n",df_sale.groupby('商品品类')['订单号'].count())

#各商品品类订单号计数,降序排列
print("各商品品类订单号计数,降序排列:\n",df_sale.groupby('商品品类')['订单号'].count().reset_index().sort_values('订单号',ascending=False))


#各区域不同商品类别订单数
print("各区域不同商品类别订单数:\n",df_sale.groupby(['区域','商品品类'])['订单号'].count().reset_index())

#各产品销售额求和
print("各产品销售额求和:\n",df_sale.groupby('商品品类')['销售额'].sum().reset_index())

#各区域订单数计数
print("各区域订单数计数:\n",df_sale.groupby('区域')['订单号'].count().reset_index())


print("各区域销售额统计:\n",df_sale.groupby(['区域'])['销售额'].agg(['sum','mean','max','min','std']).reset_index())

# 多列聚合

print("各客户性别不同商品品类订单数计数,销售额求和,利润平均值,利润总和:\n",df_sale.groupby(['客户性别','商品品类']).agg({
    '订单号': 'count',
    '销售额': ['sum','max','min'],
    '利润': ['mean','sum']
}).reset_index())
