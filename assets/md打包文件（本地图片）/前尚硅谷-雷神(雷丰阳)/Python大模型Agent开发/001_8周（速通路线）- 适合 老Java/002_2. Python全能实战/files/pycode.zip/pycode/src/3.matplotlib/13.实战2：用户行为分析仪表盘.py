import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# 数据加载
df_orders = pd.read_csv('docs/data/用户下单数据.csv', encoding='gbk')
df_orders['下单时间'] = pd.to_datetime(df_orders['下单时间'])
df_orders['用户出生日期'] = pd.to_datetime(df_orders['用户出生日期'])
df_orders['年龄'] = 2024 - df_orders['用户出生日期'].dt.year
df_orders['下单小时'] = df_orders['下单时间'].dt.hour
df_orders['下单月份'] = df_orders['下单时间'].dt.month

# 设置样式
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

fig, axes = plt.subplots(2, 3, figsize=(18, 10))
fig.suptitle('用户下单行为分析仪表盘', fontsize=18, fontweight='bold', y=0.995)

# ========== 子图1：每小时下单量分布 ==========
hourly_orders = df_orders.groupby('下单小时').size()
axes[0, 0].bar(hourly_orders.index, hourly_orders.values, 
               color='steelblue', alpha=0.8, edgecolor='black')
axes[0, 0].set_xlabel('小时', fontsize=11)
axes[0, 0].set_ylabel('订单数', fontsize=11)
axes[0, 0].set_title('24小时下单量分布', fontsize=13, fontweight='bold')
axes[0, 0].grid(axis='y', alpha=0.3)
axes[0, 0].set_xticks(range(0, 24, 2))

# 标注高峰时段
max_hour = hourly_orders.idxmax()
max_count = hourly_orders.max()
axes[0, 0].annotate(f'高峰: {max_hour}时\n{max_count}单',
                    xy=(max_hour, max_count),
                    xytext=(max_hour, max_count * 1.1),
                    ha='center',
                    fontsize=10,
                    fontweight='bold',
                    color='red',
                    arrowprops=dict(arrowstyle='->', color='red', lw=1.5))

# ========== 子图2：月度交易金额趋势 ==========
monthly_amount = df_orders.groupby('下单月份')['交易金额'].sum()
axes[0, 1].plot(monthly_amount.index, monthly_amount.values, 
                marker='o', linewidth=2.5, markersize=8, color='#E74C3C')
axes[0, 1].fill_between(monthly_amount.index, monthly_amount.values, 
                         alpha=0.3, color='#E74C3C')
axes[0, 1].set_xlabel('月份', fontsize=11)
axes[0, 1].set_ylabel('交易金额（元）', fontsize=11)
axes[0, 1].set_title('月度交易金额趋势', fontsize=13, fontweight='bold')
axes[0, 1].grid(True, alpha=0.3)
axes[0, 1].set_xticks(range(1, 13))

# ========== 子图3：性别×婚姻状况交易对比 ==========
gender_marriage = df_orders.groupby(['性别', '婚姻状况'])['交易金额'].mean().unstack()
x = np.arange(len(gender_marriage.index))
width = 0.35
bars1 = axes[0, 2].bar(x - width/2, gender_marriage['已婚'], 
                       width, label='已婚', color='#27AE60', alpha=0.85)
bars2 = axes[0, 2].bar(x + width/2, gender_marriage['未婚'], 
                       width, label='未婚', color='#F39C12', alpha=0.85)
axes[0, 2].set_xticks(x)
axes[0, 2].set_xticklabels(gender_marriage.index)
axes[0, 2].set_ylabel('平均交易金额（元）', fontsize=11)
axes[0, 2].set_title('性别×婚姻状况平均交易额', fontsize=13, fontweight='bold')
axes[0, 2].legend(fontsize=10)
axes[0, 2].grid(axis='y', alpha=0.3)

# ========== 子图4：年龄段交易分布 ==========
df_orders['年龄段'] = pd.cut(df_orders['年龄'], 
                            bins=[0, 30, 40, 50, 100], 
                            labels=['30岁以下', '30-40岁', '40-50岁', '50岁以上'])
age_group_stats = df_orders.groupby('年龄段',observed=False).agg({
    '交易金额': ['mean', 'count']
}).reset_index()
age_group_stats.columns = ['年龄段', '平均交易额', '订单数']

ax4_twin = axes[1, 0].twinx()
color1 = '#3498DB'
bars = axes[1, 0].bar(range(len(age_group_stats)), age_group_stats['平均交易额'],
                      color=color1, alpha=0.7, label='平均交易额')
axes[1, 0].set_ylabel('平均交易额（元）', color=color1, fontsize=11, fontweight='bold')
axes[1, 0].tick_params(axis='y', labelcolor=color1)

color2 = '#E74C3C'
line = ax4_twin.plot(range(len(age_group_stats)), age_group_stats['订单数'],
                     color=color2, marker='o', linewidth=2.5, markersize=8, label='订单数')
ax4_twin.set_ylabel('订单数', color=color2, fontsize=11, fontweight='bold')
ax4_twin.tick_params(axis='y', labelcolor=color2)

axes[1, 0].set_xticks(range(len(age_group_stats)))
axes[1, 0].set_xticklabels(age_group_stats['年龄段'], rotation=30, ha='right')
axes[1, 0].set_title('年龄段交易分析', fontsize=13, fontweight='bold')
axes[1, 0].grid(axis='y', alpha=0.3)

# ========== 子图5：学历交易金额箱线图 ==========
education_levels = ['大专', '本科', '硕士', '博士']
education_data = [df_orders[df_orders['文化程度'] == edu]['交易金额'].values 
                  for edu in education_levels]
bp = axes[1, 1].boxplot(education_data, 
                        tick_labels=education_levels,
                        patch_artist=True,
                        showmeans=True,
                        notch=True)
colors_edu = ['#FFE5B4', '#FFD700', '#FFA500', '#FF6347']
for patch, color in zip(bp['boxes'], colors_edu):
    patch.set_facecolor(color)
    patch.set_alpha(0.7)
axes[1, 1].set_ylabel('交易金额（元）', fontsize=11)
axes[1, 1].set_title('不同学历交易金额分布', fontsize=13, fontweight='bold')
axes[1, 1].grid(axis='y', alpha=0.3)

# ========== 子图6：交易金额散点图（年龄 vs 交易金额） ==========
sample_data = df_orders.sample(n=min(1000, len(df_orders)), random_state=42)
scatter = axes[1, 2].scatter(sample_data['年龄'], sample_data['交易金额'],
                             c=sample_data['交易金额'], 
                             s=50, 
                             cmap='viridis', 
                             alpha=0.6,
                             edgecolors='black',
                             linewidth=0.5)
axes[1, 2].set_xlabel('年龄', fontsize=11)
axes[1, 2].set_ylabel('交易金额（元）', fontsize=11)
axes[1, 2].set_title('年龄与交易金额关系', fontsize=13, fontweight='bold')
axes[1, 2].grid(True, alpha=0.3)

# 添加趋势线
z = np.polyfit(sample_data['年龄'], sample_data['交易金额'], 1)
p = np.poly1d(z)
axes[1, 2].plot(sample_data['年龄'].sort_values(), 
                p(sample_data['年龄'].sort_values()),
                "r--", linewidth=2, alpha=0.8, label='趋势线')
axes[1, 2].legend(fontsize=9)

plt.tight_layout()
plt.savefig('用户行为分析仪表盘.png', dpi=300, bbox_inches='tight')
plt.show()

print("✅ 用户行为分析仪表盘生成完成！")