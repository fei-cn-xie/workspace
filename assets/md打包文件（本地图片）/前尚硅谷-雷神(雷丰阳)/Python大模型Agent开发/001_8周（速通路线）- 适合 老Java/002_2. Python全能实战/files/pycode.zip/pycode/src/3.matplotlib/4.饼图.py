import data.sales_data as sd
import matplotlib.pyplot as plt

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 黑体或微软雅黑
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 导入数据
df_sales, df_orders = sd.load_data()

category_sales = df_sales.groupby('商品品类')['销售额'].sum().sort_values(ascending=False)
print(category_sales)

def plot01():
    fig,ax = plt.subplots(figsize=(12, 6))

    # wedges: 饼图的扇形对象
    # texts: 标签对象
    # autotexts: 自动百分比标签对象
    explode = [0.05 if i == 0 else 0 for i in range(len(category_sales))]
    wedges, texts, autotexts = ax.pie(category_sales.values,
        labels=category_sales.index,
        autopct='%1.1f%%',
        startangle=90,
        explode=explode)
        # 突出最大块

    for t in texts:
        t.set_fontsize(12)

    for at in autotexts:
        at.set_fontsize(11)
        at.set_color('white')

    wedges[0].set_edgecolor('black')
    wedges[0].set_linewidth(5)

    ax.set_title('商品品类销售额占比', fontsize=16, fontweight='bold', pad=20)
    plt.tight_layout()
    plt.show()



def plot02():
    fig,ax = plt.subplots(figsize=(12, 6))
    ax.pie(category_sales.values,
        labels=category_sales.index,
        autopct='%1.1f%%',
        pctdistance=0.9,
        startangle=90,
        wedgeprops=dict(width=0.3, edgecolor='white', linewidth=2))
    
    ax.set_title('商品品类销售额占比', fontsize=16, fontweight='bold', pad=20)
    ax.text(0, 0, f'总销售额\n¥{category_sales.sum():,.0f}', 
            ha='center', va='center', fontsize=14, fontweight='bold')
    plt.tight_layout()
    plt.show()

plot02()