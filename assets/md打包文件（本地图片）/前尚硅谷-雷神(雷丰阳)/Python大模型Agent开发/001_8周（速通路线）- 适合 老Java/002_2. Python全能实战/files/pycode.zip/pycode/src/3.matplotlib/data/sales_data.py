import pandas as pd

def load_data():
    # 加载电商销售数据
    df_sales = pd.read_excel('docs/data/电商销售数据.xlsx')
    # 数据预处理
    df_sales['日期'] = pd.to_datetime(df_sales['日期'])
    df_sales['进货价格'] = df_sales['进货价格'].str.replace('¥', '').astype(float)
    df_sales['实际售价'] = df_sales['实际售价'].astype(float)

    # 加载用户下单数据
    df_orders = pd.read_csv('docs/data/用户下单数据.csv', encoding='gbk')
    df_orders['下单时间'] = pd.to_datetime(df_orders['下单时间'])
    df_orders['用户出生日期'] = pd.to_datetime(df_orders['用户出生日期'])

    return df_sales, df_orders
