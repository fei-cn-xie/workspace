import data.sales_data as sd
import matplotlib.pyplot as plt

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 黑体或微软雅黑
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 导入数据
df_sales, df_orders = sd.load_data()


def plot01():
    age_sales = df_sales.groupby('客户年龄').agg({
        '销售额': 'sum',
        '订单号': 'count'
    }).reset_index()

    age_sales.columns = ['客户年龄', '销售额', '订单数']

    print(age_sales)

    fig,ax = plt.subplots(figsize=(12, 6))
    scatter = ax.scatter(age_sales['客户年龄'], 
        age_sales['销售额'], 
        c=age_sales['订单数'],
        alpha=0.5)

    ax.set_title('客户年龄与销售额的关系', fontsize=16, fontweight='bold', pad=20)
    ax.set_xlabel('客户年龄', fontsize=12)
    ax.set_ylabel('销售额', fontsize=12)

    cbar = plt.colorbar(scatter,ax=ax)
    cbar.set_label('订单数', fontsize=12)

    plt.tight_layout()
    plt.show()


def plot02():
    age_sales = df_sales.groupby('客户年龄').agg({
        '销售额': 'sum',
        '订单号': 'count'
    }).reset_index()

    age_sales.columns = ['客户年龄', '销售额', '订单数']

    age_sales.loc[3,'订单数'] = 87
    age_sales.loc[9,'订单数'] = 12
    age_sales.loc[35,'订单数'] = 261
    print(age_sales)

    fig,ax = plt.subplots(figsize=(12, 6))
    scatter = ax.scatter(age_sales['客户年龄'], 
        age_sales['销售额'], 
        s=age_sales['订单数']*3,
        alpha=0.5)

    ax.set_title('客户年龄与销售额的关系', fontsize=16, fontweight='bold', pad=20)
    ax.set_xlabel('客户年龄', fontsize=12)
    ax.set_ylabel('销售额', fontsize=12)


    plt.tight_layout()
    plt.show()

import pandas as pd
def plot03():
    # 准备数据
    df_sales['年龄段'] = pd.cut(df_sales['客户年龄'], 
        bins=[0, 18, 30, 45, 60, 100],
        labels=['18岁以下','18-30岁','30-45岁','45-60岁','60岁以上'])
   
    age_sales = df_sales.pivot_table(
        index=['年龄段','客户性别'],
        values=['销售额','订单号'],
        aggfunc={
            '销售额': 'mean',
            '订单号': 'count'
        },
        observed=False
    ).reset_index()
    age_sales.columns = ['年龄段','客户性别','订单数','销售额']

    
    fig,ax = plt.subplots(figsize=(12, 6))

    # 绘制男性气泡图
    male_data = age_sales[age_sales['客户性别']== '男']
    print(male_data)
    ax.scatter(x = male_data['年龄段'],
               y = male_data['销售额'],
               s = male_data['订单数'],
               c = 'blue',
               label='男性',
               alpha=0.5)

    # 绘制女性气泡图
    female_data = age_sales[age_sales['客户性别']== '女']
    ax.scatter(x = female_data['年龄段'],
               y = female_data['销售额'],
               s = female_data['订单数'],
               c = 'red',
               label='女性',
               alpha=0.5)
    
    # 添加图例
    ax.legend(fontsize=12)
    ax.set_title('客户年龄与销售额的关系(气泡大小代表订单数量)', fontsize=16, fontweight='bold', pad=20)
    ax.set_xlabel('客户年龄', fontsize=12)
    ax.set_ylabel('平均销售额', fontsize=12)

    plt.tight_layout()
    plt.show()

plot03()