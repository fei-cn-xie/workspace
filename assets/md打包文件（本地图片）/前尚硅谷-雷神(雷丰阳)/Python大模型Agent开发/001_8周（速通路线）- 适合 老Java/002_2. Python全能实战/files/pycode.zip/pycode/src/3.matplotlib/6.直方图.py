import data.sales_data as sd
import matplotlib.pyplot as plt

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 黑体或微软雅黑
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 导入数据
df_sales, df_orders = sd.load_data()

def plot01():
    fig,ax = plt.subplots(figsize=(12, 6))
    print(df_sales['客户年龄'].value_counts().sort_index())
    ax.hist(df_sales['客户年龄'], bins=20,
        edgecolor='black', alpha=0.7, histtype='stepfilled')
    
    ax.set_title('客户年龄分布', fontsize=16, fontweight='bold')
    ax.set_xlabel('年龄', fontsize=12)
    ax.set_ylabel('次数', fontsize=12)
    ax.grid(axis='y', alpha=0.3)

    plt.tight_layout()
    plt.show()


def plot02():
    fig,ax = plt.subplots(figsize=(12, 6))
    print(df_sales)
    male_age = df_sales[df_sales['客户性别']=='男']['客户年龄']
    female_age = df_sales[df_sales['客户性别']=='女']['客户年龄']
    print(male_age)
    print(female_age)

    ax.hist([male_age, female_age], bins=20,
        edgecolor='black', alpha=0.7, histtype='bar',label=['男','女'])
    
    ax.set_title('客户年龄分布', fontsize=16, fontweight='bold')
    ax.set_xlabel('年龄', fontsize=12)
    ax.set_ylabel('次数', fontsize=12)
    ax.grid(axis='y', alpha=0.3)

    ax.legend(fontsize=12)

    plt.tight_layout()
    plt.show()


def plot03():
    fig,ax = plt.subplots(figsize=(12, 6))
    print(df_orders)

    ax.hist(df_orders['交易金额'], bins=20,density=True,range=(200,600),
        edgecolor='black', alpha=0.7, histtype='bar')
    
    ax.set_title('交易金额分布', fontsize=16, fontweight='bold')
    ax.set_xlabel('交易金额', fontsize=12)
    ax.set_ylabel('概率', fontsize=12)
    ax.grid(axis='y', alpha=0.3)

    plt.tight_layout()
    plt.show()

plot03()