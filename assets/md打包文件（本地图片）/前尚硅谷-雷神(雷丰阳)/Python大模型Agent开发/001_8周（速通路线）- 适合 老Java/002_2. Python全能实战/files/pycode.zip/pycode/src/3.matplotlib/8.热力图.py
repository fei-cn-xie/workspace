import data.sales_data as sd
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
from matplotlib.image import imread

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 黑体或微软雅黑
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 导入数据
df_sales, df_orders = sd.load_data()

def plot01():
    df_sales['大区'] = df_sales['区域'].str.split('-', expand=True)[0]
    print(df_sales.head())

    region_category_sales = df_sales.pivot_table(index='商品品类', columns='大区', values='销售额', aggfunc='sum')
    print(region_category_sales)
    # 绘制热力图
    fig,ax = plt.subplots(figsize=(12, 6))

    im = ax.imshow(region_category_sales.values, cmap='YlOrRd',aspect='auto')
    ax.set_yticks(range(len(region_category_sales.index))) # 0-7
    ax.set_yticklabels(region_category_sales.index, fontsize=12) # 商品品类
    ax.set_xticks(range(len(region_category_sales.columns)))
    ax.set_xticklabels(region_category_sales.columns, fontsize=12)

    cbar = plt.colorbar(im, ax = ax)
    cbar.set_label('销售额（万元）', fontsize=12)

    # 添加数据值标注
    for i in range(len(region_category_sales.index)):
        for j in range(len(region_category_sales.columns)):
            ax.text(j, i, f'{region_category_sales.values[i, j]/10000:.2f}', 
                    ha='center', va='center', color='black', fontsize=12)

    ax.set_title('大区-商品品类销售额热力图', fontsize=16, fontweight='bold', pad=20)
    ax.set_xlabel('大区', fontsize=12)
    ax.set_ylabel('商品品类', fontsize=12)

    plt.tight_layout()
    plt.show()
    


def plot02():
    # 准备数据
    corr_matrix = df_sales[['客户年龄', '进货价格', '实际售价', '销售数', '销售额', '利润']].corr()
    print(corr_matrix)
    fig,ax = plt.subplots(figsize=(12, 6))

    im = ax.imshow(corr_matrix.values, cmap='coolwarm',aspect='auto',vmin=-1, vmax=1)
    ax.set_yticks(range(len(corr_matrix.index))) # 0-5
    ax.set_yticklabels(corr_matrix.index, fontsize=12) # 商品品类
    ax.set_xticks(range(len(corr_matrix.columns)))
    ax.set_xticklabels(corr_matrix.columns, fontsize=12)

    ax.set_title('相关系数热力图', fontsize=16, fontweight='bold', pad=20)
    ax.set_xlabel('变量', fontsize=12)
    ax.set_ylabel('变量', fontsize=12)

    # 添加数据值标注
    for i in range(len(corr_matrix.index)):
        for j in range(len(corr_matrix.columns)):
            ax.text(j, i, f'{corr_matrix.values[i, j]:.2f}', 
                    ha='center', va='center', color='white' if abs(corr_matrix.values[i, j]) > 0.5 else 'black', fontsize=12)

    cbar = plt.colorbar(im, ax = ax)
    cbar.set_label('相关系数', fontsize=12)

    plt.tight_layout()
    plt.show()

    
def plot03():
    # 测试展示图像
    image_path = cbook.get_sample_data('grace_hopper.jpg')
    print(f"尝试加载图像: {image_path}")
    image = imread(image_path)
    print(f"成功加载图像，形状: {image.shape}")
    plt.imshow(image)
    # plt.axis('off')
    plt.show()
plot03()