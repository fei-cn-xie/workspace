# 初始环境
```shell
conda create -n py310 python=3.10
conda activate py310
pip install -r requirements.txt
```