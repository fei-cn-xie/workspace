import numpy as np
arr = np.array([10, 20, 30, 40, 50])

# 正向索引（从0开始）
print(arr[0])
# 10
print(arr[2])   # 30
 # 负向索引（从-1开始，表示最后一个）
print(arr[-1])   # 50
print(arr[-2])   # 40

arr = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])

# 基本切片 [start:stop:step]
arr2 = arr[2:7]
print(arr2)      # [2 3 4 5 6]  从索引2到6
print(arr[:5])       # [0 1 2 3 4]  从开头到索引4
print(arr[5:])       # [5 6 7 8 9]  从索引5到结尾
print(arr[::2])      # [0 2 4 6 8]  每隔2个取一个
print(arr[::-1])     # [9 8 7 6 5 4 3 2 1 0]  反转数组
print("===========")

# 原数组基本属性
print("数组的维度数:",arr.ndim)  # 1 - 一维数组
print("数组的形状:",arr.shape)  # (10,) - 10个元素
print("数组的元素总数:",arr.size)       # 10 - 共10个元素
print("数组的数据类型:",arr.dtype)      # int64 (或 int32)
print("数组每个元素的字节数:",arr.itemsize)   # 8 (64位整数占8字节)
print("数组的步长:",arr.strides)    # (8,) - 每个元素 8 字节
print("数组的数据起始内存地址:",arr.data)

print("===========")

# arr2 基本属性
print("数组的维度数:",arr2.ndim)  # 1 - 一维数组
print("数组的形状:",arr2.shape)  # (5,) - 5个元素
print("数组的元素总数:",arr2.size)       # 5 - 共5个元素
print("数组的数据类型:",arr2.dtype)      # int64 (或 int32)
print("数组每个元素的字节数:",arr2.itemsize)   # 8 (64位整数占8字节)
print("数组的步长:",arr2.strides)    # (8,) - 每个元素 8 字节
print("数组的数据起始内存地址:",arr2.data)


arr = np.array([[1, 2, 3],
                [4, 5, 6],
                [7, 8, 9]])

# 单个元素 [行, 列]
print(arr[0, 0])     # 1  (第0行第0列)
print(arr[1, 2])     # 6  (第1行第2列)
print(arr[-1, -1])   # 9  (最后一行最后一列)

# 整行
print(arr[1])        # [4 5 6]  第1行
print(arr[1, :])     # [4 5 6]  同上

# 整列
print(arr[:, 1])     # [2 5 8]  第1列

# 子矩阵
print(arr[0:2, 1:3])

arr = np.array([10, 20, 30, 40, 50])

# 花式索引（使用数组作为索引）
indices = [0, 2, 4]
print("花式索引结果:",arr[indices])  # [10 30 50]

# 布尔索引
mask = arr > 25
print("布尔索引结果:",mask)          # [False False  True  True  True]
print("布尔索引筛选结果:",arr[mask])     # [30 40 50]

# 条件筛选
print(arr[arr > 25])  # [30 40 50]
print(arr[(arr > 15) & (arr < 45)])  # [20 30 40]