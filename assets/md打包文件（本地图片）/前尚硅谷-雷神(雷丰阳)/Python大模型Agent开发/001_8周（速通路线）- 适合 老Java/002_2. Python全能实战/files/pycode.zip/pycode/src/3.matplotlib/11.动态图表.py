from numpy import mean
import data.sales_data as sd
import matplotlib.pyplot as plt

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 黑体或微软雅黑
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
# 导入数据
df_sales, df_orders = sd.load_data()
# 数据准备
daily_sales = df_sales.groupby('日期')['销售额'].sum().reset_index()

fig, ax = plt.subplots(figsize=(14, 6))


# 绘制折线
ax.plot(daily_sales['日期'], daily_sales['销售额'], 
        color='steelblue', linewidth=2.5, label='销售额')

# 标注最高点

max_sales_idx = daily_sales['销售额'].idxmax()
print(max_sales_idx)
max_sales_date = daily_sales.loc[max_sales_idx,'日期']
max_sales_value = daily_sales.loc[max_sales_idx,'销售额']
ax.scatter([max_sales_date],[max_sales_value],s=200,c='red',label='最高销售额')

# 添加箭头注释
ax.annotate(f'最高销售额：\n¥{max_sales_value:,.0f}',
            xy=(max_sales_date, max_sales_value),
            xytext=(max_sales_date, max_sales_value * 1.15),
            fontsize=12,
            fontweight='bold',
            color='red',
            ha='center',
            arrowprops=dict(arrowstyle='->', color='blue', lw=2))

# 添加水平参考线
mean_sales = daily_sales['销售额'].mean()
ax.axhline(mean_sales, color='green', linestyle='--', linewidth=1.5,
     label=f'平均销售额：¥{mean_sales:,.0f}')

# 添加文本框
ax.text(0.05, 0.95, f'总销售额：¥{daily_sales["销售额"].sum():,.0f} \n 平均销售额：¥{mean_sales:,.0f}',
        transform=ax.transAxes, 
        fontsize=12, fontweight='bold', color='darkblue',
        ha='left',
        va='top',
        bbox=dict(facecolor='wheat', alpha=0.8, edgecolor='black'))

ax.set_title('销售额趋势分析（带注释）', fontsize=16, fontweight='bold')
ax.set_xlabel('日期', fontsize=12)
ax.set_ylabel('销售额（元）', fontsize=12)
ax.legend(loc='upper right', fontsize=10)
ax.grid(True, alpha=0.3)

# 保存为不同格式
plt.savefig('out/sales_trend.png', dpi=300, bbox_inches='tight')  # 高清PNG
plt.savefig('out/sales_trend.pdf', bbox_inches='tight')  # 矢量PDF
plt.savefig('out/sales_trend.svg', bbox_inches='tight')  # 矢量SVG
plt.savefig('out/sales_trend.jpg', dpi=300, bbox_inches='tight')  # JPEG
plt.tight_layout()
plt.show()




