from pandas.core.generic import clean_reindex_fill_method
import data.sales_data as sd
import matplotlib.pyplot as plt

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 黑体或微软雅黑
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 导入数据
df_sales, df_orders = sd.load_data()

def plot01():
    # 数据准备
    categories = df_sales['商品品类'].unique()
    salenum_by_category = [df_sales[df_sales['商品品类'] == c]['销售数'].values for c in categories]
    
    fig, ax = plt.subplots(figsize=(12, 6))
    bx = ax.boxplot(salenum_by_category, labels=categories,
        notch=True, patch_artist=True, showmeans=True, showfliers=True, vert=True)
    
    # 设置颜色
    colors = plt.cm.Set3(range(len(categories)))
    for box, clr in zip(bx['boxes'], colors):
        box.set_facecolor(clr)
    
    # 设置标题和标签
    ax.set_title('商品品类销售数量分布（箱线图）', fontsize=16, fontweight='bold', pad=20)
    ax.set_xlabel('销售数量', fontsize=12)
    ax.set_ylabel('商品品类', fontsize=12)
    
    # 添加网格线
    ax.grid(axis='y', alpha=0.3)
    
    # 调整布局并显示
    plt.tight_layout()
    plt.show()




# 绘制箱线图
# plot01()

def plot02():
    
    categorys = df_orders['文化程度'].unique()
   
    trade_by_edu = [df_orders[df_orders['文化程度'] == edu]['交易金额'].values for edu in categorys]
    print(trade_by_edu)

    fig, ax = plt.subplots(figsize=(12, 6))
    violinax = ax.violinplot(trade_by_edu, showmeans=True, showmedians=True)
    box = ax.boxplot(trade_by_edu, patch_artist=True, 
        vert=True,showmeans=True, showfliers=True,notch=False,
        widths=0.2,medianprops={'color':'gray'},whiskerprops={'color':'red'})

    print(box.keys())
    print(violinax.keys())
    violinax['cmeans'].set_color('red')
    violinax['cmedians'].set_color('blue')
    colors = plt.cm.Set3(range(len(categorys)))
    for vl,bx, clr in zip(violinax['bodies'],box['boxes'],colors):
        vl.set_facecolor(clr)
        vl.set_edgecolor('black')
        vl.set_linewidth(1.5)
        vl.set_alpha(1)
        bx.set_facecolor('white')
        bx.set_alpha(0.5)

    # 设置标题和标签
    ax.set_title('文化程度交易金额分布（小提琴图）', fontsize=16, fontweight='bold', pad=20)
    ax.set_xlabel('文化程度', fontsize=12)
    ax.set_ylabel('交易金额', fontsize=12)
    # 设置x轴刻度
    ax.set_xticks(range(1, len(categorys) + 1))
    ax.set_xticklabels(categorys, fontsize=12)

    plt.tight_layout()
    plt.show()

    

plot02()