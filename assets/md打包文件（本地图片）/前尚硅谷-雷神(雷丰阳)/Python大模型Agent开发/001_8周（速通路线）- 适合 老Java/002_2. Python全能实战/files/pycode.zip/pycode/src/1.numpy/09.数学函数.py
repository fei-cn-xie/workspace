import numpy as np

arr = np.array([1, 4, 9, 16, 25])

# 平方根
print("平方根:",np.sqrt(arr))    # [1. 2. 3. 4. 5.]

# 指数  e^arr = x
print("指数:",np.exp(arr))     # [2.718... 54.598... ...]

# 对数  log e ? x = 1
print("自然对数:",np.log(arr))     # [0. 1.386... 2.197... ...]
# 常用对数  log 10 ? x = 1
print("常用对数:",np.log10(arr))   # [0. 0.602... 0.954... ...]

# 绝对值
print("绝对值:",np.abs([-1, -2, 3]))  # [1 2 3]

# 取整
arr2 = np.array([1.2, 2.5, 3.7])
print("向下取整:",np.floor(arr2))  # [1. 2. 3.]  向下取整
print("向上取整:",np.ceil(arr2))   # [2. 3. 4.]  向上取整
print("四舍五入:",np.round(arr2))  # [1. 2. 4.]  四舍五入   

print("="*30)
angles = np.array([0, np.pi/6, np.pi/4, np.pi/3, np.pi/2])

print(np.sin(angles))  # [0. 0.5 0.707... 0.866... 1.]
print(np.cos(angles))  # [1. 0.866... 0.707... 0.5 0.]
print(np.tan(angles))  # [0. 0.577... 1. 1.732... 很大的数]

# 角度与弧度转换
degrees = np.array([0, 30, 45, 60, 90])
radians = np.deg2rad(degrees)
print(radians)  # [0. 0.524... 0.785... 1.047... 1.571...]

print("="*30)

arr = np.array([[1, 2, 3],
                [4, 5, 6]])

# 求和
print("所有元素求和:",np.sum(arr))        # 21 (所有元素)       

print("每列求和:",np.sum(arr, axis=0))  # [5 7 9] (每列求和)
print("每行求和:",np.sum(arr, axis=1))  # [6 15] (每行求和)

# 平均值
print("数组平均值:",np.mean(arr))       # 3.5

# 最大/最小值
print("数组最大值:",np.max(arr))        # 6
print("数组最小值:",np.min(arr))        # 1
print("数组最大值索引:",np.argmax(arr))     # 5 (最大值的索引)
print("数组最小值索引:",np.argmin(arr))     # 0 (最小值的索引)

# 累积和
print("数组累积和:",np.cumsum(arr))     # [1 3 6 10 15 21]

# 乘积
print(np.prod(arr))       # 720 (1*2*3*4*5*6)

x = np.array([1, 2, 3, 4, 5])
y = np.array([2, 4, 5, 4, 5])
