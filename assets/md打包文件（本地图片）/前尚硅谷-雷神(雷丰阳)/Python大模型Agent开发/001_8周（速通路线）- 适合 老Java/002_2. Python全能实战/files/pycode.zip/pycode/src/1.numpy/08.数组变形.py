import numpy as np
## 1. reshape - 改变形状

arr = np.arange(1,13)  # [1 2 3 4 5 6 7 8 9 10 11, 12]

# 变形为 3x4 矩阵
arr_2d = arr.reshape(3, 4)
print(arr_2d)


# 变形为 2x2x3 三维数组
arr_3d = arr.reshape(2, 2, 3)
print(arr_3d)

# 使用 -1 自动计算维度
arr_auto = arr.reshape(4, -1)  # 4行，列数自动计算
print(arr_auto)  # (4, 3)


# print(arr.reshape(5,-1))

# 行优先
arr_row = arr.reshape(4, 3, order='C')
print("行优先:",arr_row)
# 列优先
arr_col = arr.reshape(4, 3, order='F')
print("列优先:",arr_col)

## 2.  其他变形操作
print("="*30)
# 创建二维数组
arr = np.array([[1, 2, 3],
[4, 5, 6]])

# 使用 flatten() - 返回副本
flat = arr.flatten()
print("flatten:",flat)

# 使用 ravel() - 返回视图
ravelled = arr.ravel()
print("ravel:",ravelled)

# 测试修改
flat[0] = 99
print("原数组:", arr[0, 0]) # 1（未改变）

ravelled[0] = 99
print("原数组:", arr[0, 0]) # 99（已改变）


# transpose / T - 转置
arr = np.array([[1, 2, 3],
[4, 5, 6]])
transposed = arr.T
print("转置:",transposed)
# [[1 4]
#  [2 5]
#  [3 6]]

arr_234 = np.array([[[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]],
                     [[13, 14, 15, 16], [17, 18, 19, 20], [21, 22, 23, 24]]])
print("2x3x4 数组形状:", arr_234.shape) # (2, 3, 4)

arr_243 = arr_234.transpose(2, 0, 1)
print("2x4x3 数组形状:", arr_243.shape) # (2, 4, 3)

# swapaxes - 交换轴
swapped = arr.swapaxes(0, 1)  # 等同于转置
print("交换轴:",swapped)
# [[1 4]
#  [2 5]
#  [3 6]]

# expand_dims - 增加维度
expanded = np.expand_dims(arr, axis=0)
print(expanded.shape)  # (1, 2, 3)

expanded2 = np.expand_dims(expanded, axis=3)
print(expanded2.shape)  # (1, 2,3, 1)

# squeeze - 移除大小为1的维度
squeezed = np.squeeze(expanded2)
print(squeezed.shape)  # (2, 3)

## 3.  数组拼接与拆分
# 创建示例数组
a = np.array([[1, 2], [3, 4]]) # shape=(2, 2)
b = np.array([[5, 6], [7, 8]]) # shape=(2, 2)

# 垂直拼接 (vstack)
result_v = np.vstack([a, b])
print("垂直拼接结果:")
print(result_v)
# [[1 2]
# [3 4]
# [5 6]
# [7 8]]

# 水平拼接 (hstack)
result_h = np.hstack([a, b])
print("水平拼接结果:")
print(result_h)
# [[1 2 5 6]
# [3 4 7 8]]

# 使用 concatenate
result_v2 = np.concatenate([a, b], axis=0) # 等同于 vstack
result_h2 = np.concatenate([a, b], axis=1) # 等同于 hstack
print("concatenate 垂直拼接结果:", result_v2)
print("concatenate 水平拼接结果:", result_h2)

arr = np.arange(12).reshape(4, 3)
print("原始数组:")
print(arr)

saarr = np.split(arr, 2, axis=0)
print("垂直拆分:",saarr)
# [array([[0, 1, 2],
#        [3, 4, 5]]), 
#  array([[ 6,  7,  8],
#        [ 9, 10, 11]])]