import pandas as pd
# 读取销售数据
df_sales = pd.read_excel('docs/data/电商销售数据.xlsx')

# 分割区域信息
df_sales[['区域', '省份', '城市']] = df_sales['区域'].str.split('-', expand=True)

print(df_sales.head())

#各区域销售额情况
print("分组聚合\n",df_sales.groupby('区域')['销售额'].agg(['sum','mean','max','min']))

pt = pd.pivot_table(df_sales,index=['区域'],values='销售额')
print(pt)

#各区域不同产品销售额情况
print("透视表\n",pd.pivot_table(df_sales,index=['区域','商品品类'],values='销售额',aggfunc='sum'))

#重置索引
print("重置索引\n",pd.pivot_table(df_sales,index=['区域','商品品类'],values='销售额',aggfunc='sum').reset_index())

# 总计
print("总计透视表\n",pd.pivot_table(df_sales,index=['区域','商品品类'],values='销售额',aggfunc='sum',
        margins=True,margins_name='总计').tail())


#各区域不同产品订单数，销售额情况，加总计,缺失值填充为0(长表)
print("长表透视表\n",pd.pivot_table(df_sales,index=['区域','商品品类','客户性别'],
               values=['订单号','销售额'],
               aggfunc={'订单号':'count','销售额':'sum'},
               margins=True,
               margins_name='总计',
               fill_value=0).reset_index().tail(10))

# 传入 columns 参数，可分别对不同性别的用户做数据透视。
pt = pd.pivot_table(df_sales,index=['区域','商品品类'],
 values=['订单号','销售额'],
 aggfunc={'订单号':'count','销售额':'sum'},
 columns=['客户性别'],
 fill_value=0,
 margins=True,
 margins_name='总计')

print(pt)

print(pt.loc[['东北','华北'],'销售额'])
