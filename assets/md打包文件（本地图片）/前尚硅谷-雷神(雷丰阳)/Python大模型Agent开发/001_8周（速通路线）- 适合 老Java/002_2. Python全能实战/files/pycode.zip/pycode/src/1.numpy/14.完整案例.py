import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
from matplotlib.image import imread

# 使用经典图像代替随机生成的图像
# 尝试使用内置的经典图像

# 初始化原始图像变量
original_image = None
image = None

try:
    # 方法1：使用matplotlib内置的sample data中的经典图像
    image_path = cbook.get_sample_data('grace_hopper.jpg')
    print(f"尝试加载图像: {image_path}")
    image = imread(image_path)
    original_image = image.copy()
    print(f"成功加载图像，形状: {image.shape}")
except Exception as e:
    print(f"无法加载grace_hopper.jpg: {e}")

# 如果是彩色图像，转换为灰度图像用于处理
grayscale_image = None
if image.ndim == 3:
    print("将彩色图像转换为灰度图像...")
    # 使用加权平均法转换为灰度图像
    grayscale_image = np.dot(image[...,:3], [0.299, 0.587, 0.114]).astype(np.uint8)
else:
    grayscale_image = image.copy()

# 确保图像是灰度的且数据类型正确
processing_image = grayscale_image.astype(np.uint8)

print(f"处理图像的最终形状: {processing_image.shape}")
print(f"原始图像的最终形状: {original_image.shape}")

# 图像反转
inverted = 255 - processing_image

# 图像二值化
threshold = 128
binary = (processing_image > threshold).astype(np.uint8) * 255

# 图像亮度调整
brighter = np.clip(processing_image + 50, 0, 255).astype(np.uint8)

# 简单的均值滤波（模糊）
def mean_filter(img, kernel_size=3):
    pad = kernel_size // 2
    padded = np.pad(img, pad, mode='edge')
    result = np.zeros_like(img, dtype=float)
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            result[i, j] = padded[i:i+kernel_size, j:j+kernel_size].mean()
    return result.astype(np.uint8)

# 添加更丰富的图像处理效果
# 锐化滤镜
def sharpen_filter(img):
    # 锐化卷积核
    kernel = np.array([[-1, -1, -1],
                      [-1,  9, -1],
                      [-1, -1, -1]])
    
    pad = kernel.shape[0] // 2
    padded = np.pad(img, pad, mode='edge')
    result = np.zeros_like(img, dtype=float)
    
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            result[i, j] = np.sum(padded[i:i+kernel.shape[0], j:j+kernel.shape[1]] * kernel)
    
    # 确保值在0-255范围内
    result = np.clip(result, 0, 255)
    return result.astype(np.uint8)

# 边缘检测（Sobel算子）
def edge_detection(img):
    # Sobel X方向卷积核（水平边缘）
    sobel_x = np.array([[-1, 0, 1],
                       [-2, 0, 2],
                       [-1, 0, 1]])
    
    # Sobel Y方向卷积核（垂直边缘）
    sobel_y = np.array([[-1, -2, -1],
                       [0, 0, 0],
                       [1, 2, 1]])
    
    pad = 1
    padded = np.pad(img, pad, mode='edge')
    
    grad_x = np.zeros_like(img, dtype=float)
    grad_y = np.zeros_like(img, dtype=float)
    
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            grad_x[i, j] = np.sum(padded[i:i+3, j:j+3] * sobel_x)
            grad_y[i, j] = np.sum(padded[i:i+3, j:j+3] * sobel_y)
    
    # 计算梯度幅度
    gradient = np.sqrt(grad_x**2 + grad_y**2)
    # 归一化到0-255
    gradient = (gradient / gradient.max() * 255).astype(np.uint8)
    
    return gradient

# 应用新的滤镜效果
sharpened = sharpen_filter(processing_image)
edges = edge_detection(processing_image)

# 可视化同时展示以上图像
# 调整布局，添加原始图像显示
plt.figure(figsize=(18, 12))

# 原始图像（彩色）
plt.subplot(3, 4, 1)
plt.imshow(original_image)
plt.title('Original Image (Color)')
plt.axis('off')

# 转换后的灰度图像
plt.subplot(3, 4, 2)
plt.imshow(grayscale_image, cmap='gray')
plt.title('Grayscale Image')
plt.axis('off')

# 反转图像
plt.subplot(3, 4, 3)
plt.imshow(inverted, cmap='gray')
plt.title('Inverted Image')
plt.axis('off')

# 二值化图像
plt.subplot(3, 4, 4)
plt.imshow(binary, cmap='gray')
plt.title('Binary Image')
plt.axis('off')

# 亮度调整
plt.subplot(3, 4, 5)
plt.imshow(brighter, cmap='gray')
plt.title('Brighter Image')
plt.axis('off')

# 均值滤波（模糊）
plt.subplot(3, 4, 6)
plt.imshow(mean_filter(processing_image), cmap='gray')
plt.title('Mean Filter (Blur)')
plt.axis('off')

# 锐化滤镜
plt.subplot(3, 4, 7)
plt.imshow(sharpened, cmap='gray')
plt.title('Sharpen Filter')
plt.axis('off')

# 边缘检测
plt.subplot(3, 4, 8)
plt.imshow(edges, cmap='gray')
plt.title('Edge Detection (Sobel)')
plt.axis('off')

# 展示图像信息
plt.subplot(3, 4, 9)
plt.axis('off')
image_info = f"Image Info:\n"
image_info += f"Original Shape: {original_image.shape}\n"
image_info += f"Grayscale Shape: {grayscale_image.shape}\n"
image_info += f"Dtype: {original_image.dtype}\n"
image_info += f"Min: {processing_image.min()}, Max: {processing_image.max()}"
plt.text(0.1, 0.5, image_info, fontsize=12, verticalalignment='center')

plt.tight_layout()
plt.savefig('image_processing_results.png', dpi=150, bbox_inches='tight')  # 保存结果
plt.show()

# 打印一些图像统计信息
print("\n图像基本信息:")
print(f"原始图像形状: {original_image.shape}")
print(f"灰度图像形状: {grayscale_image.shape}")
print(f"数据类型: {original_image.dtype}")
print(f"像素值范围: [{processing_image.min()}, {processing_image.max()}]")
print(f"图像大小: {processing_image.shape[0] * processing_image.shape[1]} 像素")

# 演示如何访问和修改特定像素
print("\n像素操作演示:")
# 获取图像中心像素值
center_y, center_x = processing_image.shape[0] // 2, processing_image.shape[1] // 2
print(f"中心像素值: {processing_image[center_y, center_x]}")

# 修改中心区域的像素值（创建一个白色方块）
modified_image = processing_image.copy()
block_size = min(20, min(processing_image.shape) // 4)  # 确保方块不会超出图像范围
modified_image[center_y-block_size:center_y+block_size, 
               center_x-block_size:center_x+block_size] = 255

# 显示修改后的图像
plt.figure(figsize=(8, 4))

plt.subplot(1, 2, 1)
plt.imshow(processing_image, cmap='gray')
plt.title('Original Processing Image')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(modified_image, cmap='gray')
plt.title('Modified Image (Center Block)')
plt.axis('off')

plt.tight_layout()
plt.show()