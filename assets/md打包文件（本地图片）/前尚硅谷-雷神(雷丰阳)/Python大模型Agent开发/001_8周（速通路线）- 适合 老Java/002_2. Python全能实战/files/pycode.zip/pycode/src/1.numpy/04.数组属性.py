import numpy as np

arr = np.array([[1, 2, 3, 4],
                [5, 6, 7, 8],
                [9, 10, 11, 12]])

# 形状
print("数组的形状:",arr.shape)      # (3, 4) - 3行4列


# 维度数
print("数组的维度数:",arr.ndim)      # 2 - 二维数组


# 元素总数
print("数组的元素总数:",arr.size)       # 12 - 共12个元素


# 数据类型
print("数组的数据类型:",arr.dtype)      # int64 (或 int32)


# 每个元素的字节数
print("数组每个元素的字节数:",arr.itemsize)   # 8 (64位整数占8字节)


#  strides - 每个维度的步长（字节数）
# 第一个维度（行）的步长是 32 字节，因为每个行有 4 个元素，每个元素 8 字节。
# 第二个维度（列）的步长是 8 字节，因为每个元素 8 字节。

print("数组的步长:",arr.strides)    # (32, 8)


# 数组总字节数 
print("数组的总字节数:",arr.nbytes)     # 96 (12个元素 × 8字节)
 

#  data - 数据的起始内存地址  0x0000025BEB5DA9B0
print("数组的数据起始内存地址:",arr.data)
