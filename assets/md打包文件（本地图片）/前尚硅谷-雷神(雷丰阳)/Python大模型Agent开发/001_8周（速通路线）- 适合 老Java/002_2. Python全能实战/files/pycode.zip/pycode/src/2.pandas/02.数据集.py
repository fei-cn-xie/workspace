import pandas as pd

# 从列表创建 Series - 模拟交易金额
amounts = pd.Series([402.77, 545.27, 256.72, 275.55, 1023.50])
print(amounts)

# 使用自定义索引
s2 = pd.Series([402.77, 545.27, 256.72], index=['订单1', '订单2', '订单3'])
print(s2)

# 使用字典创建，键作为索引
s3 = pd.Series({'A': 1, 'B': 2, 'C': 3})
print(s3)

# 指定为整数类型
s4 = pd.Series([1.1, 2.2, 3.3]).astype(int)
print(s4)

# 命名的Series
s5 = pd.Series([1, 2, 3], name='数值数据')
print(s5)


print("=" * 30)
# 创建交易金额 Series
amounts = pd.Series(
    [402.77, 545.27, 256.72, 275.55, 1023.50],
    index=['A', 'B', 'C', 'D', 'E']
)

# 访问元素
print(amounts['A'])      # 402.77
print(amounts.iloc[0])        # 402.77
print(amounts[['A', 'C']])  # 多个元素

# 切片
print(amounts['B':'D'])  # B, C, D
print(amounts[1:4])      # 索引1到3

# 条件筛选 - 找出大额订单（>500元）
print(amounts[amounts > 500])
# B    545.27
# E   1023.50

# 基本运算 - 计算打9折后的价格
print(amounts * 0.9)

# 统计分析
print(f"平均交易额: {amounts.mean():.2f}")
print(f"总交易额: {amounts.sum():.2f}")
print(f"最大交易额: {amounts.max():.2f}")
print(f"最小交易额: {amounts.min():.2f}")

print("=" * 30)


# 创建简化的用户订单数据
data = {
    '用户ID': [6414111, 6516117, 6714112],
    '性别': ['男', '女', '女'],
    '交易金额': [402.77, 545.27, 256.72]
}
df = pd.DataFrame(data)
print(df)

# 外层列表的每个元素是一行数据
data = [
    [6414111, '男', 402.77],
    [6516117, '女', 545.27],
    [6714112, '女', 256.72]
]
df = pd.DataFrame(data,columns=['用户ID', '性别', '交易金额'],index=['订单1', '订单2', '订单3'])
print(df)

import numpy as np
# 创建 3 行 3 列的随机数组
data = np.random.rand(3, 3)
df = pd.DataFrame(data, columns=['列1', '列2', '列3'])
print(df)

data = {
    '用户ID': [6414111, 6516117, 6714112],
    '年龄': [25, 30, 28],
    '交易金额': [402.77, 545.27, 256.72]
}
df = pd.DataFrame(data, 
                  index=['用户A', '用户B', '用户C'])  # 指定数据类型
df = df.astype({'用户ID': 'int32', '年龄': 'int8', '交易金额': 'float32'})
print(df)

# 创建示例数据
df = pd.DataFrame({
    '用户ID': [6414111, 6516117, 6714112, 5311117],
    '性别': ['男', '女', '女', '女'],
    '文化程度': ['本科', '博士', '博士', '大专'],
    '交易金额': [402.77, 545.27, 256.72, 275.55]
})

# 形状
print("数据集形状:", df.shape)      # (4, 4) - 4行4列

# 列名
print("列名:", df.columns)    # Index(['用户ID', '性别', '文化程度', '交易金额'])

# 索引
print("索引:", df.index)      # RangeIndex(start=0, stop=4, step=1)

# 数据类型
print("数据类型:", df.dtypes)
# 用户ID       int64
# 性别        object
# 文化程度     object
# 交易金额    float64

# 基本信息
print("基本信息:")
df.info()

# 统计摘要（只对数值列）
print("统计摘要:")
print(df.describe())
