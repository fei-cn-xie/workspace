import numpy as np

A = np.array([[1, 2, 3],
              [4, 5, 6]])
B = np.array([[7, 8],
              [9, 10],
              [11, 12]])

# 矩阵乘法
C = np.dot(A, B)  # 或 A @ B
print(C)

A = np.array([[1, 2],
              [3, 4]])

# 转置
print("转置:\n", A.T)
# [[1 3]
#  [2 4]]

# 行列式
det = np.linalg.det(A)
print("行列式:", det)  # -2.0

# 逆矩阵
inv = np.linalg.inv(A)
print("逆矩阵:\n", inv)
# [[-2.   1. ]
#  [ 1.5 -0.5]]

# 验证: A × A^(-1) = I
print("验证: A × A^(-1) = I:\n", np.dot(A, inv))
# [[1. 0.]
#  [0. 1.]]

# 特征值和特征向量
eigenvalues, eigenvectors = np.linalg.eig(A)
print("特征值:", eigenvalues)
print("特征向量:\n", eigenvectors)

A = np.array([[2, 1],
              [1, 2]])
# 解线性方程组 Ax = b
b = np.array([5, 7])
x = np.linalg.solve(A, b)
print(x)  # [1. 3.]  即 x=1, y=3


x = np.array([1, 2, 3, 4, 5])
y = np.array([2, 4, 5, 4, 5])

