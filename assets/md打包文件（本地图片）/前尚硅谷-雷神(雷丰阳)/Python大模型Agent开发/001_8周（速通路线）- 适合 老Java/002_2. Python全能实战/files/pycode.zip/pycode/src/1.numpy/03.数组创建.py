import numpy as np

# 1. 从列表创建
# 从 Python 列表创建
arr = np.array([1, 2, 3, 4, 5])
print("从列表创建的数组:",arr)  # [1 2 3 4 5]

# 指定数据类型
arr_float = np.array([1, 2, 3], dtype=float)
print("指定数据类型为float的数组:",arr_float)  # [1. 2. 3.]

arr_int = np.array([1.5, 2.7, 3.9], dtype=int)
print("指定数据类型为int的数组:",arr_int)  # [1 2 3]  (截断小数部分)

# 2. 使用内置函数创建
# zeros - 创建全 0 数组
zeros_1d = np.zeros(5)           # [0. 0. 0. 0. 0.]
print("1维全0数组:",zeros_1d)

zeros_2d = np.zeros((3, 4))      # 3行4列的全0矩阵
print("2维全0数组:",zeros_2d)

zeros_3d = np.zeros((2, 3, 4))    # 2层3行4列的全0矩阵
print("3维全0数组:",zeros_3d)


# ones - 创建全 1 数组
ones_1d = np.ones(5)             # [1. 1. 1. 1. 1.]
print("1维全1数组:",ones_1d)

ones_2d = np.ones((2, 3))        # 2行3列的全1矩阵
print("2维全1数组:",ones_2d)

# full - 创建指定值的数组
full_arr = np.full((2, 3), 7)    # 全是7的2x3矩阵
print("2维全7数组:",full_arr)

# empty - 创建未初始化的数组（速度快，但值随机）
empty_arr = np.empty((2, 2))
print("2维未初始化数组:",empty_arr)

# eye / identity - 创建单位矩阵
identity = np.eye(3)
print("3x3单位矩阵:",identity)

# [[1. 0. 0.]
#  [0. 1. 0.]
#  [0. 0. 1.]]

# 3. 使用范围函数创建
# arange - 类似 Python 的 range； 前闭后开
arr1 = np.arange(10)           # [0 1 2 3 4 5 6 7 8 9]
print("arange(10):",arr1)

arr2 = np.arange(2, 10)        # [2 3 4 5 6 7 8 9]
print("arange(2,10):",arr2)

arr3 = np.arange(2, 10, 2)     # [2 4 6 8]  步长为2
print("arange(2,10,2):",arr3)

arr4 = np.arange(0, 1, 0.1)    # [0.  0.1 0.2 ... 0.9]
print("arange(0,1,0.1):",arr4)

# linspace - 创建等间隔数组
arr5 = np.linspace(0, 10, 5)   # [0.  2.5  5.  7.5 10.]
print("linspace(0,10,5):",arr5)
# 从0到10，均匀分成5个数

# logspace - 创建对数间隔数组
arr6 = np.logspace(0, 2, 5)    # [1. 3.16... 10. 31.6... 100.]
print("logspace(0,2,5):",arr6)
# 从 10^0 到 10^2，均匀分成5个数