import pandas as pd
sale_table=pd.read_excel(r'docs/data/电商销售数据.xlsx',
                       sheet_name='销售数据_清洗')#导入数据处理这个sheet表

print(sale_table.head())

#数据类型
print(sale_table.dtypes)

sale_table['订单号']= sale_table['订单号'].astype(str)
print("订单号的数据类型为:",sale_table['订单号'].dtype)

# to_datetime转换日期类型
sale_table['日期'] = pd.to_datetime(sale_table['日期'])
print("日期的数据类型为:",sale_table['日期'].dtype)

# 提取日期组件
sale_table['年'] = sale_table['日期'].dt.year
sale_table['月'] = sale_table['日期'].dt.month
sale_table['星期'] = sale_table['日期'].dt.dayofweek

print(sale_table.head())

df_split = sale_table['区域'].str.split('-',expand=True)

print(df_split)

sale_table['区域'] = df_split.iloc[:,0]
sale_table['省份'] = df_split.iloc[:,1]
sale_table['城市'] = df_split.iloc[:,2]

print(sale_table.head())

df_group = sale_table.groupby('区域').apply(lambda x: x['商品品类'].unique(),include_groups=False).reset_index()
df_group.columns=['区域','商品品类']
print(df_group)

#1. 缺失值统计
print(sale_table.isnull().sum())

#2. 删除缺失值
df_clean = sale_table.dropna()
print(df_clean)

sale_table = sale_table.fillna({'客户性别':'x','商品品类':'无品类'})
print(sale_table[(sale_table['客户性别']=='x') | (sale_table['商品品类']=='无品类')])


print(sale_table.duplicated().sum())

print(sale_table[sale_table.duplicated()])

sale_table_drop = sale_table.drop_duplicates()
print(sale_table_drop)


print(sale_table.duplicated(subset=['订单号']).sum())
sale_table.drop_duplicates(subset=['订单号'],inplace=True,keep='last')
print(sale_table)