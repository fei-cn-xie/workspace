import data.sales_data as sd
import matplotlib.pyplot as plt

df_sales, df_orders = sd.load_data()

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']  # 黑体或微软雅黑
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题


def plot01():
    # 按区域汇总; 获取 Top10数据
    region_sales = df_sales.groupby('区域')['销售额'].sum().sort_values(ascending=False).head(10)
    print(region_sales)

    # 绘图
    fig,ax = plt.subplots(figsize=(12,6))
    bars = ax.bar(region_sales.index,region_sales.values)
    ax.set_title('区域销售额Top10',fontsize=16)
    ax.set_xlabel('区域',fontsize=12)
    ax.set_ylabel('销售额(元)',fontsize=12)

    # 为每个柱子添加数值标签
    for bar in bars:
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, height, f'{height:.2f}', 
                ha='center', va='bottom', fontsize=10)

    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def plot02():
    # 获取分组数据
    # category_gender = df_sales.groupby(['商品品类','客户性别'])['销售额'].sum().unstack()
    category_gender = df_sales.pivot_table(index='商品品类',columns='客户性别',values='销售额',aggfunc='sum')
    print(category_gender)
    # 绘图
    fig,ax = plt.subplots(figsize=(12,6))
    width = 0.35
    x = range(len(category_gender))
    print("x:",x)
    # 绘制分组柱状图
    ax.bar([i-width/2 for i in x],category_gender['男'],label='男性客户',width=width)
    ax.bar([i+width/2 for i in x],category_gender['女'],label='女性客户',width=width)
    
  
    ax.set_xticks(x)
    ax.set_xticklabels(category_gender.index)

    ax.set_title('不同性别不同品类销售额对比',fontsize=16)
    ax.set_xlabel('商品品类',fontsize=12)
    ax.set_ylabel('销售额(元)',fontsize=12)
    ax.grid(True,alpha=0.3)
    ax.legend()

    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()


# plot02()

def plot03():
    category_gender = df_sales.pivot_table(index='商品品类',columns='客户性别',values='销售额',aggfunc='sum')
    print(category_gender)

    fig,ax = plt.subplots(figsize=(12,6))
    ax.bar(category_gender.index,category_gender['男'],label='男性客户',color='#1f77b4')
    ax.bar(category_gender.index,category_gender['女'],label='女性客户',alpha=0.7,color='#ff7f0e',
            bottom=category_gender['男'])
    

    ax.set_title('不同性别不同品类销售额对比',fontsize=16)
    ax.set_xlabel('商品品类',fontsize=12)
    ax.set_ylabel('销售额(元)',fontsize=12)
    # ax.grid(True,alpha=0.3)
    ax.legend()

    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

# plot03()
def plot04():
    region_sales = df_sales.groupby('区域')['销售额'].sum().sort_values(ascending=False).head(10)
    print(region_sales)

    fig,ax = plt.subplots(figsize=(12,6))
    ax.barh(region_sales.index,region_sales.values,color='coral',alpha=0.8)

    ax.set_title('Top 10 区域销售额（水平）', fontsize=16, fontweight='bold')
    ax.set_xlabel('销售额（元）', fontsize=12)
    ax.invert_yaxis()  # 倒序显示，最大值在上

    plt.tight_layout()
    plt.show()

plot04()