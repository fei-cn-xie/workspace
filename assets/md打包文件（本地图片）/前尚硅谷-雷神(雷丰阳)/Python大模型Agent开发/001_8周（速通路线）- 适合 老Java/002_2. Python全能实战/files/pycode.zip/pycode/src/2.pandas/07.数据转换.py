import pandas as pd
df_orders=pd.read_csv('docs/data/用户下单数据.csv',encoding='gbk')
print(df_orders.head())


df_orders['用户出生日期'] = pd.to_datetime(df_orders['用户出生日期'])

df_orders['年龄'] = 2026 - df_orders['用户出生日期'].dt.year
print(df_orders.head())

# 消费等级
df_orders['消费等级'] = df_orders['交易金额'].apply(
    lambda x: '高' if x > 800 else ('中' if x > 400 else '低')
)
print(df_orders.head())

# 年龄段 cut； 分箱; 左闭右开区间（right=False；不包含右边值）
# 默认是包含右边值（right=True），左开右闭；
df_orders['年龄段'] = pd.cut(
    df_orders['年龄'],
    bins=[0, 18, 30, 45, 60, 100],
    labels=['儿童', '青年', '中年', '老年', '长寿'],
    right=False
)
print(df_orders.head())


# 读取销售数据
df_sales = pd.read_excel('docs/data/电商销售数据.xlsx')
print(df_sales.head())


# 分割区域信息
df_sales[['大区', '省份', '城市']] = df_sales['区域'].str.split('-', expand=True)
print(df_sales.head())

df_sales['进货价格_clean'] = df_sales['进货价格'].str.replace('¥', '').astype(int)
print(df_sales.head())

# 按交易金额降序
df_sorted = df_orders.sort_values('交易金额', ascending=False)
print(df_sorted.head(10))  # 前10大订单

df_orders.sort_values(by=['年龄','交易金额'],ascending=[True,False],inplace=True)
print(df_orders.head(20))

append0=pd.DataFrame([[11,12],[13,14]],columns=['二班','一班'],index=['优','良'])
print(append0)

append1=pd.DataFrame([[15,16]],columns=['二班','三班'],index=['差'])
print(append1)

append2=pd.concat([append0,append1],
          axis= 0, #指定扩展轴，默认0，拼接行
          sort=True,
          keys=['k1','k2'],
          ignore_index=False) #ignore_index=True去除索引
print(append2)

append3 = pd.concat([append0,append1],
        axis=1,
        sort=True,
        keys=['k1','k2'],
          ignore_index=False)
print(append3)


