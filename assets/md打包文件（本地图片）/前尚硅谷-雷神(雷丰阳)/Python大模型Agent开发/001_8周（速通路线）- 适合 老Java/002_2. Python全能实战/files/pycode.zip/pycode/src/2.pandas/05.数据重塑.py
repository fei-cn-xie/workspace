import pandas as pd

# 创建宽表数据（学生成绩）
df_wide = pd.DataFrame({
    '学生': ['张三', '李四', '王五'],
    '语文': [85, 92, 78],
    '数学': [90, 87, 95],
    '英语': [88, 91, 82]
})

print("宽表格式:")
print(df_wide)

df_long = pd.melt(
    df_wide,
    id_vars=['学生'],           # 保持不变的列（标识列）
    # value_vars=['语文', '数学', '英语'],  # 要转换的列，可以不写。默认是除了id_vars中的列
    var_name='科目',            # 新列名（存储原列名）
    value_name='成绩'           # 新列名（存储值）
)
print("\n长表格式:")
print(df_long)


# 创建月度销售宽表
sales_wide = pd.DataFrame({
    '产品': ['手机', '电脑', '平板'],
    '1月': [1200, 800, 500],
    '2月': [1500, 900, 600],
    '3月': [1300, 850, 550]
})
print("\n月度销售宽表:")
print(sales_wide)

sales_long = pd.melt(sales_wide,
    id_vars=['产品'],
    var_name='月份',
    value_name='销售额'
)
print("\n月度销售长表:")
print(sales_long)

# 计算不同产品销售总额
total_sales = sales_long.groupby('产品')['销售额'].sum()
print("\n不同产品销售总额:")
print(total_sales)

# 创建包含多个标识列的宽表
df_multi = pd.DataFrame({
    '城市': ['北京', '北京', '上海', '上海'],
    '区域': ['朝阳', '海淀', '浦东', '徐汇'],
    'Q1': [100, 120, 150, 130],
    'Q2': [110, 125, 160, 135],
    'Q3': [105, 130, 155, 140],
    'Q4': [115, 135, 165, 145]
})

print("原始数据:")
print(df_multi)
df_long_multi = pd.melt(
    df_multi,
    id_vars=['城市', '区域'],  # 多个标识列
    var_name='季度',
    value_name='销售额'
)

print("\n转换后:")
print(df_long_multi)

# 使用之前的长表数据
print("长表格式:")
print(df_long)

df_pivot = df_long.pivot(
    index = ['学生'],
    columns = ['科目'],
    values = ['成绩']
).reset_index()
print("\n转换后:")
print(df_pivot)
print(df_pivot.shape)


# 使用之前的销售长表
print("销售长表:")
print(sales_long)

sales_pivot = sales_long.pivot(
    index = ['产品'],
    columns = ['月份'],
    values = ['销售额']
).reset_index()
print("\n转换后:")
print(sales_pivot)
print(sales_pivot.shape)

# 创建有重复值的长表
sales_dup = pd.DataFrame({
    '产品': ['手机', '手机', '电脑', '电脑', '手机', '电脑'],
    '月份': ['1月', '1月', '1月', '1月', '2月', '2月'],
    '销售额': [1000, 1200, 800, 850, 1500, 900]
})
print("\n有重复值的销售长表:")
print(sales_dup)

sales_pivot_dup = pd.pivot_table(
    sales_dup,
    index = ['产品'],
    columns = ['月份'],
    values = ['销售额'],
    aggfunc = 'sum'
).reset_index()

print("\n转换后:")
print(sales_pivot_dup)
print(sales_pivot_dup.shape)