import data.sales_data as sd
import matplotlib.pyplot as plt

df_sales, df_orders = sd.load_data()

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']  # 黑体或微软雅黑
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

def plot01():
    sales_data = df_sales.groupby('日期')['销售额'].sum().reset_index()
    print(sales_data)

    fig,ax = plt.subplots(figsize=(12,6))
    ax.plot(sales_data['日期'],sales_data['销售额'])
    ax.set_title('销售额趋势',fontsize=16)
    ax.set_xlabel('日期',fontsize=12)
    ax.set_ylabel('销售额(元)',fontsize=12)
    ax.grid(True,alpha=0.3)

    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def plot02():
    # sales_data = df_sales.groupby(['日期','客户性别'])['销售额'].sum().unstack()
    sales_data = df_sales.pivot_table(index='日期',columns='客户性别',values='销售额',aggfunc='sum')
    print(sales_data)
    fig,ax =plt.subplots(figsize=(12,6))
    ax.plot(sales_data.index,sales_data['男'],label='男性客户',marker='o')
    ax.plot(sales_data.index,sales_data['女'],label='女性客户',marker='s')
    ax.set_title('不同性别销售额趋势',fontsize=16)
    ax.set_xlabel('日期',fontsize=12)
    ax.set_ylabel('销售额(元)',fontsize=12)
    ax.grid(True,alpha=0.3)
    ax.legend()

    plt.tight_layout()
    plt.show()

plot02()