import numpy as np

a = np.array([1, 2, 3, 4])
b = np.array([10, 20, 30, 40])

# 加减乘除（逐元素运算）
print(a + b)    # [11 22 33 44]
print(a - b)    # [-9 -18 -27 -36]
print(a * b)    # [10 40 90 160]
print(b / a)    # [10. 10. 10. 10.]

# 幂运算
print(a ** 2)   # [1 4 9 16]

# 取模
print(b % 3)    # [1 2 0 1]


arr = np.array([1, 2, 3, 4, 5])

# 数组与标量运算（标量会广播到每个元素）
print(arr + 10)    # [11 12 13 14 15]
print(arr * 2)     # [2 4 6 8 10]
print(arr / 2)     # [0.5 1.  1.5 2.  2.5]
print(arr ** 2)    # [1 4 9 16 25]

arr = np.array([1, 2, 3, 4, 5])

print(arr > 3)     # [False False False  True  True]
print(arr == 3)    # [False False  True False False]
print(arr != 3)    # [ True  True False  True  True]

# 数组间比较
a = np.array([1, 2, 3])
b = np.array([3, 2, 1])
print(a > b)       # [False False  True]
print(a == b)      # [False  True False]