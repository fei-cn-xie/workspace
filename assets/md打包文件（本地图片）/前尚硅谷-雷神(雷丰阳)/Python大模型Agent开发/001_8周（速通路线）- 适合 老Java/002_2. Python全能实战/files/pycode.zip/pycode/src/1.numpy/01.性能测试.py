import numpy as np

py_list = [1,2,3,4,5]
print(py_list)

np_array = np.array(py_list)
print(np_array)

# Python 列表 vs NumPy 数组的性能对比
import time

# Python 列表
python_list = list(range(1000000))
start = time.time()
result = [x * 2 for x in python_list]
print(f"Python 列表耗时: {time.time() - start:.4f}秒")
# ===================================================
# NumPy 数组
numpy_array = np.arange(1000000)
start = time.time()
result = numpy_array * 2
print(f"NumPy 数组耗时: {time.time() - start:.4f}秒")
# NumPy 通常快 10-100 倍！