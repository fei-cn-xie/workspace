import matplotlib.pyplot as plt
import matplotlib.cbook as cbook
from matplotlib.image import imread
import numpy as np

# 1. 图像读取与显示
# 尝试使用内置的经典图像
try:
    # 方法1：使用matplotlib内置的sample data中的经典图像
    image_path = cbook.get_sample_data('grace_hopper.jpg')
    print(f"尝试加载图像: {image_path}")
    image = imread(image_path)
    original_image = image.copy()
    print(f"成功加载图像，形状: {image.shape}")
except Exception as e:
    print(f"无法加载grace_hopper.jpg: {e}")

# 2. 图像预处理
# 如果是彩色图像，转换为灰度图像用于处理
grayscale_image = None
if image.ndim == 3:
    print("将彩色图像转换为灰度图像...")
    # 使用加权平均法转换为灰度图像
    grayscale_image = np.dot(image[..., :3], [0.2989, 0.5870, 0.1140])
    grayscale_image = grayscale_image.astype(np.uint8)
else:
    grayscale_image = image.copy()

# 3. 反转图像
print("图像反转...")
reversed_image = 255 - grayscale_image

# 4. 二值化处理
print("二值化处理...")
threshold = 128
binary_image = (grayscale_image > threshold).astype(np.uint8) * 255

# 5. 显示所有处理后的图像
plt.figure(figsize=(12, 8))

plt.subplot(2, 3, 1)
plt.imshow(original_image)
plt.title('Original Image')

plt.subplot(2, 3, 2)
plt.imshow(grayscale_image, cmap='gray')
plt.title('Grayscale Image')

plt.subplot(2, 3, 3)
plt.imshow(reversed_image, cmap='gray')
plt.title('Reversed Image')

plt.subplot(2, 3, 4)
plt.imshow(binary_image, cmap='gray')
plt.title('Binary Image')

plt.tight_layout()
plt.show()
