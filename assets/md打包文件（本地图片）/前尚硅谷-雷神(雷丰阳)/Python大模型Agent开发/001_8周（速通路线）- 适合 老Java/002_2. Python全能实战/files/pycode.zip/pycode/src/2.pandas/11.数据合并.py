import pandas as pd
import numpy as np
#构造数据集merge0
# 模拟员工信息表
np.random.seed(42)
employees = pd.DataFrame({
    "emp_id":  np.arange(1, 6),
    "name":    ["张三", "李四", "王五", "赵六", "钱七"],
    "dept_id": [10, 20, 10, 30, 0]
})

# 模拟部门信息表
departments = pd.DataFrame({
    "dept_id": [10, 20, 30, 40],
    "dept_name": ["人事部", "技术部", "市场部", "财务部"]
})
print(employees)
print(departments)

# 内连接
inner_merge = pd.merge(employees,departments,on='dept_id',how='inner')
print(inner_merge)

# 左连接
left_merge = pd.merge(employees,departments,on='dept_id',how='left')
print(left_merge)

# 右连接
right_merge = pd.merge(employees,departments,on='dept_id',how='right')
print(right_merge)

# 外连接
outer_merge = pd.merge(employees,departments,on='dept_id',how='outer')
print(outer_merge)

#模拟绩效表
performance = pd.DataFrame({
    "emp_id": [1, 2, 3, 4, 5],
    "year":   [2023, 2025, 2023, 2023, 2023],
    "score":  [90, 85, 95, 78, 88]
})
# 添加 year 列，方便测试
employees['year'] = [2023, 2025, 2023, 2024, 2023]
print(employees)
print(performance)

# 多列合并
multi_merge = pd.merge(employees, performance, on=['emp_id', 'year'], how='inner')
print(multi_merge)

salary2022 = pd.DataFrame({
    "emp_id": [1, 2, 3, 4, 5],
    "salary": [7000, 8000, 7500, 6500, 9000]
})
salary2023 = pd.DataFrame({
    "emp_id": [1, 2, 3, 4, 5],
    "salary": [7500, 8500, 8000, 7000, 9500]
})
print(salary2022)
print(salary2023)

# 合并2022年和2023年的薪资数据
salary_merge = pd.merge(salary2022,salary2023,on='emp_id',suffixes=('_2022', '_2023'))
print(salary_merge)


employees = pd.DataFrame({
    "emp_id":  np.arange(1, 6),
    "name":    ["张三", "李四", "王五", "赵六", "钱七"],
    "dept_no": [10, 20, 10, 30, 0]
})

 # 左连接，使用 dept_no 作为左表键
left_merge = pd.merge(employees, departments, left_on='dept_no', right_on='dept_id', how='left')
print(left_merge)

# 写 sql(数据库查询语言)
