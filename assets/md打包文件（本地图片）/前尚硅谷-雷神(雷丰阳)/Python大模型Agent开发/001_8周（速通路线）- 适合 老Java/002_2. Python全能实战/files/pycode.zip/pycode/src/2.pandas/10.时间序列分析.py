import pandas as pd

df_orders = pd.read_excel('docs/data/电商销售数据.xlsx',
                       sheet_name='销售数据')#导入销售数据sheet表


print(df_orders.dtypes)

# 转换为日期时间类型
df_orders['日期'] = pd.to_datetime(df_orders['日期'])

# 提取时间组件
df_orders['年'] = df_orders['日期'].dt.year
df_orders['月'] = df_orders['日期'].dt.month
df_orders['日'] = df_orders['日期'].dt.day
df_orders['星期'] = df_orders['日期'].dt.dayofweek
df_orders['小时'] = df_orders['日期'].dt.hour



# 按年月统计订单
df_orders['年月'] = df_orders['日期'].dt.to_period('M')

print(df_orders.head())

monthly_orders = df_orders.groupby('年月').agg({'销售额': ['sum', 'mean', 'count']}).round(2)
daily_orders = df_orders.groupby('日期').agg({'销售额': ['sum', 'mean', 'count']}).round(2)
weekly_orders = df_orders.groupby('星期').agg({'利润': ['sum', 'mean', 'count']}).round(2)
weekly_orders.index = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']
print(weekly_orders)

# 每日销售趋势
daily_trend = df_orders.groupby('日期').agg({
    '销售额': 'sum',
    '利润': 'sum',
    '订单号': 'count'
    }).round(2)

daily_trend.columns = ['销售额', '利润', '订单数']
print(daily_trend)

# 计算移动平均
daily_trend['销售额_移动平均'] = daily_trend['销售额'].rolling(window=7).mean().round(2)
daily_trend['利润_移动平均'] = daily_trend['利润'].rolling(window=7).mean().round(2)
daily_trend['订单数_移动平均'] = daily_trend['订单数'].rolling(window=7).mean().round(2)
print(daily_trend)
