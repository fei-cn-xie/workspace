import numpy as np

# 设置随机种子（保证可重复性）
np.random.seed(42)

# 0-1之间
rand_num = np.random.rand()  
print("0-1之间的随机数:", rand_num)



# 0-1之间的均匀分布
rand_uniform = np.random.rand(3, 4)  # 3x4矩阵
print("0-1之间的均匀分布:", rand_uniform)



# 指定范围的随机整数
rand_int = np.random.randint(1, 100, size=(3, 3))
print("指定范围的随机整数:", rand_int)



# 标准正态分布 (均值0, 标准差1)
rand_normal = np.random.randn(3, 3)
print("标准正态分布:", rand_normal)

# 指定均值和标准差的正态分布
rand_normal2 = np.random.normal(loc=50, scale=10, size=100)
print("指定均值和标准差的正态分布:", rand_normal2)



# 从数组中随机选择
arr = np.array([1, 2, 3, 4, 5])
choice = np.random.choice(arr, size=3, replace=False)
print("从数组中随机选择:", choice)

# 均匀分布
uniform = np.random.uniform(low=0, high=10, size=1000)
print("均匀分布:", uniform)

# 正态分布
normal = np.random.normal(loc=0, scale=1, size=1000)
print("正态分布:", normal)

# 二项分布
binomial = np.random.binomial(n=10, p=0.5, size=1000)
print("二项分布:", binomial)



# 泊松分布
poisson = np.random.poisson(lam=5, size=1000)
print("泊松分布:", poisson)

# 指数分布
exponential = np.random.exponential(scale=1, size=1000)
print("指数分布:", exponential)

print("="*50)

arr = np.array([1, 2, 3, 4, 5])

# 打乱数组（原地修改）
np.random.shuffle(arr)
print("打乱后的数组:", arr)  # 例如 [3 1 5 2 4]

# 返回打乱后的副本
arr2 = np.array([1, 2, 3, 4, 5])
shuffled = np.random.permutation(arr2)
print("打乱后的数组副本:", shuffled)  # 例如 [2 5 1 4 3]
print("原数组:", arr2)      # [1 2 3 4 5] 原数组不变

