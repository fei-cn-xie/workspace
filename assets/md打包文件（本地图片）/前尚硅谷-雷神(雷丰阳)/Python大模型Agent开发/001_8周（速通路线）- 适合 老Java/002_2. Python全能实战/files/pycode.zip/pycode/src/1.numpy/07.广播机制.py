import numpy as np

# 标量与数组
arr = np.array([1, 2, 3])
print("arr",arr + 10)  # [11 12 13]
# 10 被"广播"成 [10, 10, 10]

# 代码实现
a = np.array([[1, 2, 3]])      # shape: (1, 3)
b = np.array([[10], [20], [30]])  # shape: (3, 1)
print("a+b",a + b)

# 不同形状数组
a = np.array([[1, 2, 3],
              [4, 5, 6]])  # shape: (2, 3)
b = np.array([10, 20, 30])  # shape: (3,)
print("a+b",a + b)
# [[11 22 33]
#  [14 25 36]]
# b 被广播成 [[10, 20, 30], [10, 20, 30]]