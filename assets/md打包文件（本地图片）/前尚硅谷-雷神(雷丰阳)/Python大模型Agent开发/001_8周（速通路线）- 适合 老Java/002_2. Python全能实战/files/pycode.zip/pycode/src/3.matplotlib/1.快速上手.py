import matplotlib.pyplot as plt

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei']  # 黑体或微软雅黑
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 1. pyplot接口
# plt.plot([1,2,3,4],[1,4,2,3])
# plt.title('简单折线图')
# plt.xlabel('x轴')
# plt.ylabel('y轴')
# plt.legend(['折线1'])
# plt.xlim(0,8)
# plt.ylim(0,8)
# plt.grid(True)

# plt.show()

# 2. 面向对象接口
fig,(ax1,ax2) = plt.subplots(1,2)

ax1.plot([1,2,3,4],[1,4,2,3])
ax1.set_title('简单折线图')
ax1.set_xlabel('x轴')
ax1.set_ylabel('y轴')

ax1.legend(['折线1'])
ax1.set_xlim(0,8)
ax1.set_ylim(0,8)
ax1.grid(True)


ax2.plot([1,2,3,4],[1,4,2,3])
ax2.set_title('简单折线图2')
ax2.set_xlabel('x轴')
ax2.set_ylabel('y轴')

ax2.legend(['折线1'])


plt.show()