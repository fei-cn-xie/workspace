import pandas as pd

# 读取用户下单数据
df_orders = pd.read_csv('docs/data/用户下单数据.csv', encoding='gbk')
# 查看基本信息
print(df_orders.shape)       # (5000, 8)
print(df_orders.head())      # 前5行
print(df_orders.info())      # 数据类型和缺失值
print(df_orders.describe())  # 统计摘要

# 读取电商销售数据
df_sales = pd.read_excel('docs/data/电商销售数据.xlsx')

print(df_sales.shape)   # (7284, 11)



#默认显示前5行,用于快速查看数据集的一小部分
print(df_sales.head())

# #指定显示前10行数据
print(df_sales.head(10))

# #与head()类似，但是返回的是后n行，默认显示后5行数据
print(df_sales.tail())

# #随机抽取5行数据
print(df_sales.sample(5))

# #提供数据的简要摘要，包括索引类型、列名、非空值计数和数据类型等
df_sales.info()

# #数据类型
print(df_sales.dtypes)

# #生成数据的描述性统计信息，包括计数、均值、标准差、最小值、四分位数和最大值
print(df_sales.describe().round(0))

# #返回数据的形状（行数，列数）
print(df_sales.shape)

# #返回DataFrame行索引
print(df_sales.index)

# #返回DataFrame的列名
print(df_sales.columns)

# #对于Series中的唯一值，返回其计数，常用于统计分类数据。
print(df_sales['商品品类'].value_counts())

# #查看数据唯一值
print(df_sales['商品品类'].unique())


# 单列
print(df_orders['性别'])

# 多列
print(df_orders[['用户ID', '性别', '交易金额']])

# 使用 loc（基于标签）[包含结束的值]
print(df_orders.loc[0:4])  # 前5行（包含4）

# 使用 iloc（基于位置）[不包含结束的值]
print(df_orders.iloc[0:10:2])  # 前5行（不包含5）

# 单条件：找出女性用户
female = df_orders[df_orders['性别'] == '女']
print(f"女性用户数: {female}")

# 单条件：大额订单（>800元）
high_value = df_orders[df_orders['交易金额'] > 800]
print(f"大额订单数: {high_value}")
print(f"大额订单平均金额: {high_value['交易金额'].mean():.2f}元")

# 多条件：已婚女性的大额订单
result = df_orders[
    (df_orders['性别'] == '女') & 
    (df_orders['婚姻状况'] == '已婚') & 
    (df_orders['交易金额'] > 800)
]
print(f"符合条件的订单数: {result}")

# 使用 isin：本科或博士学历
edu_filter = df_orders[df_orders['文化程度'].isin(['本科', '博士'])]
print(f"符合条件的订单数: {edu_filter}")

# 使用 query（更直观）
result = df_orders.query('性别 == "女" and 交易金额 > 800')
print(f"符合条件的订单数: {result}")



# 4. 实战：不同学历消费
with pd.ExcelWriter('edu_orders.xlsx', #指定文件路径
                    engine='openpyxl', #代表所使用的引擎
                    mode='w', #写入模式
                    ) as writer:
    for edu in df_orders['文化程度'].unique():
        edu_orders = df_orders[df_orders['文化程度'] == edu]
        edu_orders.to_excel(writer, sheet_name=edu, index=False)
    # edu_orders_mean = edu_orders['交易金额'].mean()
    # print(f" {edu} 订单数量: {len(edu_orders)}  平均金额: {edu_orders_mean:.2f}元")


# df = pd.DataFrame({
#     '用户ID': [6414111, 6516117, 6714112, 5311117],
#     '性别': ['男', '女', '女', '女'],
#     '文化程度': ['本科', '博士', '博士', '大专'],
#     '交易金额': [402.77, 545.27, 256.72, 275.55]
# })

# df.to_excel('out_table.xlsx', #导出数据路径
#             sheet_name='Sheet1',#写入的Excel表的名字
#             index=False,#不显示行索引
#             na_rep=0#缺失数据显示为0
#            )

# import numpy as np
# #初始化ExcelWriter对象
# writer = pd.ExcelWriter('out_sheet.xlsx', #指定文件路径
#                         engine='openpyxl', #代表所使用的引擎
#                         mode='w', #写入模式
#                         )

# #生成随机数据
# df1 = pd.DataFrame(np.random.randn(10,4),
#                   columns=list('ABCD'))

# df2 = pd.DataFrame(np.random.randint(0,100,size=(10,4)),
#                    columns=["col1", "col2", "col3", "col4"])
# #使用to_excel()方法写入数据
# with pd.ExcelWriter('output2.xlsx', engine='openpyxl') as writer:
#     df1.to_excel(writer, sheet_name='Sheet1',index=False)
#     df2.to_excel(writer, sheet_name='Sheet2',index=False)



